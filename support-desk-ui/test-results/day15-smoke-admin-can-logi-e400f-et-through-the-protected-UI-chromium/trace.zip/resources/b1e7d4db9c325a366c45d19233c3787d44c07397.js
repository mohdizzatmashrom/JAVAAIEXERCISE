import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/TicketDataContext.jsx");const createContext = __vite__cjsImport0_react["createContext"]; const useCallback = __vite__cjsImport0_react["useCallback"]; const useContext = __vite__cjsImport0_react["useContext"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"]; const useReducer = __vite__cjsImport0_react["useReducer"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=3927c5ff";
import { fetchPagedTickets, updateTicket } from "/src/services/api.js";
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/context/TicketDataContext.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3927c5ff";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const TicketDataContext = createContext(null);
_c = TicketDataContext;
/* ------------------------------------------------------------------ */
/*  In-memory page cache (module-level, survives re-renders)           */
/* ------------------------------------------------------------------ */
const pageCache = new Map();
function buildCacheKey({ page, size, sortBy, direction, status, searchText }) {
	return `${page}|${size}|${sortBy}|${direction}|${status ?? ""}|${searchText ?? ""}`;
}
/* ------------------------------------------------------------------ */
/*  Initial state                                                      */
/* ------------------------------------------------------------------ */
const initialState = {
	tickets: [],
	selectedId: null,
	loading: false,
	error: "",
	cacheMessage: "",
	pageInfo: {
		page: 0,
		size: 5,
		totalPages: 0,
		totalElements: 0
	},
	sort: {
		sortBy: "createdAt",
		direction: "desc"
	},
	filters: {
		searchText: "",
		statusFilter: ""
	}
};
/* ------------------------------------------------------------------ */
/*  Reducer                                                            */
/* ------------------------------------------------------------------ */
function ticketReducer(state, action) {
	switch (action.type) {
		case "LOAD_START": return {
			...state,
			loading: true,
			error: "",
			cacheMessage: ""
		};
		case "LOAD_SUCCESS": {
			const pageData = action.data;
			const tickets = pageData.content ?? [];
			const selectedStillVisible = tickets.some((t) => t.id === state.selectedId);
			return {
				...state,
				tickets,
				selectedId: selectedStillVisible ? state.selectedId : tickets[0]?.id ?? null,
				loading: false,
				error: "",
				cacheMessage: action.cacheMessage ?? "",
				pageInfo: {
					page: pageData.number ?? state.pageInfo.page,
					size: pageData.size ?? state.pageInfo.size,
					totalPages: pageData.totalPages ?? 0,
					totalElements: pageData.totalElements ?? 0
				}
			};
		}
		case "LOAD_ERROR": return {
			...state,
			loading: false,
			error: action.message,
			cacheMessage: ""
		};
		case "SET_CACHE_MESSAGE": return {
			...state,
			cacheMessage: action.value
		};
		case "SET_SEARCH_TEXT": return {
			...state,
			filters: {
				...state.filters,
				searchText: action.value
			}
		};
		case "SET_STATUS_FILTER": return {
			...state,
			filters: {
				...state.filters,
				statusFilter: action.value
			}
		};
		case "SET_PAGE": return {
			...state,
			pageInfo: {
				...state.pageInfo,
				page: action.value
			}
		};
		case "SET_PAGE_SIZE": return {
			...state,
			pageInfo: {
				...state.pageInfo,
				size: action.value,
				page: 0
			}
		};
		case "SET_SORT_BY": return {
			...state,
			sort: {
				...state.sort,
				sortBy: action.value
			}
		};
		case "SET_SORT_DIRECTION": return {
			...state,
			sort: {
				...state.sort,
				direction: action.value
			}
		};
		case "SELECT_TICKET": return {
			...state,
			selectedId: action.ticketId
		};
		case "OPTIMISTIC_STATUS_UPDATE": {
			const updatedTickets = state.tickets.map((t) => t.id === action.ticketId ? {
				...t,
				status: action.newStatus
			} : t);
			return {
				...state,
				tickets: updatedTickets
			};
		}
		case "ROLLBACK_STATUS": {
			const rolledBack = state.tickets.map((t) => t.id === action.backupTicket.id ? action.backupTicket : t);
			return {
				...state,
				tickets: rolledBack,
				error: action.message
			};
		}
		case "CONFIRM_STATUS_UPDATE": {
			const confirmed = state.tickets.map((t) => t.id === action.updatedTicket.id ? action.updatedTicket : t);
			return {
				...state,
				tickets: confirmed
			};
		}
		default: return state;
	}
}
/* ------------------------------------------------------------------ */
/*  Provider                                                           */
/* ------------------------------------------------------------------ */
export function TicketDataProvider({ children }) {
	_s();
	const { token, isAuthenticated } = useAuth();
	const [state, dispatch] = useReducer(ticketReducer, initialState);
	/* Use a ref to always have the latest state inside loadTickets
	without re-creating the callback on every state change.         */
	const stateRef = useRef(state);
	stateRef.current = state;
	/* Core fetch helper – called by both loadTickets and refreshTickets */
	const doFetch = useCallback((forceRefresh) => {
		if (!token) return;
		const s = stateRef.current;
		const params = {
			page: s.pageInfo.page,
			size: s.pageInfo.size,
			sortBy: s.sort.sortBy,
			direction: s.sort.direction,
			status: s.filters.statusFilter,
			searchText: s.filters.searchText
		};
		const cacheKey = buildCacheKey(params);
		// Check cache first (unless force-refresh)
		if (!forceRefresh && pageCache.has(cacheKey)) {
			const cached = pageCache.get(cacheKey);
			dispatch({
				type: "LOAD_SUCCESS",
				data: cached,
				cacheMessage: "Loaded from cache"
			});
			return;
		}
		dispatch({ type: "LOAD_START" });
		fetchPagedTickets(token, params).then((data) => {
			// Store in cache
			pageCache.set(cacheKey, data);
			dispatch({
				type: "LOAD_SUCCESS",
				data,
				cacheMessage: "Fetched from backend"
			});
		}).catch((err) => dispatch({
			type: "LOAD_ERROR",
			message: err.message
		}));
	}, [token]);
	/* Load tickets – uses cache when available */
	const loadTickets = useCallback(() => {
		doFetch(false);
	}, [doFetch]);
	/* Refresh – always fetches from backend, updates cache */
	const refreshTickets = useCallback(() => {
		doFetch(true);
	}, [doFetch]);
	useEffect(() => {
		if (isAuthenticated) {
			loadTickets();
		}
	}, [isAuthenticated, loadTickets]);
	/* Stable action dispatchers */
	const setSearchText = useCallback((value) => {
		dispatch({
			type: "SET_SEARCH_TEXT",
			value
		});
		dispatch({
			type: "SET_PAGE",
			value: 0
		});
	}, []);
	const setStatusFilter = useCallback((value) => {
		dispatch({
			type: "SET_STATUS_FILTER",
			value
		});
		dispatch({
			type: "SET_PAGE",
			value: 0
		});
	}, []);
	const setPage = useCallback((value) => {
		dispatch({
			type: "SET_PAGE",
			value
		});
	}, []);
	const setPageSize = useCallback((value) => {
		dispatch({
			type: "SET_PAGE_SIZE",
			value
		});
	}, []);
	const setSortBy = useCallback((value) => {
		dispatch({
			type: "SET_SORT_BY",
			value
		});
		dispatch({
			type: "SET_PAGE",
			value: 0
		});
	}, []);
	const setSortDirection = useCallback((value) => {
		dispatch({
			type: "SET_SORT_DIRECTION",
			value
		});
		dispatch({
			type: "SET_PAGE",
			value: 0
		});
	}, []);
	const selectTicket = useCallback((ticketId) => {
		dispatch({
			type: "SELECT_TICKET",
			ticketId
		});
	}, []);
	/* Optimistic status update ---------------------------------------- */
	const updateTicketStatus = useCallback((ticketId, newStatus) => {
		if (!token) return;
		const s = stateRef.current;
		const currentTicket = s.tickets.find((t) => t.id === ticketId);
		if (!currentTicket || currentTicket.status === newStatus) return;
		// 1. Save backup
		const backupTicket = { ...currentTicket };
		// 2. Update UI immediately (optimistic)
		dispatch({
			type: "OPTIMISTIC_STATUS_UPDATE",
			ticketId,
			newStatus
		});
		// 3. Build payload for PUT request
		const payload = {
			title: currentTicket.title,
			description: currentTicket.description,
			category: currentTicket.category,
			priority: currentTicket.priority,
			status: newStatus
		};
		// 4. Send PUT request
		updateTicket(ticketId, token, payload).then((updatedTicket) => {
			// 5a. Success – replace optimistic data with backend response
			dispatch({
				type: "CONFIRM_STATUS_UPDATE",
				updatedTicket
			});
			// Invalidate page cache since data changed
			pageCache.clear();
		}).catch((err) => {
			// 5b. Failure – roll back to backup
			dispatch({
				type: "ROLLBACK_STATUS",
				backupTicket,
				message: err.message
			});
		});
	}, [token]);
	/* Derived values ------------------------------------------------- */
	const selectedTicket = useMemo(() => state.tickets.find((t) => t.id === state.selectedId) ?? null, [state.tickets, state.selectedId]);
	/* Context value -------------------------------------------------- */
	const value = useMemo(() => ({
		...state,
		selectedTicket,
		loadTickets,
		refreshTickets,
		setSearchText,
		setStatusFilter,
		setPage,
		setPageSize,
		setSortBy,
		setSortDirection,
		selectTicket,
		updateTicketStatus
	}), [
		state,
		selectedTicket,
		loadTickets,
		refreshTickets,
		setSearchText,
		setStatusFilter,
		setPage,
		setPageSize,
		setSortBy,
		setSortDirection,
		selectTicket,
		updateTicketStatus
	]);
	return /* @__PURE__ */ _jsxDEV(TicketDataContext.Provider, {
		value,
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 285,
		columnNumber: 10
	}, this);
}
_s(TicketDataProvider, "JU3q11btzKJt5DtsUBLFN35SKWI=", false, function() {
	return [useAuth];
});
_c2 = TicketDataProvider;
/* ------------------------------------------------------------------ */
/*  Hook                                                               */
/* ------------------------------------------------------------------ */
export function useTicketData() {
	_s2();
	const value = useContext(TicketDataContext);
	if (!value) {
		throw new Error("useTicketData must be used inside TicketDataProvider");
	}
	return value;
}
_s2(useTicketData, "ksutO2/Ix3UeCrGnhyM+QEP505Y=");
var _c, _c2;
$RefreshReg$(_c, "TicketDataContext");
$RefreshReg$(_c2, "TicketDataProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/context/TicketDataContext.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/context/TicketDataContext.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/context/TicketDataContext.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/context/TicketDataContext.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlLGFBQWEsWUFBWSxXQUFXLFNBQVMsWUFBWSxjQUFjO0FBQy9GLFNBQVMsbUJBQW1CLG9CQUFvQjtBQUNoRCxTQUFTLGVBQWU7Ozs7QUFFeEIsTUFBTSxvQkFBb0IsY0FBYyxJQUFJOzs7OztBQU01QyxNQUFNLFlBQVksSUFBSSxJQUFJO0FBRTFCLFNBQVMsY0FBYyxFQUFFLE1BQU0sTUFBTSxRQUFRLFdBQVcsUUFBUSxjQUFjO0NBQzVFLE9BQU8sR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLE9BQU8sR0FBRyxVQUFVLEdBQUcsVUFBVSxHQUFHLEdBQUcsY0FBYztBQUNqRjs7OztBQU1BLE1BQU0sZUFBZTtDQUNuQixTQUFTLENBQUM7Q0FDVixZQUFZO0NBQ1osU0FBUztDQUNULE9BQU87Q0FDUCxjQUFjO0NBQ2QsVUFBVTtFQUNSLE1BQU07RUFDTixNQUFNO0VBQ04sWUFBWTtFQUNaLGVBQWU7Q0FDakI7Q0FDQSxNQUFNO0VBQ0osUUFBUTtFQUNSLFdBQVc7Q0FDYjtDQUNBLFNBQVM7RUFDUCxZQUFZO0VBQ1osY0FBYztDQUNoQjtBQUNGOzs7O0FBTUEsU0FBUyxjQUFjLE9BQU8sUUFBUTtDQUNwQyxRQUFRLE9BQU8sTUFBZjtFQUNFLEtBQUssY0FDSCxPQUFPO0dBQUUsR0FBRztHQUFPLFNBQVM7R0FBTSxPQUFPO0dBQUksY0FBYztFQUFHO0VBRWhFLEtBQUssZ0JBQWdCO0dBQ25CLE1BQU0sV0FBVyxPQUFPO0dBQ3hCLE1BQU0sVUFBVSxTQUFTLFdBQVcsQ0FBQztHQUNyQyxNQUFNLHVCQUF1QixRQUFRLE1BQU0sTUFBTSxFQUFFLE9BQU8sTUFBTSxVQUFVO0dBQzFFLE9BQU87SUFDTCxHQUFHO0lBQ0g7SUFDQSxZQUFZLHVCQUF1QixNQUFNLGFBQWMsUUFBUSxFQUFFLEVBQUUsTUFBTTtJQUN6RSxTQUFTO0lBQ1QsT0FBTztJQUNQLGNBQWMsT0FBTyxnQkFBZ0I7SUFDckMsVUFBVTtLQUNSLE1BQU0sU0FBUyxVQUFVLE1BQU0sU0FBUztLQUN4QyxNQUFNLFNBQVMsUUFBUSxNQUFNLFNBQVM7S0FDdEMsWUFBWSxTQUFTLGNBQWM7S0FDbkMsZUFBZSxTQUFTLGlCQUFpQjtJQUMzQztHQUNGO0VBQ0Y7RUFFQSxLQUFLLGNBQ0gsT0FBTztHQUFFLEdBQUc7R0FBTyxTQUFTO0dBQU8sT0FBTyxPQUFPO0dBQVMsY0FBYztFQUFHO0VBRTdFLEtBQUsscUJBQ0gsT0FBTztHQUFFLEdBQUc7R0FBTyxjQUFjLE9BQU87RUFBTTtFQUVoRCxLQUFLLG1CQUNILE9BQU87R0FBRSxHQUFHO0dBQU8sU0FBUztJQUFFLEdBQUcsTUFBTTtJQUFTLFlBQVksT0FBTztHQUFNO0VBQUU7RUFFN0UsS0FBSyxxQkFDSCxPQUFPO0dBQUUsR0FBRztHQUFPLFNBQVM7SUFBRSxHQUFHLE1BQU07SUFBUyxjQUFjLE9BQU87R0FBTTtFQUFFO0VBRS9FLEtBQUssWUFDSCxPQUFPO0dBQUUsR0FBRztHQUFPLFVBQVU7SUFBRSxHQUFHLE1BQU07SUFBVSxNQUFNLE9BQU87R0FBTTtFQUFFO0VBRXpFLEtBQUssaUJBQ0gsT0FBTztHQUFFLEdBQUc7R0FBTyxVQUFVO0lBQUUsR0FBRyxNQUFNO0lBQVUsTUFBTSxPQUFPO0lBQU8sTUFBTTtHQUFFO0VBQUU7RUFFbEYsS0FBSyxlQUNILE9BQU87R0FBRSxHQUFHO0dBQU8sTUFBTTtJQUFFLEdBQUcsTUFBTTtJQUFNLFFBQVEsT0FBTztHQUFNO0VBQUU7RUFFbkUsS0FBSyxzQkFDSCxPQUFPO0dBQUUsR0FBRztHQUFPLE1BQU07SUFBRSxHQUFHLE1BQU07SUFBTSxXQUFXLE9BQU87R0FBTTtFQUFFO0VBRXRFLEtBQUssaUJBQ0gsT0FBTztHQUFFLEdBQUc7R0FBTyxZQUFZLE9BQU87RUFBUztFQUVqRCxLQUFLLDRCQUE0QjtHQUMvQixNQUFNLGlCQUFpQixNQUFNLFFBQVEsS0FBSyxNQUN4QyxFQUFFLE9BQU8sT0FBTyxXQUFXO0lBQUUsR0FBRztJQUFHLFFBQVEsT0FBTztHQUFVLElBQUksQ0FDbEU7R0FDQSxPQUFPO0lBQUUsR0FBRztJQUFPLFNBQVM7R0FBZTtFQUM3QztFQUVBLEtBQUssbUJBQW1CO0dBQ3RCLE1BQU0sYUFBYSxNQUFNLFFBQVEsS0FBSyxNQUNwQyxFQUFFLE9BQU8sT0FBTyxhQUFhLEtBQUssT0FBTyxlQUFlLENBQzFEO0dBQ0EsT0FBTztJQUFFLEdBQUc7SUFBTyxTQUFTO0lBQVksT0FBTyxPQUFPO0dBQVE7RUFDaEU7RUFFQSxLQUFLLHlCQUF5QjtHQUM1QixNQUFNLFlBQVksTUFBTSxRQUFRLEtBQUssTUFDbkMsRUFBRSxPQUFPLE9BQU8sY0FBYyxLQUFLLE9BQU8sZ0JBQWdCLENBQzVEO0dBQ0EsT0FBTztJQUFFLEdBQUc7SUFBTyxTQUFTO0dBQVU7RUFDeEM7RUFFQSxTQUNFLE9BQU87Q0FDWDtBQUNGOzs7O0FBTUEsT0FBTyxTQUFTLG1CQUFtQixFQUFFLFlBQVk7O0NBQy9DLE1BQU0sRUFBRSxPQUFPLG9CQUFvQixRQUFRO0NBQzNDLE1BQU0sQ0FBQyxPQUFPLFlBQVksV0FBVyxlQUFlLFlBQVk7OztDQUloRSxNQUFNLFdBQVcsT0FBTyxLQUFLO0NBQzdCLFNBQVMsVUFBVTs7Q0FHbkIsTUFBTSxVQUFVLGFBQWEsaUJBQWlCO0VBQzVDLElBQUksQ0FBQyxPQUFPO0VBRVosTUFBTSxJQUFJLFNBQVM7RUFDbkIsTUFBTSxTQUFTO0dBQ2IsTUFBTSxFQUFFLFNBQVM7R0FDakIsTUFBTSxFQUFFLFNBQVM7R0FDakIsUUFBUSxFQUFFLEtBQUs7R0FDZixXQUFXLEVBQUUsS0FBSztHQUNsQixRQUFRLEVBQUUsUUFBUTtHQUNsQixZQUFZLEVBQUUsUUFBUTtFQUN4QjtFQUNBLE1BQU0sV0FBVyxjQUFjLE1BQU07O0VBR3JDLElBQUksQ0FBQyxnQkFBZ0IsVUFBVSxJQUFJLFFBQVEsR0FBRztHQUM1QyxNQUFNLFNBQVMsVUFBVSxJQUFJLFFBQVE7R0FDckMsU0FBUztJQUFFLE1BQU07SUFBZ0IsTUFBTTtJQUFRLGNBQWM7R0FBb0IsQ0FBQztHQUNsRjtFQUNGO0VBRUEsU0FBUyxFQUFFLE1BQU0sYUFBYSxDQUFDO0VBRS9CLGtCQUFrQixPQUFPLE1BQU0sQ0FBQyxDQUM3QixNQUFNLFNBQVM7O0dBRWQsVUFBVSxJQUFJLFVBQVUsSUFBSTtHQUM1QixTQUFTO0lBQUUsTUFBTTtJQUFnQjtJQUFNLGNBQWM7R0FBdUIsQ0FBQztFQUMvRSxDQUFDLENBQUMsQ0FDRCxPQUFPLFFBQVEsU0FBUztHQUFFLE1BQU07R0FBYyxTQUFTLElBQUk7RUFBUSxDQUFDLENBQUM7Q0FDMUUsR0FBRyxDQUFDLEtBQUssQ0FBQzs7Q0FHVixNQUFNLGNBQWMsa0JBQWtCO0VBQ3BDLFFBQVEsS0FBSztDQUNmLEdBQUcsQ0FBQyxPQUFPLENBQUM7O0NBR1osTUFBTSxpQkFBaUIsa0JBQWtCO0VBQ3ZDLFFBQVEsSUFBSTtDQUNkLEdBQUcsQ0FBQyxPQUFPLENBQUM7Q0FFWixnQkFBZ0I7RUFDZCxJQUFJLGlCQUFpQjtHQUNuQixZQUFZO0VBQ2Q7Q0FDRixHQUFHLENBQUMsaUJBQWlCLFdBQVcsQ0FBQzs7Q0FHakMsTUFBTSxnQkFBZ0IsYUFBYSxVQUFVO0VBQzNDLFNBQVM7R0FBRSxNQUFNO0dBQW1CO0VBQU0sQ0FBQztFQUMzQyxTQUFTO0dBQUUsTUFBTTtHQUFZLE9BQU87RUFBRSxDQUFDO0NBQ3pDLEdBQUcsQ0FBQyxDQUFDO0NBRUwsTUFBTSxrQkFBa0IsYUFBYSxVQUFVO0VBQzdDLFNBQVM7R0FBRSxNQUFNO0dBQXFCO0VBQU0sQ0FBQztFQUM3QyxTQUFTO0dBQUUsTUFBTTtHQUFZLE9BQU87RUFBRSxDQUFDO0NBQ3pDLEdBQUcsQ0FBQyxDQUFDO0NBRUwsTUFBTSxVQUFVLGFBQWEsVUFBVTtFQUNyQyxTQUFTO0dBQUUsTUFBTTtHQUFZO0VBQU0sQ0FBQztDQUN0QyxHQUFHLENBQUMsQ0FBQztDQUVMLE1BQU0sY0FBYyxhQUFhLFVBQVU7RUFDekMsU0FBUztHQUFFLE1BQU07R0FBaUI7RUFBTSxDQUFDO0NBQzNDLEdBQUcsQ0FBQyxDQUFDO0NBRUwsTUFBTSxZQUFZLGFBQWEsVUFBVTtFQUN2QyxTQUFTO0dBQUUsTUFBTTtHQUFlO0VBQU0sQ0FBQztFQUN2QyxTQUFTO0dBQUUsTUFBTTtHQUFZLE9BQU87RUFBRSxDQUFDO0NBQ3pDLEdBQUcsQ0FBQyxDQUFDO0NBRUwsTUFBTSxtQkFBbUIsYUFBYSxVQUFVO0VBQzlDLFNBQVM7R0FBRSxNQUFNO0dBQXNCO0VBQU0sQ0FBQztFQUM5QyxTQUFTO0dBQUUsTUFBTTtHQUFZLE9BQU87RUFBRSxDQUFDO0NBQ3pDLEdBQUcsQ0FBQyxDQUFDO0NBRUwsTUFBTSxlQUFlLGFBQWEsYUFBYTtFQUM3QyxTQUFTO0dBQUUsTUFBTTtHQUFpQjtFQUFTLENBQUM7Q0FDOUMsR0FBRyxDQUFDLENBQUM7O0NBSUwsTUFBTSxxQkFBcUIsYUFBYSxVQUFVLGNBQWM7RUFDOUQsSUFBSSxDQUFDLE9BQU87RUFFWixNQUFNLElBQUksU0FBUztFQUNuQixNQUFNLGdCQUFnQixFQUFFLFFBQVEsTUFBTSxNQUFNLEVBQUUsT0FBTyxRQUFRO0VBQzdELElBQUksQ0FBQyxpQkFBaUIsY0FBYyxXQUFXLFdBQVc7O0VBRzFELE1BQU0sZUFBZSxFQUFFLEdBQUcsY0FBYzs7RUFHeEMsU0FBUztHQUFFLE1BQU07R0FBNEI7R0FBVTtFQUFVLENBQUM7O0VBR2xFLE1BQU0sVUFBVTtHQUNkLE9BQU8sY0FBYztHQUNyQixhQUFhLGNBQWM7R0FDM0IsVUFBVSxjQUFjO0dBQ3hCLFVBQVUsY0FBYztHQUN4QixRQUFRO0VBQ1Y7O0VBR0EsYUFBYSxVQUFVLE9BQU8sT0FBTyxDQUFDLENBQ25DLE1BQU0sa0JBQWtCOztHQUV2QixTQUFTO0lBQUUsTUFBTTtJQUF5QjtHQUFjLENBQUM7O0dBRXpELFVBQVUsTUFBTTtFQUNsQixDQUFDLENBQUMsQ0FDRCxPQUFPLFFBQVE7O0dBRWQsU0FBUztJQUFFLE1BQU07SUFBbUI7SUFBYyxTQUFTLElBQUk7R0FBUSxDQUFDO0VBQzFFLENBQUM7Q0FDTCxHQUFHLENBQUMsS0FBSyxDQUFDOztDQUlWLE1BQU0saUJBQWlCLGNBQ2YsTUFBTSxRQUFRLE1BQU0sTUFBTSxFQUFFLE9BQU8sTUFBTSxVQUFVLEtBQUssTUFDOUQsQ0FBQyxNQUFNLFNBQVMsTUFBTSxVQUFVLENBQ2xDOztDQUlBLE1BQU0sUUFBUSxlQUNMO0VBQ0wsR0FBRztFQUNIO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRixJQUNBO0VBQUM7RUFBTztFQUFnQjtFQUFhO0VBQWdCO0VBQWU7RUFBaUI7RUFBUztFQUFhO0VBQVc7RUFBa0I7RUFBYztDQUFrQixDQUMxSztDQUVBLE9BQU8sd0JBQUMsa0JBQWtCLFVBQW5CO0VBQW1DO0VBQVE7Q0FBcUM7Ozs7O0FBQ3pGOzs7Ozs7OztBQU1BLE9BQU8sU0FBUyxnQkFBZ0I7O0NBQzlCLE1BQU0sUUFBUSxXQUFXLGlCQUFpQjtDQUUxQyxJQUFJLENBQUMsT0FBTztFQUNWLE1BQU0sSUFBSSxNQUFNLHNEQUFzRDtDQUN4RTtDQUVBLE9BQU87QUFDVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJUaWNrZXREYXRhQ29udGV4dC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlQ2FsbGJhY2ssIHVzZUNvbnRleHQsIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlUmVkdWNlciwgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBmZXRjaFBhZ2VkVGlja2V0cywgdXBkYXRlVGlja2V0IH0gZnJvbSAnLi4vc2VydmljZXMvYXBpLmpzJztcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4vQXV0aENvbnRleHQuanN4JztcclxuXHJcbmNvbnN0IFRpY2tldERhdGFDb250ZXh0ID0gY3JlYXRlQ29udGV4dChudWxsKTtcclxuXHJcbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xyXG4vKiAgSW4tbWVtb3J5IHBhZ2UgY2FjaGUgKG1vZHVsZS1sZXZlbCwgc3Vydml2ZXMgcmUtcmVuZGVycykgICAgICAgICAgICovXHJcbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xyXG5cclxuY29uc3QgcGFnZUNhY2hlID0gbmV3IE1hcCgpO1xyXG5cclxuZnVuY3Rpb24gYnVpbGRDYWNoZUtleSh7IHBhZ2UsIHNpemUsIHNvcnRCeSwgZGlyZWN0aW9uLCBzdGF0dXMsIHNlYXJjaFRleHQgfSkge1xyXG4gIHJldHVybiBgJHtwYWdlfXwke3NpemV9fCR7c29ydEJ5fXwke2RpcmVjdGlvbn18JHtzdGF0dXMgPz8gJyd9fCR7c2VhcmNoVGV4dCA/PyAnJ31gO1xyXG59XHJcblxyXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cclxuLyogIEluaXRpYWwgc3RhdGUgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAqL1xyXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cclxuXHJcbmNvbnN0IGluaXRpYWxTdGF0ZSA9IHtcclxuICB0aWNrZXRzOiBbXSxcclxuICBzZWxlY3RlZElkOiBudWxsLFxyXG4gIGxvYWRpbmc6IGZhbHNlLFxyXG4gIGVycm9yOiAnJyxcclxuICBjYWNoZU1lc3NhZ2U6ICcnLFxyXG4gIHBhZ2VJbmZvOiB7XHJcbiAgICBwYWdlOiAwLFxyXG4gICAgc2l6ZTogNSxcclxuICAgIHRvdGFsUGFnZXM6IDAsXHJcbiAgICB0b3RhbEVsZW1lbnRzOiAwXHJcbiAgfSxcclxuICBzb3J0OiB7XHJcbiAgICBzb3J0Qnk6ICdjcmVhdGVkQXQnLFxyXG4gICAgZGlyZWN0aW9uOiAnZGVzYydcclxuICB9LFxyXG4gIGZpbHRlcnM6IHtcclxuICAgIHNlYXJjaFRleHQ6ICcnLFxyXG4gICAgc3RhdHVzRmlsdGVyOiAnJ1xyXG4gIH1cclxufTtcclxuXHJcbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xyXG4vKiAgUmVkdWNlciAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICovXHJcbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xyXG5cclxuZnVuY3Rpb24gdGlja2V0UmVkdWNlcihzdGF0ZSwgYWN0aW9uKSB7XHJcbiAgc3dpdGNoIChhY3Rpb24udHlwZSkge1xyXG4gICAgY2FzZSAnTE9BRF9TVEFSVCc6XHJcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBsb2FkaW5nOiB0cnVlLCBlcnJvcjogJycsIGNhY2hlTWVzc2FnZTogJycgfTtcclxuXHJcbiAgICBjYXNlICdMT0FEX1NVQ0NFU1MnOiB7XHJcbiAgICAgIGNvbnN0IHBhZ2VEYXRhID0gYWN0aW9uLmRhdGE7XHJcbiAgICAgIGNvbnN0IHRpY2tldHMgPSBwYWdlRGF0YS5jb250ZW50ID8/IFtdO1xyXG4gICAgICBjb25zdCBzZWxlY3RlZFN0aWxsVmlzaWJsZSA9IHRpY2tldHMuc29tZSgodCkgPT4gdC5pZCA9PT0gc3RhdGUuc2VsZWN0ZWRJZCk7XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgdGlja2V0cyxcclxuICAgICAgICBzZWxlY3RlZElkOiBzZWxlY3RlZFN0aWxsVmlzaWJsZSA/IHN0YXRlLnNlbGVjdGVkSWQgOiAodGlja2V0c1swXT8uaWQgPz8gbnVsbCksXHJcbiAgICAgICAgbG9hZGluZzogZmFsc2UsXHJcbiAgICAgICAgZXJyb3I6ICcnLFxyXG4gICAgICAgIGNhY2hlTWVzc2FnZTogYWN0aW9uLmNhY2hlTWVzc2FnZSA/PyAnJyxcclxuICAgICAgICBwYWdlSW5mbzoge1xyXG4gICAgICAgICAgcGFnZTogcGFnZURhdGEubnVtYmVyID8/IHN0YXRlLnBhZ2VJbmZvLnBhZ2UsXHJcbiAgICAgICAgICBzaXplOiBwYWdlRGF0YS5zaXplID8/IHN0YXRlLnBhZ2VJbmZvLnNpemUsXHJcbiAgICAgICAgICB0b3RhbFBhZ2VzOiBwYWdlRGF0YS50b3RhbFBhZ2VzID8/IDAsXHJcbiAgICAgICAgICB0b3RhbEVsZW1lbnRzOiBwYWdlRGF0YS50b3RhbEVsZW1lbnRzID8/IDBcclxuICAgICAgICB9XHJcbiAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgY2FzZSAnTE9BRF9FUlJPUic6XHJcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBsb2FkaW5nOiBmYWxzZSwgZXJyb3I6IGFjdGlvbi5tZXNzYWdlLCBjYWNoZU1lc3NhZ2U6ICcnIH07XHJcblxyXG4gICAgY2FzZSAnU0VUX0NBQ0hFX01FU1NBR0UnOlxyXG4gICAgICByZXR1cm4geyAuLi5zdGF0ZSwgY2FjaGVNZXNzYWdlOiBhY3Rpb24udmFsdWUgfTtcclxuXHJcbiAgICBjYXNlICdTRVRfU0VBUkNIX1RFWFQnOlxyXG4gICAgICByZXR1cm4geyAuLi5zdGF0ZSwgZmlsdGVyczogeyAuLi5zdGF0ZS5maWx0ZXJzLCBzZWFyY2hUZXh0OiBhY3Rpb24udmFsdWUgfSB9O1xyXG5cclxuICAgIGNhc2UgJ1NFVF9TVEFUVVNfRklMVEVSJzpcclxuICAgICAgcmV0dXJuIHsgLi4uc3RhdGUsIGZpbHRlcnM6IHsgLi4uc3RhdGUuZmlsdGVycywgc3RhdHVzRmlsdGVyOiBhY3Rpb24udmFsdWUgfSB9O1xyXG5cclxuICAgIGNhc2UgJ1NFVF9QQUdFJzpcclxuICAgICAgcmV0dXJuIHsgLi4uc3RhdGUsIHBhZ2VJbmZvOiB7IC4uLnN0YXRlLnBhZ2VJbmZvLCBwYWdlOiBhY3Rpb24udmFsdWUgfSB9O1xyXG5cclxuICAgIGNhc2UgJ1NFVF9QQUdFX1NJWkUnOlxyXG4gICAgICByZXR1cm4geyAuLi5zdGF0ZSwgcGFnZUluZm86IHsgLi4uc3RhdGUucGFnZUluZm8sIHNpemU6IGFjdGlvbi52YWx1ZSwgcGFnZTogMCB9IH07XHJcblxyXG4gICAgY2FzZSAnU0VUX1NPUlRfQlknOlxyXG4gICAgICByZXR1cm4geyAuLi5zdGF0ZSwgc29ydDogeyAuLi5zdGF0ZS5zb3J0LCBzb3J0Qnk6IGFjdGlvbi52YWx1ZSB9IH07XHJcblxyXG4gICAgY2FzZSAnU0VUX1NPUlRfRElSRUNUSU9OJzpcclxuICAgICAgcmV0dXJuIHsgLi4uc3RhdGUsIHNvcnQ6IHsgLi4uc3RhdGUuc29ydCwgZGlyZWN0aW9uOiBhY3Rpb24udmFsdWUgfSB9O1xyXG5cclxuICAgIGNhc2UgJ1NFTEVDVF9USUNLRVQnOlxyXG4gICAgICByZXR1cm4geyAuLi5zdGF0ZSwgc2VsZWN0ZWRJZDogYWN0aW9uLnRpY2tldElkIH07XHJcblxyXG4gICAgY2FzZSAnT1BUSU1JU1RJQ19TVEFUVVNfVVBEQVRFJzoge1xyXG4gICAgICBjb25zdCB1cGRhdGVkVGlja2V0cyA9IHN0YXRlLnRpY2tldHMubWFwKCh0KSA9PlxyXG4gICAgICAgIHQuaWQgPT09IGFjdGlvbi50aWNrZXRJZCA/IHsgLi4udCwgc3RhdHVzOiBhY3Rpb24ubmV3U3RhdHVzIH0gOiB0XHJcbiAgICAgICk7XHJcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCB0aWNrZXRzOiB1cGRhdGVkVGlja2V0cyB9O1xyXG4gICAgfVxyXG5cclxuICAgIGNhc2UgJ1JPTExCQUNLX1NUQVRVUyc6IHtcclxuICAgICAgY29uc3Qgcm9sbGVkQmFjayA9IHN0YXRlLnRpY2tldHMubWFwKCh0KSA9PlxyXG4gICAgICAgIHQuaWQgPT09IGFjdGlvbi5iYWNrdXBUaWNrZXQuaWQgPyBhY3Rpb24uYmFja3VwVGlja2V0IDogdFxyXG4gICAgICApO1xyXG4gICAgICByZXR1cm4geyAuLi5zdGF0ZSwgdGlja2V0czogcm9sbGVkQmFjaywgZXJyb3I6IGFjdGlvbi5tZXNzYWdlIH07XHJcbiAgICB9XHJcblxyXG4gICAgY2FzZSAnQ09ORklSTV9TVEFUVVNfVVBEQVRFJzoge1xyXG4gICAgICBjb25zdCBjb25maXJtZWQgPSBzdGF0ZS50aWNrZXRzLm1hcCgodCkgPT5cclxuICAgICAgICB0LmlkID09PSBhY3Rpb24udXBkYXRlZFRpY2tldC5pZCA/IGFjdGlvbi51cGRhdGVkVGlja2V0IDogdFxyXG4gICAgICApO1xyXG4gICAgICByZXR1cm4geyAuLi5zdGF0ZSwgdGlja2V0czogY29uZmlybWVkIH07XHJcbiAgICB9XHJcblxyXG4gICAgZGVmYXVsdDpcclxuICAgICAgcmV0dXJuIHN0YXRlO1xyXG4gIH1cclxufVxyXG5cclxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXHJcbi8qICBQcm92aWRlciAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKi9cclxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gVGlja2V0RGF0YVByb3ZpZGVyKHsgY2hpbGRyZW4gfSkge1xyXG4gIGNvbnN0IHsgdG9rZW4sIGlzQXV0aGVudGljYXRlZCB9ID0gdXNlQXV0aCgpO1xyXG4gIGNvbnN0IFtzdGF0ZSwgZGlzcGF0Y2hdID0gdXNlUmVkdWNlcih0aWNrZXRSZWR1Y2VyLCBpbml0aWFsU3RhdGUpO1xyXG5cclxuICAvKiBVc2UgYSByZWYgdG8gYWx3YXlzIGhhdmUgdGhlIGxhdGVzdCBzdGF0ZSBpbnNpZGUgbG9hZFRpY2tldHNcclxuICAgICB3aXRob3V0IHJlLWNyZWF0aW5nIHRoZSBjYWxsYmFjayBvbiBldmVyeSBzdGF0ZSBjaGFuZ2UuICAgICAgICAgKi9cclxuICBjb25zdCBzdGF0ZVJlZiA9IHVzZVJlZihzdGF0ZSk7XHJcbiAgc3RhdGVSZWYuY3VycmVudCA9IHN0YXRlO1xyXG5cclxuICAvKiBDb3JlIGZldGNoIGhlbHBlciDigJMgY2FsbGVkIGJ5IGJvdGggbG9hZFRpY2tldHMgYW5kIHJlZnJlc2hUaWNrZXRzICovXHJcbiAgY29uc3QgZG9GZXRjaCA9IHVzZUNhbGxiYWNrKChmb3JjZVJlZnJlc2gpID0+IHtcclxuICAgIGlmICghdG9rZW4pIHJldHVybjtcclxuXHJcbiAgICBjb25zdCBzID0gc3RhdGVSZWYuY3VycmVudDtcclxuICAgIGNvbnN0IHBhcmFtcyA9IHtcclxuICAgICAgcGFnZTogcy5wYWdlSW5mby5wYWdlLFxyXG4gICAgICBzaXplOiBzLnBhZ2VJbmZvLnNpemUsXHJcbiAgICAgIHNvcnRCeTogcy5zb3J0LnNvcnRCeSxcclxuICAgICAgZGlyZWN0aW9uOiBzLnNvcnQuZGlyZWN0aW9uLFxyXG4gICAgICBzdGF0dXM6IHMuZmlsdGVycy5zdGF0dXNGaWx0ZXIsXHJcbiAgICAgIHNlYXJjaFRleHQ6IHMuZmlsdGVycy5zZWFyY2hUZXh0XHJcbiAgICB9O1xyXG4gICAgY29uc3QgY2FjaGVLZXkgPSBidWlsZENhY2hlS2V5KHBhcmFtcyk7XHJcblxyXG4gICAgLy8gQ2hlY2sgY2FjaGUgZmlyc3QgKHVubGVzcyBmb3JjZS1yZWZyZXNoKVxyXG4gICAgaWYgKCFmb3JjZVJlZnJlc2ggJiYgcGFnZUNhY2hlLmhhcyhjYWNoZUtleSkpIHtcclxuICAgICAgY29uc3QgY2FjaGVkID0gcGFnZUNhY2hlLmdldChjYWNoZUtleSk7XHJcbiAgICAgIGRpc3BhdGNoKHsgdHlwZTogJ0xPQURfU1VDQ0VTUycsIGRhdGE6IGNhY2hlZCwgY2FjaGVNZXNzYWdlOiAnTG9hZGVkIGZyb20gY2FjaGUnIH0pO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgZGlzcGF0Y2goeyB0eXBlOiAnTE9BRF9TVEFSVCcgfSk7XHJcblxyXG4gICAgZmV0Y2hQYWdlZFRpY2tldHModG9rZW4sIHBhcmFtcylcclxuICAgICAgLnRoZW4oKGRhdGEpID0+IHtcclxuICAgICAgICAvLyBTdG9yZSBpbiBjYWNoZVxyXG4gICAgICAgIHBhZ2VDYWNoZS5zZXQoY2FjaGVLZXksIGRhdGEpO1xyXG4gICAgICAgIGRpc3BhdGNoKHsgdHlwZTogJ0xPQURfU1VDQ0VTUycsIGRhdGEsIGNhY2hlTWVzc2FnZTogJ0ZldGNoZWQgZnJvbSBiYWNrZW5kJyB9KTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnIpID0+IGRpc3BhdGNoKHsgdHlwZTogJ0xPQURfRVJST1InLCBtZXNzYWdlOiBlcnIubWVzc2FnZSB9KSk7XHJcbiAgfSwgW3Rva2VuXSk7XHJcblxyXG4gIC8qIExvYWQgdGlja2V0cyDigJMgdXNlcyBjYWNoZSB3aGVuIGF2YWlsYWJsZSAqL1xyXG4gIGNvbnN0IGxvYWRUaWNrZXRzID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xyXG4gICAgZG9GZXRjaChmYWxzZSk7XHJcbiAgfSwgW2RvRmV0Y2hdKTtcclxuXHJcbiAgLyogUmVmcmVzaCDigJMgYWx3YXlzIGZldGNoZXMgZnJvbSBiYWNrZW5kLCB1cGRhdGVzIGNhY2hlICovXHJcbiAgY29uc3QgcmVmcmVzaFRpY2tldHMgPSB1c2VDYWxsYmFjaygoKSA9PiB7XHJcbiAgICBkb0ZldGNoKHRydWUpO1xyXG4gIH0sIFtkb0ZldGNoXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoaXNBdXRoZW50aWNhdGVkKSB7XHJcbiAgICAgIGxvYWRUaWNrZXRzKCk7XHJcbiAgICB9XHJcbiAgfSwgW2lzQXV0aGVudGljYXRlZCwgbG9hZFRpY2tldHNdKTtcclxuXHJcbiAgLyogU3RhYmxlIGFjdGlvbiBkaXNwYXRjaGVycyAqL1xyXG4gIGNvbnN0IHNldFNlYXJjaFRleHQgPSB1c2VDYWxsYmFjaygodmFsdWUpID0+IHtcclxuICAgIGRpc3BhdGNoKHsgdHlwZTogJ1NFVF9TRUFSQ0hfVEVYVCcsIHZhbHVlIH0pO1xyXG4gICAgZGlzcGF0Y2goeyB0eXBlOiAnU0VUX1BBR0UnLCB2YWx1ZTogMCB9KTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IHNldFN0YXR1c0ZpbHRlciA9IHVzZUNhbGxiYWNrKCh2YWx1ZSkgPT4ge1xyXG4gICAgZGlzcGF0Y2goeyB0eXBlOiAnU0VUX1NUQVRVU19GSUxURVInLCB2YWx1ZSB9KTtcclxuICAgIGRpc3BhdGNoKHsgdHlwZTogJ1NFVF9QQUdFJywgdmFsdWU6IDAgfSk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBzZXRQYWdlID0gdXNlQ2FsbGJhY2soKHZhbHVlKSA9PiB7XHJcbiAgICBkaXNwYXRjaCh7IHR5cGU6ICdTRVRfUEFHRScsIHZhbHVlIH0pO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3Qgc2V0UGFnZVNpemUgPSB1c2VDYWxsYmFjaygodmFsdWUpID0+IHtcclxuICAgIGRpc3BhdGNoKHsgdHlwZTogJ1NFVF9QQUdFX1NJWkUnLCB2YWx1ZSB9KTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IHNldFNvcnRCeSA9IHVzZUNhbGxiYWNrKCh2YWx1ZSkgPT4ge1xyXG4gICAgZGlzcGF0Y2goeyB0eXBlOiAnU0VUX1NPUlRfQlknLCB2YWx1ZSB9KTtcclxuICAgIGRpc3BhdGNoKHsgdHlwZTogJ1NFVF9QQUdFJywgdmFsdWU6IDAgfSk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBzZXRTb3J0RGlyZWN0aW9uID0gdXNlQ2FsbGJhY2soKHZhbHVlKSA9PiB7XHJcbiAgICBkaXNwYXRjaCh7IHR5cGU6ICdTRVRfU09SVF9ESVJFQ1RJT04nLCB2YWx1ZSB9KTtcclxuICAgIGRpc3BhdGNoKHsgdHlwZTogJ1NFVF9QQUdFJywgdmFsdWU6IDAgfSk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBzZWxlY3RUaWNrZXQgPSB1c2VDYWxsYmFjaygodGlja2V0SWQpID0+IHtcclxuICAgIGRpc3BhdGNoKHsgdHlwZTogJ1NFTEVDVF9USUNLRVQnLCB0aWNrZXRJZCB9KTtcclxuICB9LCBbXSk7XHJcblxyXG4gIC8qIE9wdGltaXN0aWMgc3RhdHVzIHVwZGF0ZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXHJcblxyXG4gIGNvbnN0IHVwZGF0ZVRpY2tldFN0YXR1cyA9IHVzZUNhbGxiYWNrKCh0aWNrZXRJZCwgbmV3U3RhdHVzKSA9PiB7XHJcbiAgICBpZiAoIXRva2VuKSByZXR1cm47XHJcblxyXG4gICAgY29uc3QgcyA9IHN0YXRlUmVmLmN1cnJlbnQ7XHJcbiAgICBjb25zdCBjdXJyZW50VGlja2V0ID0gcy50aWNrZXRzLmZpbmQoKHQpID0+IHQuaWQgPT09IHRpY2tldElkKTtcclxuICAgIGlmICghY3VycmVudFRpY2tldCB8fCBjdXJyZW50VGlja2V0LnN0YXR1cyA9PT0gbmV3U3RhdHVzKSByZXR1cm47XHJcblxyXG4gICAgLy8gMS4gU2F2ZSBiYWNrdXBcclxuICAgIGNvbnN0IGJhY2t1cFRpY2tldCA9IHsgLi4uY3VycmVudFRpY2tldCB9O1xyXG5cclxuICAgIC8vIDIuIFVwZGF0ZSBVSSBpbW1lZGlhdGVseSAob3B0aW1pc3RpYylcclxuICAgIGRpc3BhdGNoKHsgdHlwZTogJ09QVElNSVNUSUNfU1RBVFVTX1VQREFURScsIHRpY2tldElkLCBuZXdTdGF0dXMgfSk7XHJcblxyXG4gICAgLy8gMy4gQnVpbGQgcGF5bG9hZCBmb3IgUFVUIHJlcXVlc3RcclxuICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbiAgICAgIHRpdGxlOiBjdXJyZW50VGlja2V0LnRpdGxlLFxyXG4gICAgICBkZXNjcmlwdGlvbjogY3VycmVudFRpY2tldC5kZXNjcmlwdGlvbixcclxuICAgICAgY2F0ZWdvcnk6IGN1cnJlbnRUaWNrZXQuY2F0ZWdvcnksXHJcbiAgICAgIHByaW9yaXR5OiBjdXJyZW50VGlja2V0LnByaW9yaXR5LFxyXG4gICAgICBzdGF0dXM6IG5ld1N0YXR1c1xyXG4gICAgfTtcclxuXHJcbiAgICAvLyA0LiBTZW5kIFBVVCByZXF1ZXN0XHJcbiAgICB1cGRhdGVUaWNrZXQodGlja2V0SWQsIHRva2VuLCBwYXlsb2FkKVxyXG4gICAgICAudGhlbigodXBkYXRlZFRpY2tldCkgPT4ge1xyXG4gICAgICAgIC8vIDVhLiBTdWNjZXNzIOKAkyByZXBsYWNlIG9wdGltaXN0aWMgZGF0YSB3aXRoIGJhY2tlbmQgcmVzcG9uc2VcclxuICAgICAgICBkaXNwYXRjaCh7IHR5cGU6ICdDT05GSVJNX1NUQVRVU19VUERBVEUnLCB1cGRhdGVkVGlja2V0IH0pO1xyXG4gICAgICAgIC8vIEludmFsaWRhdGUgcGFnZSBjYWNoZSBzaW5jZSBkYXRhIGNoYW5nZWRcclxuICAgICAgICBwYWdlQ2FjaGUuY2xlYXIoKTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnIpID0+IHtcclxuICAgICAgICAvLyA1Yi4gRmFpbHVyZSDigJMgcm9sbCBiYWNrIHRvIGJhY2t1cFxyXG4gICAgICAgIGRpc3BhdGNoKHsgdHlwZTogJ1JPTExCQUNLX1NUQVRVUycsIGJhY2t1cFRpY2tldCwgbWVzc2FnZTogZXJyLm1lc3NhZ2UgfSk7XHJcbiAgICAgIH0pO1xyXG4gIH0sIFt0b2tlbl0pO1xyXG5cclxuICAvKiBEZXJpdmVkIHZhbHVlcyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXHJcblxyXG4gIGNvbnN0IHNlbGVjdGVkVGlja2V0ID0gdXNlTWVtbyhcclxuICAgICgpID0+IHN0YXRlLnRpY2tldHMuZmluZCgodCkgPT4gdC5pZCA9PT0gc3RhdGUuc2VsZWN0ZWRJZCkgPz8gbnVsbCxcclxuICAgIFtzdGF0ZS50aWNrZXRzLCBzdGF0ZS5zZWxlY3RlZElkXVxyXG4gICk7XHJcblxyXG4gIC8qIENvbnRleHQgdmFsdWUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cclxuXHJcbiAgY29uc3QgdmFsdWUgPSB1c2VNZW1vKFxyXG4gICAgKCkgPT4gKHtcclxuICAgICAgLi4uc3RhdGUsXHJcbiAgICAgIHNlbGVjdGVkVGlja2V0LFxyXG4gICAgICBsb2FkVGlja2V0cyxcclxuICAgICAgcmVmcmVzaFRpY2tldHMsXHJcbiAgICAgIHNldFNlYXJjaFRleHQsXHJcbiAgICAgIHNldFN0YXR1c0ZpbHRlcixcclxuICAgICAgc2V0UGFnZSxcclxuICAgICAgc2V0UGFnZVNpemUsXHJcbiAgICAgIHNldFNvcnRCeSxcclxuICAgICAgc2V0U29ydERpcmVjdGlvbixcclxuICAgICAgc2VsZWN0VGlja2V0LFxyXG4gICAgICB1cGRhdGVUaWNrZXRTdGF0dXNcclxuICAgIH0pLFxyXG4gICAgW3N0YXRlLCBzZWxlY3RlZFRpY2tldCwgbG9hZFRpY2tldHMsIHJlZnJlc2hUaWNrZXRzLCBzZXRTZWFyY2hUZXh0LCBzZXRTdGF0dXNGaWx0ZXIsIHNldFBhZ2UsIHNldFBhZ2VTaXplLCBzZXRTb3J0QnksIHNldFNvcnREaXJlY3Rpb24sIHNlbGVjdFRpY2tldCwgdXBkYXRlVGlja2V0U3RhdHVzXVxyXG4gICk7XHJcblxyXG4gIHJldHVybiA8VGlja2V0RGF0YUNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3ZhbHVlfT57Y2hpbGRyZW59PC9UaWNrZXREYXRhQ29udGV4dC5Qcm92aWRlcj47XHJcbn1cclxuXHJcbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xyXG4vKiAgSG9vayAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICovXHJcbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHVzZVRpY2tldERhdGEoKSB7XHJcbiAgY29uc3QgdmFsdWUgPSB1c2VDb250ZXh0KFRpY2tldERhdGFDb250ZXh0KTtcclxuXHJcbiAgaWYgKCF2YWx1ZSkge1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKCd1c2VUaWNrZXREYXRhIG11c3QgYmUgdXNlZCBpbnNpZGUgVGlja2V0RGF0YVByb3ZpZGVyJyk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gdmFsdWU7XHJcbn1cclxuIl19