import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ProtectedRoute.jsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { Navigate, useLocation } from "/node_modules/.vite/deps/react-router.js?v=3927c5ff";
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/ProtectedRoute.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3927c5ff";
var _s = $RefreshSig$();
export default function ProtectedRoute({ children }) {
	_s();
	const { isAuthenticated } = useAuth();
	const location = useLocation();
	if (!isAuthenticated) {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/login",
			replace: true,
			state: { from: location }
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 12
		}, this);
	}
	return children;
}
_s(ProtectedRoute, "x2bl+jc97H3E+NXGUiZa4WBKcE8=", false, function() {
	return [useAuth, useLocation];
});
_c = ProtectedRoute;
var _c;
$RefreshReg$(_c, "ProtectedRoute");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ProtectedRoute.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/ProtectedRoute.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/ProtectedRoute.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/ProtectedRoute.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLG1CQUFtQjtBQUN0QyxTQUFTLGVBQWU7Ozs7QUFFeEIsZUFBZSxTQUFTLGVBQWUsRUFBRSxZQUFZOztDQUNuRCxNQUFNLEVBQUUsb0JBQW9CLFFBQVE7Q0FDcEMsTUFBTSxXQUFXLFlBQVk7Q0FFN0IsSUFBSSxDQUFDLGlCQUFpQjtFQUNwQixPQUFPLHdCQUFDLFVBQUQ7R0FBVSxJQUFHO0dBQVM7R0FBUSxPQUFPLEVBQUUsTUFBTSxTQUFTO0VBQUk7Ozs7O0NBQ25FO0NBRUEsT0FBTztBQUNUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlByb3RlY3RlZFJvdXRlLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOYXZpZ2F0ZSwgdXNlTG9jYXRpb24gfSBmcm9tICdyZWFjdC1yb3V0ZXInO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uL2NvbnRleHQvQXV0aENvbnRleHQuanN4JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUHJvdGVjdGVkUm91dGUoeyBjaGlsZHJlbiB9KSB7XG4gIGNvbnN0IHsgaXNBdXRoZW50aWNhdGVkIH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcblxuICBpZiAoIWlzQXV0aGVudGljYXRlZCkge1xuICAgIHJldHVybiA8TmF2aWdhdGUgdG89XCIvbG9naW5cIiByZXBsYWNlIHN0YXRlPXt7IGZyb206IGxvY2F0aW9uIH19IC8+O1xuICB9XG5cbiAgcmV0dXJuIGNoaWxkcmVuO1xufVxuIl19