import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TicketDetail.jsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import { Link } from "/node_modules/.vite/deps/react-router.js?v=3927c5ff";
import PriorityBadge from "/src/components/PriorityBadge.jsx";
import StatusBadge from "/src/components/StatusBadge.jsx";
import { useTicketData } from "/src/context/TicketDataContext.jsx";
var _jsxFileName = "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/TicketDetail.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3927c5ff";
var _s = $RefreshSig$();
const QUICK_STATUSES = [
	"OPEN",
	"IN_PROGRESS",
	"CLOSED"
];
export default function TicketDetail({ ticket }) {
	_s();
	const { updateTicketStatus } = useTicketData();
	if (!ticket) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "ticket-detail empty-detail",
			children: /* @__PURE__ */ _jsxDEV("p", { children: "Select a ticket to view details" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 13,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "ticket-detail",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "detail-header",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "ticket-id",
					children: ticket.id
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "detail-badges",
					children: [/* @__PURE__ */ _jsxDEV(PriorityBadge, { priority: ticket.priority }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 24,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(StatusBadge, { status: ticket.status }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 23,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "detail-title",
				children: ticket.title
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("dl", {
				className: "detail-fields",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "detail-row",
						children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Category" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 33,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("dd", { children: ticket.category }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 34,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "detail-row",
						children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Created By" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 37,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("dd", { children: ticket.createdBy }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 38,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 36,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "detail-row",
						children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Created At" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 41,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("dd", { children: String(ticket.createdAt ?? "").replace("T", " ").slice(0, 16) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 42,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "detail-row",
						children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Priority" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 45,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("dd", { children: ticket.priority }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "detail-row",
						children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Status" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 49,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("dd", { children: ticket.status }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 50,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "status-quick-update",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "status-quick-label",
					children: "Quick status:"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "status-btn-group",
					children: QUICK_STATUSES.map((status) => /* @__PURE__ */ _jsxDEV("button", {
						className: `status-btn ${ticket.status === status ? "status-btn-active" : ""}`,
						onClick: () => updateTicketStatus(ticket.id, status),
						disabled: ticket.status === status,
						children: status === "IN_PROGRESS" ? "In Progress" : status.charAt(0) + status.slice(1).toLowerCase()
					}, status, false, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "form-actions",
				children: /* @__PURE__ */ _jsxDEV(Link, {
					to: `/app/tickets/${ticket.id}/edit`,
					className: "button-link secondary",
					children: "Edit Ticket"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 5
	}, this);
}
_s(TicketDetail, "fGwp9ddqkBvGHsB7LBwkgWz8jkY=", false, function() {
	return [useTicketData];
});
_c = TicketDetail;
var _c;
$RefreshReg$(_c, "TicketDetail");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/TicketDetail.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/TicketDetail.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/TicketDetail.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/TicketDetail.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBQ3JCLE9BQU8sbUJBQW1CO0FBQzFCLE9BQU8saUJBQWlCO0FBQ3hCLFNBQVMscUJBQXFCOzs7O0FBRTlCLE1BQU0saUJBQWlCO0NBQUM7Q0FBUTtDQUFlO0FBQVE7QUFFdkQsZUFBZSxTQUFTLGFBQWEsRUFBRSxVQUFVOztDQUMvQyxNQUFNLEVBQUUsdUJBQXVCLGNBQWM7Q0FFN0MsSUFBSSxDQUFDLFFBQVE7RUFDWCxPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsS0FBRCxZQUFHLGtDQUFrQzs7Ozs7RUFDbEM7Ozs7O0NBRVQ7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBYSxPQUFPO0lBQVM7Ozs7Y0FDN0Msd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLGVBQUQsRUFBZSxVQUFVLE9BQU8sU0FBVzs7OztlQUMzQyx3QkFBQyxhQUFELEVBQWEsUUFBUSxPQUFPLE9BQVM7Ozs7YUFDbEM7Ozs7O1lBQ0Y7Ozs7OztHQUVMLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQWdCLE9BQU87R0FBVTs7Ozs7R0FFL0Msd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBZDtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRCxZQUFJLFdBQVk7Ozs7Z0JBQ2hCLHdCQUFDLE1BQUQsWUFBSyxPQUFPLFNBQWE7Ozs7Y0FDdEI7Ozs7OztLQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRCxZQUFJLGFBQWM7Ozs7Z0JBQ2xCLHdCQUFDLE1BQUQsWUFBSyxPQUFPLFVBQWM7Ozs7Y0FDdkI7Ozs7OztLQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRCxZQUFJLGFBQWM7Ozs7Z0JBQ2xCLHdCQUFDLE1BQUQsWUFBSyxPQUFPLE9BQU8sYUFBYSxFQUFFLENBQUMsQ0FBQyxRQUFRLEtBQUssR0FBRyxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUUsRUFBTTs7OztjQUNwRTs7Ozs7O0tBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFELFlBQUksV0FBWTs7OztnQkFDaEIsd0JBQUMsTUFBRCxZQUFLLE9BQU8sU0FBYTs7OztjQUN0Qjs7Ozs7O0tBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFELFlBQUksU0FBVTs7OztnQkFDZCx3QkFBQyxNQUFELFlBQUssT0FBTyxPQUFXOzs7O2NBQ3BCOzs7Ozs7SUFDSDs7Ozs7O0dBRUosd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQXFCO0lBQW1COzs7O2NBQ3hELHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osZUFBZSxLQUFLLFdBQ25CLHdCQUFDLFVBQUQ7TUFFRSxXQUFXLGNBQWMsT0FBTyxXQUFXLFNBQVMsc0JBQXNCO01BQzFFLGVBQWUsbUJBQW1CLE9BQU8sSUFBSSxNQUFNO01BQ25ELFVBQVUsT0FBTyxXQUFXO2dCQUUzQixXQUFXLGdCQUFnQixnQkFBZ0IsT0FBTyxPQUFPLENBQUMsSUFBSSxPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsWUFBWTtLQUNyRixHQU5EOzs7O1lBTUMsQ0FDVDtJQUNFOzs7O1lBQ0Y7Ozs7OztHQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsTUFBRDtLQUFNLElBQUksZ0JBQWdCLE9BQU8sR0FBRztLQUFRLFdBQVU7ZUFBd0I7SUFFeEU7Ozs7O0dBQ0g7Ozs7O0VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlRpY2tldERldGFpbC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlcic7XG5pbXBvcnQgUHJpb3JpdHlCYWRnZSBmcm9tICcuL1ByaW9yaXR5QmFkZ2UuanN4JztcbmltcG9ydCBTdGF0dXNCYWRnZSBmcm9tICcuL1N0YXR1c0JhZGdlLmpzeCc7XG5pbXBvcnQgeyB1c2VUaWNrZXREYXRhIH0gZnJvbSAnLi4vY29udGV4dC9UaWNrZXREYXRhQ29udGV4dC5qc3gnO1xuXG5jb25zdCBRVUlDS19TVEFUVVNFUyA9IFsnT1BFTicsICdJTl9QUk9HUkVTUycsICdDTE9TRUQnXTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gVGlja2V0RGV0YWlsKHsgdGlja2V0IH0pIHtcbiAgY29uc3QgeyB1cGRhdGVUaWNrZXRTdGF0dXMgfSA9IHVzZVRpY2tldERhdGEoKTtcblxuICBpZiAoIXRpY2tldCkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldC1kZXRhaWwgZW1wdHktZGV0YWlsXCI+XG4gICAgICAgIDxwPlNlbGVjdCBhIHRpY2tldCB0byB2aWV3IGRldGFpbHM8L3A+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldC1kZXRhaWxcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGV0YWlsLWhlYWRlclwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0aWNrZXQtaWRcIj57dGlja2V0LmlkfTwvc3Bhbj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZXRhaWwtYmFkZ2VzXCI+XG4gICAgICAgICAgPFByaW9yaXR5QmFkZ2UgcHJpb3JpdHk9e3RpY2tldC5wcmlvcml0eX0gLz5cbiAgICAgICAgICA8U3RhdHVzQmFkZ2Ugc3RhdHVzPXt0aWNrZXQuc3RhdHVzfSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8aDIgY2xhc3NOYW1lPVwiZGV0YWlsLXRpdGxlXCI+e3RpY2tldC50aXRsZX08L2gyPlxuXG4gICAgICA8ZGwgY2xhc3NOYW1lPVwiZGV0YWlsLWZpZWxkc1wiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRldGFpbC1yb3dcIj5cbiAgICAgICAgICA8ZHQ+Q2F0ZWdvcnk8L2R0PlxuICAgICAgICAgIDxkZD57dGlja2V0LmNhdGVnb3J5fTwvZGQ+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRldGFpbC1yb3dcIj5cbiAgICAgICAgICA8ZHQ+Q3JlYXRlZCBCeTwvZHQ+XG4gICAgICAgICAgPGRkPnt0aWNrZXQuY3JlYXRlZEJ5fTwvZGQ+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRldGFpbC1yb3dcIj5cbiAgICAgICAgICA8ZHQ+Q3JlYXRlZCBBdDwvZHQ+XG4gICAgICAgICAgPGRkPntTdHJpbmcodGlja2V0LmNyZWF0ZWRBdCA/PyAnJykucmVwbGFjZSgnVCcsICcgJykuc2xpY2UoMCwgMTYpfTwvZGQ+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRldGFpbC1yb3dcIj5cbiAgICAgICAgICA8ZHQ+UHJpb3JpdHk8L2R0PlxuICAgICAgICAgIDxkZD57dGlja2V0LnByaW9yaXR5fTwvZGQ+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRldGFpbC1yb3dcIj5cbiAgICAgICAgICA8ZHQ+U3RhdHVzPC9kdD5cbiAgICAgICAgICA8ZGQ+e3RpY2tldC5zdGF0dXN9PC9kZD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2RsPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0YXR1cy1xdWljay11cGRhdGVcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3RhdHVzLXF1aWNrLWxhYmVsXCI+UXVpY2sgc3RhdHVzOjwvc3Bhbj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGF0dXMtYnRuLWdyb3VwXCI+XG4gICAgICAgICAge1FVSUNLX1NUQVRVU0VTLm1hcCgoc3RhdHVzKSA9PiAoXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIGtleT17c3RhdHVzfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BzdGF0dXMtYnRuICR7dGlja2V0LnN0YXR1cyA9PT0gc3RhdHVzID8gJ3N0YXR1cy1idG4tYWN0aXZlJyA6ICcnfWB9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZVRpY2tldFN0YXR1cyh0aWNrZXQuaWQsIHN0YXR1cyl9XG4gICAgICAgICAgICAgIGRpc2FibGVkPXt0aWNrZXQuc3RhdHVzID09PSBzdGF0dXN9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtzdGF0dXMgPT09ICdJTl9QUk9HUkVTUycgPyAnSW4gUHJvZ3Jlc3MnIDogc3RhdHVzLmNoYXJBdCgwKSArIHN0YXR1cy5zbGljZSgxKS50b0xvd2VyQ2FzZSgpfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1hY3Rpb25zXCI+XG4gICAgICAgIDxMaW5rIHRvPXtgL2FwcC90aWNrZXRzLyR7dGlja2V0LmlkfS9lZGl0YH0gY2xhc3NOYW1lPVwiYnV0dG9uLWxpbmsgc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgRWRpdCBUaWNrZXRcbiAgICAgICAgPC9MaW5rPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXX0=