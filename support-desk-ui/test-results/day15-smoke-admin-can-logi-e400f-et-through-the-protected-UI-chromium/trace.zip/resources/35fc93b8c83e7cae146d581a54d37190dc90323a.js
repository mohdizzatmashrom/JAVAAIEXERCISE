const StrictMode = __vite__cjsImport0_react["StrictMode"];const createRoot = __vite__cjsImport1_reactDom_client["createRoot"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=3927c5ff";
import __vite__cjsImport1_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=3927c5ff";
import { BrowserRouter } from "/node_modules/.vite/deps/react-router.js?v=3927c5ff";
import "/src/index.css";
import App from "/src/App.jsx";
import { AuthProvider } from "/src/context/AuthContext.jsx";
import { TicketDataProvider } from "/src/context/TicketDataContext.jsx";
var _jsxFileName = "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/main.jsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3927c5ff";
createRoot(document.getElementById("root")).render(/* @__PURE__ */ _jsxDEV(StrictMode, { children: /* @__PURE__ */ _jsxDEV(BrowserRouter, { children: /* @__PURE__ */ _jsxDEV(AuthProvider, { children: /* @__PURE__ */ _jsxDEV(TicketDataProvider, { children: /* @__PURE__ */ _jsxDEV(App, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 14,
	columnNumber: 11
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 13,
	columnNumber: 9
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 12,
	columnNumber: 7
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 11,
	columnNumber: 5
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 10,
	columnNumber: 3
}, this));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxxQkFBcUI7QUFDOUIsT0FBTztBQUNQLE9BQU8sU0FBUztBQUNoQixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLDBCQUEwQjs7O0FBRW5DLFdBQVcsU0FBUyxlQUFlLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FDMUMsd0JBQUMsWUFBRCxZQUNFLHdCQUFDLGVBQUQsWUFDRSx3QkFBQyxjQUFELFlBQ0Usd0JBQUMsb0JBQUQsWUFDRSx3QkFBQyxLQUFELENBQU07Ozs7U0FDWTs7OztTQUNSOzs7O1NBQ0Q7Ozs7U0FDTDs7OztRQUNkIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIm1haW4uanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFN0cmljdE1vZGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBjcmVhdGVSb290IH0gZnJvbSAncmVhY3QtZG9tL2NsaWVudCc7XG5pbXBvcnQgeyBCcm93c2VyUm91dGVyIH0gZnJvbSAncmVhY3Qtcm91dGVyJztcbmltcG9ydCAnLi9pbmRleC5jc3MnO1xuaW1wb3J0IEFwcCBmcm9tICcuL0FwcC5qc3gnO1xuaW1wb3J0IHsgQXV0aFByb3ZpZGVyIH0gZnJvbSAnLi9jb250ZXh0L0F1dGhDb250ZXh0LmpzeCc7XG5pbXBvcnQgeyBUaWNrZXREYXRhUHJvdmlkZXIgfSBmcm9tICcuL2NvbnRleHQvVGlja2V0RGF0YUNvbnRleHQuanN4JztcblxuY3JlYXRlUm9vdChkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncm9vdCcpKS5yZW5kZXIoXG4gIDxTdHJpY3RNb2RlPlxuICAgIDxCcm93c2VyUm91dGVyPlxuICAgICAgPEF1dGhQcm92aWRlcj5cbiAgICAgICAgPFRpY2tldERhdGFQcm92aWRlcj5cbiAgICAgICAgICA8QXBwIC8+XG4gICAgICAgIDwvVGlja2V0RGF0YVByb3ZpZGVyPlxuICAgICAgPC9BdXRoUHJvdmlkZXI+XG4gICAgPC9Ccm93c2VyUm91dGVyPlxuICA8L1N0cmljdE1vZGU+XG4pO1xuIl19