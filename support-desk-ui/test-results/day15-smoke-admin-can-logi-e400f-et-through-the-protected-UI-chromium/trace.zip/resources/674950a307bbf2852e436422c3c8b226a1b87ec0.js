import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/StatusBadge.jsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/StatusBadge.jsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3927c5ff";
const statusStyles = {
	OPEN: {
		background: "#dbeafe",
		color: "#2563eb",
		border: "1px solid #93c5fd"
	},
	IN_PROGRESS: {
		background: "#fef3c7",
		color: "#d97706",
		border: "1px solid #fcd34d"
	},
	RESOLVED: {
		background: "#dcfce7",
		color: "#16a34a",
		border: "1px solid #86efac"
	},
	CLOSED: {
		background: "#f3f4f6",
		color: "#6b7280",
		border: "1px solid #d1d5db"
	}
};
const statusLabels = {
	OPEN: "Open",
	IN_PROGRESS: "In Progress",
	RESOLVED: "Resolved",
	CLOSED: "Closed"
};
export default function StatusBadge({ status }) {
	const style = statusStyles[status] || statusStyles.OPEN;
	const label = statusLabels[status] || status;
	return /* @__PURE__ */ _jsxDEV("span", {
		className: "badge",
		style,
		children: label
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 5
	}, this);
}
_c = StatusBadge;
var _c;
$RefreshReg$(_c, "StatusBadge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/StatusBadge.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/StatusBadge.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/StatusBadge.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/StatusBadge.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFBQSxNQUFNLGVBQWU7Q0FDbkIsTUFBTTtFQUFFLFlBQVk7RUFBVyxPQUFPO0VBQVcsUUFBUTtDQUFvQjtDQUM3RSxhQUFhO0VBQUUsWUFBWTtFQUFXLE9BQU87RUFBVyxRQUFRO0NBQW9CO0NBQ3BGLFVBQVU7RUFBRSxZQUFZO0VBQVcsT0FBTztFQUFXLFFBQVE7Q0FBb0I7Q0FDakYsUUFBUTtFQUFFLFlBQVk7RUFBVyxPQUFPO0VBQVcsUUFBUTtDQUFvQjtBQUNqRjtBQUVBLE1BQU0sZUFBZTtDQUNuQixNQUFNO0NBQ04sYUFBYTtDQUNiLFVBQVU7Q0FDVixRQUFRO0FBQ1Y7QUFFQSxlQUFlLFNBQVMsWUFBWSxFQUFFLFVBQVU7Q0FDOUMsTUFBTSxRQUFRLGFBQWEsV0FBVyxhQUFhO0NBQ25ELE1BQU0sUUFBUSxhQUFhLFdBQVc7Q0FFdEMsT0FDRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtFQUFlO1lBQzVCO0NBQ0c7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU3RhdHVzQmFkZ2UuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHN0YXR1c1N0eWxlcyA9IHtcbiAgT1BFTjogeyBiYWNrZ3JvdW5kOiAnI2RiZWFmZScsIGNvbG9yOiAnIzI1NjNlYicsIGJvcmRlcjogJzFweCBzb2xpZCAjOTNjNWZkJyB9LFxuICBJTl9QUk9HUkVTUzogeyBiYWNrZ3JvdW5kOiAnI2ZlZjNjNycsIGNvbG9yOiAnI2Q5NzcwNicsIGJvcmRlcjogJzFweCBzb2xpZCAjZmNkMzRkJyB9LFxuICBSRVNPTFZFRDogeyBiYWNrZ3JvdW5kOiAnI2RjZmNlNycsIGNvbG9yOiAnIzE2YTM0YScsIGJvcmRlcjogJzFweCBzb2xpZCAjODZlZmFjJyB9LFxuICBDTE9TRUQ6IHsgYmFja2dyb3VuZDogJyNmM2Y0ZjYnLCBjb2xvcjogJyM2YjcyODAnLCBib3JkZXI6ICcxcHggc29saWQgI2QxZDVkYicgfVxufTtcblxuY29uc3Qgc3RhdHVzTGFiZWxzID0ge1xuICBPUEVOOiAnT3BlbicsXG4gIElOX1BST0dSRVNTOiAnSW4gUHJvZ3Jlc3MnLFxuICBSRVNPTFZFRDogJ1Jlc29sdmVkJyxcbiAgQ0xPU0VEOiAnQ2xvc2VkJ1xufTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU3RhdHVzQmFkZ2UoeyBzdGF0dXMgfSkge1xuICBjb25zdCBzdHlsZSA9IHN0YXR1c1N0eWxlc1tzdGF0dXNdIHx8IHN0YXR1c1N0eWxlcy5PUEVOO1xuICBjb25zdCBsYWJlbCA9IHN0YXR1c0xhYmVsc1tzdGF0dXNdIHx8IHN0YXR1cztcblxuICByZXR1cm4gKFxuICAgIDxzcGFuIGNsYXNzTmFtZT1cImJhZGdlXCIgc3R5bGU9e3N0eWxlfT5cbiAgICAgIHtsYWJlbH1cbiAgICA8L3NwYW4+XG4gICk7XG59XG4iXX0=