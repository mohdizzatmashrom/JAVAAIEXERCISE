import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/DashboardPage.jsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import { Link } from "/node_modules/.vite/deps/react-router.js?v=3927c5ff";
import ApiInfoCard from "/src/components/ApiInfoCard.jsx";
import { useAuth } from "/src/context/AuthContext.jsx";
import { useTicketData } from "/src/context/TicketDataContext.jsx";
var _jsxFileName = "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/pages/DashboardPage.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3927c5ff";
var _s = $RefreshSig$();
export default function DashboardPage() {
	_s();
	const { user } = useAuth();
	const { tickets, loading, error } = useTicketData();
	const statusCounts = tickets.reduce((acc, t) => {
		acc[t.status] = (acc[t.status] || 0) + 1;
		return acc;
	}, {});
	const priorityCounts = tickets.reduce((acc, t) => {
		acc[t.priority] = (acc[t.priority] || 0) + 1;
		return acc;
	}, {});
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("section", {
			className: "card welcome-card",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("p", {
					className: "eyebrow",
					children: "Protected dashboard"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 24,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", { children: ["Welcome, ", user?.name] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("p", { children: "You are viewing a protected React route. Refresh the page and the session is restored from localStorage." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "action-row",
				children: [/* @__PURE__ */ _jsxDEV(Link, {
					className: "button-link",
					to: "/app/tickets",
					children: "View Tickets"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(Link, {
					className: "button-link secondary",
					to: "/app/reports",
					children: "View Reports"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(ApiInfoCard, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("section", {
			className: "summary-cards",
			children: [
				loading && /* @__PURE__ */ _jsxDEV("p", { children: "Loading tickets..." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 21
				}, this),
				error && /* @__PURE__ */ _jsxDEV("p", {
					style: { color: "red" },
					children: error
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 41,
					columnNumber: 19
				}, this),
				!loading && !error && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "summary-card",
						children: [/* @__PURE__ */ _jsxDEV("h3", { children: "Total Tickets" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 45,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "summary-number",
							children: tickets.length
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "summary-card",
						children: [/* @__PURE__ */ _jsxDEV("h3", { children: "Open" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 49,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "summary-number",
							children: statusCounts.OPEN || 0
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 50,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "summary-card",
						children: [/* @__PURE__ */ _jsxDEV("h3", { children: "In Progress" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "summary-number",
							children: statusCounts.IN_PROGRESS || 0
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 54,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "summary-card",
						children: [/* @__PURE__ */ _jsxDEV("h3", { children: "High Priority" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "summary-number",
							children: priorityCounts.HIGH || 0
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 58,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 56,
						columnNumber: 13
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 21,
		columnNumber: 5
	}, this);
}
_s(DashboardPage, "xP5A5Npsc2VnxBKm2XJJ9zf7AS8=", false, function() {
	return [useAuth, useTicketData];
});
_c = DashboardPage;
var _c;
$RefreshReg$(_c, "DashboardPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/DashboardPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/pages/DashboardPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/pages/DashboardPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/pages/DashboardPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBQ3JCLE9BQU8saUJBQWlCO0FBQ3hCLFNBQVMsZUFBZTtBQUN4QixTQUFTLHFCQUFxQjs7OztBQUU5QixlQUFlLFNBQVMsZ0JBQWdCOztDQUN0QyxNQUFNLEVBQUUsU0FBUyxRQUFRO0NBQ3pCLE1BQU0sRUFBRSxTQUFTLFNBQVMsVUFBVSxjQUFjO0NBRWxELE1BQU0sZUFBZSxRQUFRLFFBQVEsS0FBSyxNQUFNO0VBQzlDLElBQUksRUFBRSxXQUFXLElBQUksRUFBRSxXQUFXLEtBQUs7RUFDdkMsT0FBTztDQUNULEdBQUcsQ0FBQyxDQUFDO0NBRUwsTUFBTSxpQkFBaUIsUUFBUSxRQUFRLEtBQUssTUFBTTtFQUNoRCxJQUFJLEVBQUUsYUFBYSxJQUFJLEVBQUUsYUFBYSxLQUFLO0VBQzNDLE9BQU87Q0FDVCxHQUFHLENBQUMsQ0FBQztDQUVMLE9BQ0U7RUFDRSx3QkFBQyxXQUFEO0dBQVMsV0FBVTthQUFuQixDQUNFLHdCQUFDLE9BQUQ7SUFDRSx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFVO0lBQXNCOzs7OztJQUM3Qyx3QkFBQyxNQUFELGFBQUksYUFBVSxNQUFNLElBQVM7Ozs7O0lBQzdCLHdCQUFDLEtBQUQsWUFBRywyR0FHQTs7Ozs7R0FDQTs7OzthQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQU0sV0FBVTtLQUFjLElBQUc7ZUFBZTtJQUFrQjs7OztjQUNsRSx3QkFBQyxNQUFEO0tBQU0sV0FBVTtLQUF3QixJQUFHO2VBQWU7SUFBa0I7Ozs7WUFDekU7Ozs7O1dBQ0U7Ozs7OztFQUVULHdCQUFDLGFBQUQsQ0FBYzs7Ozs7RUFFZCx3QkFBQyxXQUFEO0dBQVMsV0FBVTthQUFuQjtJQUNHLFdBQVcsd0JBQUMsS0FBRCxZQUFHLHFCQUFxQjs7Ozs7SUFDbkMsU0FBUyx3QkFBQyxLQUFEO0tBQUcsT0FBTyxFQUFFLE9BQU8sTUFBTTtlQUFJO0lBQVM7Ozs7O0lBQy9DLENBQUMsV0FBVyxDQUFDLFNBQ1o7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQsWUFBSSxnQkFBaUI7Ozs7Z0JBQ3JCLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFrQixRQUFRO01BQWE7Ozs7Y0FDcEQ7Ozs7OztLQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRCxZQUFJLE9BQVE7Ozs7Z0JBQ1osd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWtCLGFBQWEsUUFBUTtNQUFROzs7O2NBQzVEOzs7Ozs7S0FDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQsWUFBSSxjQUFlOzs7O2dCQUNuQix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBa0IsYUFBYSxlQUFlO01BQVE7Ozs7Y0FDbkU7Ozs7OztLQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRCxZQUFJLGdCQUFpQjs7OztnQkFDckIsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWtCLGVBQWUsUUFBUTtNQUFROzs7O2NBQzlEOzs7Ozs7SUFDTDs7Ozs7R0FFRzs7Ozs7O0NBQ1Q7Ozs7O0FBRU4iLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRGFzaGJvYXJkUGFnZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlcic7XG5pbXBvcnQgQXBpSW5mb0NhcmQgZnJvbSAnLi4vY29tcG9uZW50cy9BcGlJbmZvQ2FyZC5qc3gnO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uL2NvbnRleHQvQXV0aENvbnRleHQuanN4JztcbmltcG9ydCB7IHVzZVRpY2tldERhdGEgfSBmcm9tICcuLi9jb250ZXh0L1RpY2tldERhdGFDb250ZXh0LmpzeCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERhc2hib2FyZFBhZ2UoKSB7XG4gIGNvbnN0IHsgdXNlciB9ID0gdXNlQXV0aCgpO1xuICBjb25zdCB7IHRpY2tldHMsIGxvYWRpbmcsIGVycm9yIH0gPSB1c2VUaWNrZXREYXRhKCk7XG5cbiAgY29uc3Qgc3RhdHVzQ291bnRzID0gdGlja2V0cy5yZWR1Y2UoKGFjYywgdCkgPT4ge1xuICAgIGFjY1t0LnN0YXR1c10gPSAoYWNjW3Quc3RhdHVzXSB8fCAwKSArIDE7XG4gICAgcmV0dXJuIGFjYztcbiAgfSwge30pO1xuXG4gIGNvbnN0IHByaW9yaXR5Q291bnRzID0gdGlja2V0cy5yZWR1Y2UoKGFjYywgdCkgPT4ge1xuICAgIGFjY1t0LnByaW9yaXR5XSA9IChhY2NbdC5wcmlvcml0eV0gfHwgMCkgKyAxO1xuICAgIHJldHVybiBhY2M7XG4gIH0sIHt9KTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJjYXJkIHdlbGNvbWUtY2FyZFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImV5ZWJyb3dcIj5Qcm90ZWN0ZWQgZGFzaGJvYXJkPC9wPlxuICAgICAgICAgIDxoMj5XZWxjb21lLCB7dXNlcj8ubmFtZX08L2gyPlxuICAgICAgICAgIDxwPlxuICAgICAgICAgICAgWW91IGFyZSB2aWV3aW5nIGEgcHJvdGVjdGVkIFJlYWN0IHJvdXRlLiBSZWZyZXNoIHRoZSBwYWdlIGFuZCB0aGUgc2Vzc2lvbiBpc1xuICAgICAgICAgICAgcmVzdG9yZWQgZnJvbSBsb2NhbFN0b3JhZ2UuXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhY3Rpb24tcm93XCI+XG4gICAgICAgICAgPExpbmsgY2xhc3NOYW1lPVwiYnV0dG9uLWxpbmtcIiB0bz1cIi9hcHAvdGlja2V0c1wiPlZpZXcgVGlja2V0czwvTGluaz5cbiAgICAgICAgICA8TGluayBjbGFzc05hbWU9XCJidXR0b24tbGluayBzZWNvbmRhcnlcIiB0bz1cIi9hcHAvcmVwb3J0c1wiPlZpZXcgUmVwb3J0czwvTGluaz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIDxBcGlJbmZvQ2FyZCAvPlxuXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzdW1tYXJ5LWNhcmRzXCI+XG4gICAgICAgIHtsb2FkaW5nICYmIDxwPkxvYWRpbmcgdGlja2V0cy4uLjwvcD59XG4gICAgICAgIHtlcnJvciAmJiA8cCBzdHlsZT17eyBjb2xvcjogJ3JlZCcgfX0+e2Vycm9yfTwvcD59XG4gICAgICAgIHshbG9hZGluZyAmJiAhZXJyb3IgJiYgKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1bW1hcnktY2FyZFwiPlxuICAgICAgICAgICAgICA8aDM+VG90YWwgVGlja2V0czwvaDM+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInN1bW1hcnktbnVtYmVyXCI+e3RpY2tldHMubGVuZ3RofTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdW1tYXJ5LWNhcmRcIj5cbiAgICAgICAgICAgICAgPGgzPk9wZW48L2gzPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzdW1tYXJ5LW51bWJlclwiPntzdGF0dXNDb3VudHMuT1BFTiB8fCAwfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdW1tYXJ5LWNhcmRcIj5cbiAgICAgICAgICAgICAgPGgzPkluIFByb2dyZXNzPC9oMz5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3VtbWFyeS1udW1iZXJcIj57c3RhdHVzQ291bnRzLklOX1BST0dSRVNTIHx8IDB9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1bW1hcnktY2FyZFwiPlxuICAgICAgICAgICAgICA8aDM+SGlnaCBQcmlvcml0eTwvaDM+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInN1bW1hcnktbnVtYmVyXCI+e3ByaW9yaXR5Q291bnRzLkhJR0ggfHwgMH08L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8Lz5cbiAgICAgICAgKX1cbiAgICAgIDwvc2VjdGlvbj5cbiAgICA8Lz5cbiAgKTtcbn1cbiJdfQ==