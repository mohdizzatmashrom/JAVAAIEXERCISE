import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TicketList.jsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import PriorityBadge from "/src/components/PriorityBadge.jsx";
import StatusBadge from "/src/components/StatusBadge.jsx";
var _jsxFileName = "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/TicketList.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3927c5ff";
export default function TicketList({ tickets, selectedId, onSelect }) {
	return /* @__PURE__ */ _jsxDEV("ul", {
		className: "ticket-list",
		children: tickets.map((ticket) => /* @__PURE__ */ _jsxDEV("li", {
			className: `ticket-item ${selectedId === ticket.id ? "selected" : ""}`,
			onClick: () => onSelect(ticket.id),
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "ticket-item-header",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "ticket-id",
						children: ticket.id
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 14,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV(PriorityBadge, { priority: ticket.priority }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 13,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "ticket-title",
					children: ticket.title
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 17,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "ticket-item-footer",
					children: [/* @__PURE__ */ _jsxDEV(StatusBadge, { status: ticket.status }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 19,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "ticket-date",
						children: String(ticket.createdAt ?? "").slice(0, 10)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 20,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 18,
					columnNumber: 11
				}, this)
			]
		}, ticket.id, true, {
			fileName: _jsxFileName,
			lineNumber: 8,
			columnNumber: 9
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 6,
		columnNumber: 5
	}, this);
}
_c = TicketList;
var _c;
$RefreshReg$(_c, "TicketList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/TicketList.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/TicketList.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/TicketList.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/TicketList.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxtQkFBbUI7QUFDMUIsT0FBTyxpQkFBaUI7OztBQUV4QixlQUFlLFNBQVMsV0FBVyxFQUFFLFNBQVMsWUFBWSxZQUFZO0NBQ3BFLE9BQ0Usd0JBQUMsTUFBRDtFQUFJLFdBQVU7WUFDWCxRQUFRLEtBQUssV0FDWix3QkFBQyxNQUFEO0dBRUUsV0FBVyxlQUFlLGVBQWUsT0FBTyxLQUFLLGFBQWE7R0FDbEUsZUFBZSxTQUFTLE9BQU8sRUFBRTthQUhuQztJQUtFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBYSxPQUFPO0tBQVM7Ozs7ZUFDN0Msd0JBQUMsZUFBRCxFQUFlLFVBQVUsT0FBTyxTQUFXOzs7O2FBQ3hDOzs7Ozs7SUFDTCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFnQixPQUFPO0lBQVM7Ozs7O0lBQzdDLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxhQUFELEVBQWEsUUFBUSxPQUFPLE9BQVM7Ozs7ZUFDckMsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWUsT0FBTyxPQUFPLGFBQWEsRUFBRSxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUU7S0FBUTs7OzthQUM5RTs7Ozs7O0dBQ0g7S0FiRyxPQUFPOzs7O1NBYVYsQ0FDTDtDQUNDOzs7OztBQUVSIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlRpY2tldExpc3QuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBQcmlvcml0eUJhZGdlIGZyb20gJy4vUHJpb3JpdHlCYWRnZS5qc3gnO1xuaW1wb3J0IFN0YXR1c0JhZGdlIGZyb20gJy4vU3RhdHVzQmFkZ2UuanN4JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gVGlja2V0TGlzdCh7IHRpY2tldHMsIHNlbGVjdGVkSWQsIG9uU2VsZWN0IH0pIHtcbiAgcmV0dXJuIChcbiAgICA8dWwgY2xhc3NOYW1lPVwidGlja2V0LWxpc3RcIj5cbiAgICAgIHt0aWNrZXRzLm1hcCgodGlja2V0KSA9PiAoXG4gICAgICAgIDxsaVxuICAgICAgICAgIGtleT17dGlja2V0LmlkfVxuICAgICAgICAgIGNsYXNzTmFtZT17YHRpY2tldC1pdGVtICR7c2VsZWN0ZWRJZCA9PT0gdGlja2V0LmlkID8gJ3NlbGVjdGVkJyA6ICcnfWB9XG4gICAgICAgICAgb25DbGljaz17KCkgPT4gb25TZWxlY3QodGlja2V0LmlkKX1cbiAgICAgICAgPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGlja2V0LWl0ZW0taGVhZGVyXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0aWNrZXQtaWRcIj57dGlja2V0LmlkfTwvc3Bhbj5cbiAgICAgICAgICAgIDxQcmlvcml0eUJhZGdlIHByaW9yaXR5PXt0aWNrZXQucHJpb3JpdHl9IC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGlja2V0LXRpdGxlXCI+e3RpY2tldC50aXRsZX08L3A+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtaXRlbS1mb290ZXJcIj5cbiAgICAgICAgICAgIDxTdGF0dXNCYWRnZSBzdGF0dXM9e3RpY2tldC5zdGF0dXN9IC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0aWNrZXQtZGF0ZVwiPntTdHJpbmcodGlja2V0LmNyZWF0ZWRBdCA/PyAnJykuc2xpY2UoMCwgMTApfTwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9saT5cbiAgICAgICkpfVxuICAgIDwvdWw+XG4gICk7XG59XG4iXX0=