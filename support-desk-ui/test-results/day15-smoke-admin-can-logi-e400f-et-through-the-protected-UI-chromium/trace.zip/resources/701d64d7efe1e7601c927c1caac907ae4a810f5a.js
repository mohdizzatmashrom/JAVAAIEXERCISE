import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LoginPage.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=3927c5ff";
import { Navigate, useLocation, useNavigate } from "/node_modules/.vite/deps/react-router.js?v=3927c5ff";
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/pages/LoginPage.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3927c5ff";
var _s = $RefreshSig$();
export default function LoginPage() {
	_s();
	const { isAuthenticated, login } = useAuth();
	const [email, setEmail] = useState("admin@example.com");
	const [password, setPassword] = useState("Admin@12345");
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState("");
	const navigate = useNavigate();
	const location = useLocation();
	const redirectTo = location.state?.from?.pathname || "/app/dashboard";
	if (isAuthenticated) {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: redirectTo,
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 12
		}, this);
	}
	async function handleSubmit(event) {
		event.preventDefault();
		setLoading(true);
		setError("");
		try {
			await login(email, password);
			navigate(redirectTo, { replace: true });
		} catch (err) {
			setError(err.message || "Login failed. Check the backend and credentials.");
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "login-page",
		children: /* @__PURE__ */ _jsxDEV("section", {
			className: "login-card",
			children: [
				/* @__PURE__ */ _jsxDEV("p", {
					className: "eyebrow",
					children: "Day 12"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h1", { children: "Login to Support Desk" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", { children: "This login calls our Day 9 backend, stores the JWT in localStorage for this demo and redirects the user to the protected area of our application." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("form", {
					onSubmit: handleSubmit,
					className: "login-form",
					children: [
						/* @__PURE__ */ _jsxDEV("label", { children: ["Email", /* @__PURE__ */ _jsxDEV("input", {
							type: "email",
							placeholder: "Email",
							value: email,
							onChange: (event) => setEmail(event.target.value),
							required: true
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("label", { children: ["Password", /* @__PURE__ */ _jsxDEV("input", {
							type: "password",
							placeholder: "Password",
							value: password,
							onChange: (event) => setPassword(event.target.value),
							required: true
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 59,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 11
						}, this),
						error && /* @__PURE__ */ _jsxDEV("p", {
							className: "login-error",
							children: error
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 21
						}, this),
						loading && /* @__PURE__ */ _jsxDEV("p", {
							className: "login-loading",
							children: "Logging in..."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 69,
							columnNumber: 23
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							disabled: loading,
							children: loading ? "Please wait..." : "Login"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "login-help",
					children: [
						/* @__PURE__ */ _jsxDEV("strong", { children: "Seeded admin" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("span", { children: "email: admin@example.com" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("span", { children: "password: Admin@12345" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 36,
		columnNumber: 5
	}, this);
}
_s(LoginPage, "470Ofr5pMl1IYCeY8a9iG5DCDlk=", false, function() {
	return [
		useAuth,
		useNavigate,
		useLocation
	];
});
_c = LoginPage;
var _c;
$RefreshReg$(_c, "LoginPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/LoginPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/pages/LoginPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/pages/LoginPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/pages/LoginPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxVQUFVLGFBQWEsbUJBQW1CO0FBQ25ELFNBQVMsZUFBZTs7OztBQUV4QixlQUFlLFNBQVMsWUFBWTs7Q0FDbEMsTUFBTSxFQUFFLGlCQUFpQixVQUFVLFFBQVE7Q0FDM0MsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLG1CQUFtQjtDQUN0RCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsYUFBYTtDQUN0RCxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSztDQUM1QyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLFdBQVcsWUFBWTtDQUU3QixNQUFNLGFBQWEsU0FBUyxPQUFPLE1BQU0sWUFBWTtDQUVyRCxJQUFJLGlCQUFpQjtFQUNuQixPQUFPLHdCQUFDLFVBQUQ7R0FBVSxJQUFJO0dBQVk7RUFBUzs7Ozs7Q0FDNUM7Q0FFQSxlQUFlLGFBQWEsT0FBTztFQUNqQyxNQUFNLGVBQWU7RUFDckIsV0FBVyxJQUFJO0VBQ2YsU0FBUyxFQUFFO0VBRVgsSUFBSTtHQUNGLE1BQU0sTUFBTSxPQUFPLFFBQVE7R0FDM0IsU0FBUyxZQUFZLEVBQUUsU0FBUyxLQUFLLENBQUM7RUFDeEMsU0FBUyxLQUFLO0dBQ1osU0FBUyxJQUFJLFdBQVcsa0RBQWtEO0VBQzVFLFVBQVU7R0FDUixXQUFXLEtBQUs7RUFDbEI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFDZCx3QkFBQyxXQUFEO0dBQVMsV0FBVTthQUFuQjtJQUNFLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQVU7SUFBUzs7Ozs7SUFDaEMsd0JBQUMsTUFBRCxZQUFJLHdCQUF5Qjs7Ozs7SUFDN0Isd0JBQUMsS0FBRCxZQUFHLG9KQUdBOzs7OztJQUVILHdCQUFDLFFBQUQ7S0FBTSxVQUFVO0tBQWMsV0FBVTtlQUF4QztNQUNFLHdCQUFDLFNBQUQsYUFBTyxTQUVMLHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0wsYUFBWTtPQUNaLE9BQU87T0FDUCxXQUFXLFVBQVUsU0FBUyxNQUFNLE9BQU8sS0FBSztPQUNoRDtNQUNEOzs7O2NBQ0k7Ozs7O01BRVAsd0JBQUMsU0FBRCxhQUFPLFlBRUwsd0JBQUMsU0FBRDtPQUNFLE1BQUs7T0FDTCxhQUFZO09BQ1osT0FBTztPQUNQLFdBQVcsVUFBVSxZQUFZLE1BQU0sT0FBTyxLQUFLO09BQ25EO01BQ0Q7Ozs7Y0FDSTs7Ozs7TUFFTixTQUFTLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFlO01BQVM7Ozs7O01BQzlDLFdBQVcsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWdCO01BQWdCOzs7OztNQUV6RCx3QkFBQyxVQUFEO09BQVEsTUFBSztPQUFTLFVBQVU7aUJBQzdCLFVBQVUsbUJBQW1CO01BQ3hCOzs7OztLQUNKOzs7Ozs7SUFFTix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsVUFBRCxZQUFRLGVBQW9COzs7OztNQUM1Qix3QkFBQyxRQUFELFlBQU0sMkJBQThCOzs7OztNQUNwQyx3QkFBQyxRQUFELFlBQU0sd0JBQTJCOzs7OztLQUM5Qjs7Ozs7O0dBQ0U7Ozs7OztDQUNMOzs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkxvZ2luUGFnZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBOYXZpZ2F0ZSwgdXNlTG9jYXRpb24sIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyJztcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi9jb250ZXh0L0F1dGhDb250ZXh0LmpzeCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExvZ2luUGFnZSgpIHtcbiAgY29uc3QgeyBpc0F1dGhlbnRpY2F0ZWQsIGxvZ2luIH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoJ2FkbWluQGV4YW1wbGUuY29tJyk7XG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJ0FkbWluQDEyMzQ1Jyk7XG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xuXG4gIGNvbnN0IHJlZGlyZWN0VG8gPSBsb2NhdGlvbi5zdGF0ZT8uZnJvbT8ucGF0aG5hbWUgfHwgJy9hcHAvZGFzaGJvYXJkJztcblxuICBpZiAoaXNBdXRoZW50aWNhdGVkKSB7XG4gICAgcmV0dXJuIDxOYXZpZ2F0ZSB0bz17cmVkaXJlY3RUb30gcmVwbGFjZSAvPjtcbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChldmVudCkge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICBzZXRFcnJvcignJyk7XG5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgbG9naW4oZW1haWwsIHBhc3N3b3JkKTtcbiAgICAgIG5hdmlnYXRlKHJlZGlyZWN0VG8sIHsgcmVwbGFjZTogdHJ1ZSB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlIHx8ICdMb2dpbiBmYWlsZWQuIENoZWNrIHRoZSBiYWNrZW5kIGFuZCBjcmVkZW50aWFscy4nKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8bWFpbiBjbGFzc05hbWU9XCJsb2dpbi1wYWdlXCI+XG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJsb2dpbi1jYXJkXCI+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImV5ZWJyb3dcIj5EYXkgMTI8L3A+XG4gICAgICAgIDxoMT5Mb2dpbiB0byBTdXBwb3J0IERlc2s8L2gxPlxuICAgICAgICA8cD5cbiAgICAgICAgICBUaGlzIGxvZ2luIGNhbGxzIG91ciBEYXkgOSBiYWNrZW5kLCBzdG9yZXMgdGhlIEpXVCBpbiBsb2NhbFN0b3JhZ2UgZm9yIHRoaXMgZGVtb1xuICAgICAgICAgIGFuZCByZWRpcmVjdHMgdGhlIHVzZXIgdG8gdGhlIHByb3RlY3RlZCBhcmVhIG9mIG91ciBhcHBsaWNhdGlvbi5cbiAgICAgICAgPC9wPlxuXG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cImxvZ2luLWZvcm1cIj5cbiAgICAgICAgICA8bGFiZWw+XG4gICAgICAgICAgICBFbWFpbFxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW1haWxcIlxuICAgICAgICAgICAgICB2YWx1ZT17ZW1haWx9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldEVtYWlsKGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICA8bGFiZWw+XG4gICAgICAgICAgICBQYXNzd29yZFxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUGFzc3dvcmRcIlxuICAgICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFBhc3N3b3JkKGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwibG9naW4tZXJyb3JcIj57ZXJyb3J9PC9wPn1cbiAgICAgICAgICB7bG9hZGluZyAmJiA8cCBjbGFzc05hbWU9XCJsb2dpbi1sb2FkaW5nXCI+TG9nZ2luZyBpbi4uLjwvcD59XG5cbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17bG9hZGluZ30+XG4gICAgICAgICAgICB7bG9hZGluZyA/ICdQbGVhc2Ugd2FpdC4uLicgOiAnTG9naW4nfVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Zvcm0+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsb2dpbi1oZWxwXCI+XG4gICAgICAgICAgPHN0cm9uZz5TZWVkZWQgYWRtaW48L3N0cm9uZz5cbiAgICAgICAgICA8c3Bhbj5lbWFpbDogYWRtaW5AZXhhbXBsZS5jb208L3NwYW4+XG4gICAgICAgICAgPHNwYW4+cGFzc3dvcmQ6IEFkbWluQDEyMzQ1PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cbiAgICA8L21haW4+XG4gICk7XG59XG4iXX0=