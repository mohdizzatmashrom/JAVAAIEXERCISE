import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ReportsPage.jsx");const useMemo = __vite__cjsImport0_react["useMemo"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=3927c5ff";
import StatusBadge from "/src/components/StatusBadge.jsx";
import PriorityBadge from "/src/components/PriorityBadge.jsx";
import { useTicketData } from "/src/context/TicketDataContext.jsx";
var _jsxFileName = "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/pages/ReportsPage.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3927c5ff";
var _s = $RefreshSig$();
const STATUS_ORDER = [
	"OPEN",
	"IN_PROGRESS",
	"RESOLVED",
	"CLOSED"
];
const PRIORITY_ORDER = [
	"HIGH",
	"MEDIUM",
	"LOW"
];
function countBy(items, key) {
	return items.reduce((acc, item) => {
		acc[item[key]] = (acc[item[key]] || 0) + 1;
		return acc;
	}, {});
}
export default function ReportsPage() {
	_s();
	const { tickets, loading, error } = useTicketData();
	const statusCounts = useMemo(() => countBy(tickets, "status"), [tickets]);
	const priorityCounts = useMemo(() => countBy(tickets, "priority"), [tickets]);
	const categoryCounts = useMemo(() => countBy(tickets, "category"), [tickets]);
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("h2", {
			className: "page-title",
			children: "Reports"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 7
		}, this),
		loading && /* @__PURE__ */ _jsxDEV("p", { children: "Loading reports..." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 19
		}, this),
		error && /* @__PURE__ */ _jsxDEV("p", {
			style: { color: "red" },
			children: error
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 17
		}, this),
		!loading && !error && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
			/* @__PURE__ */ _jsxDEV("section", {
				className: "card report-card",
				children: [/* @__PURE__ */ _jsxDEV("h3", { children: "Tickets by Status" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("ul", {
					className: "report-list",
					children: STATUS_ORDER.map((status) => /* @__PURE__ */ _jsxDEV("li", {
						className: "report-row",
						children: [/* @__PURE__ */ _jsxDEV(StatusBadge, { status }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 36,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "report-count",
							children: statusCounts[status] || 0
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 37,
							columnNumber: 15
						}, this)]
					}, status, true, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "card report-card",
				children: [/* @__PURE__ */ _jsxDEV("h3", { children: "Tickets by Priority" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("ul", {
					className: "report-list",
					children: PRIORITY_ORDER.map((priority) => /* @__PURE__ */ _jsxDEV("li", {
						className: "report-row",
						children: [/* @__PURE__ */ _jsxDEV(PriorityBadge, { priority }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "report-count",
							children: priorityCounts[priority] || 0
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 49,
							columnNumber: 15
						}, this)]
					}, priority, true, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "card report-card",
				children: [/* @__PURE__ */ _jsxDEV("h3", { children: "Tickets by Category" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("ul", {
					className: "report-list",
					children: Object.entries(categoryCounts).sort((a, b) => b[1] - a[1]).map(([category, count]) => /* @__PURE__ */ _jsxDEV("li", {
						className: "report-row",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "report-label",
							children: category
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 62,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "report-count",
							children: count
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 63,
							columnNumber: 17
						}, this)]
					}, category, true, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 15
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 55,
				columnNumber: 7
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 29,
			columnNumber: 31
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 24,
		columnNumber: 5
	}, this);
}
_s(ReportsPage, "jMalwBpCLDpOCEHyo6RWudYWx7Q=", false, function() {
	return [useTicketData];
});
_c = ReportsPage;
var _c;
$RefreshReg$(_c, "ReportsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/ReportsPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/pages/ReportsPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/pages/ReportsPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/pages/ReportsPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlO0FBQ3hCLE9BQU8saUJBQWlCO0FBQ3hCLE9BQU8sbUJBQW1CO0FBQzFCLFNBQVMscUJBQXFCOzs7O0FBRTlCLE1BQU0sZUFBZTtDQUFDO0NBQVE7Q0FBZTtDQUFZO0FBQVE7QUFDakUsTUFBTSxpQkFBaUI7Q0FBQztDQUFRO0NBQVU7QUFBSztBQUUvQyxTQUFTLFFBQVEsT0FBTyxLQUFLO0NBQzNCLE9BQU8sTUFBTSxRQUFRLEtBQUssU0FBUztFQUNqQyxJQUFJLEtBQUssU0FBUyxJQUFJLEtBQUssU0FBUyxLQUFLO0VBQ3pDLE9BQU87Q0FDVCxHQUFHLENBQUMsQ0FBQztBQUNQO0FBRUEsZUFBZSxTQUFTLGNBQWM7O0NBQ3BDLE1BQU0sRUFBRSxTQUFTLFNBQVMsVUFBVSxjQUFjO0NBRWxELE1BQU0sZUFBZSxjQUFjLFFBQVEsU0FBUyxRQUFRLEdBQUcsQ0FBQyxPQUFPLENBQUM7Q0FDeEUsTUFBTSxpQkFBaUIsY0FBYyxRQUFRLFNBQVMsVUFBVSxHQUFHLENBQUMsT0FBTyxDQUFDO0NBQzVFLE1BQU0saUJBQWlCLGNBQWMsUUFBUSxTQUFTLFVBQVUsR0FBRyxDQUFDLE9BQU8sQ0FBQztDQUU1RSxPQUNFO0VBQ0Usd0JBQUMsTUFBRDtHQUFJLFdBQVU7YUFBYTtFQUFXOzs7OztFQUVyQyxXQUFXLHdCQUFDLEtBQUQsWUFBRyxxQkFBcUI7Ozs7O0VBQ25DLFNBQVMsd0JBQUMsS0FBRDtHQUFHLE9BQU8sRUFBRSxPQUFPLE1BQU07YUFBSTtFQUFTOzs7OztFQUMvQyxDQUFDLFdBQVcsQ0FBQyxTQUFVO0dBRXhCLHdCQUFDLFdBQUQ7SUFBUyxXQUFVO2NBQW5CLENBQ0Usd0JBQUMsTUFBRCxZQUFJLG9CQUFxQjs7OztjQUN6Qix3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUNYLGFBQWEsS0FBSyxXQUNqQix3QkFBQyxNQUFEO01BQWlCLFdBQVU7Z0JBQTNCLENBQ0Usd0JBQUMsYUFBRCxFQUFxQixPQUFTOzs7O2dCQUM5Qix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBZ0IsYUFBYSxXQUFXO01BQVE7Ozs7Y0FDOUQ7UUFISzs7OztZQUdMLENBQ0w7SUFDQzs7OztZQUNHOzs7Ozs7R0FFVCx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUFuQixDQUNFLHdCQUFDLE1BQUQsWUFBSSxzQkFBdUI7Ozs7Y0FDM0Isd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFDWCxlQUFlLEtBQUssYUFDbkIsd0JBQUMsTUFBRDtNQUFtQixXQUFVO2dCQUE3QixDQUNFLHdCQUFDLGVBQUQsRUFBeUIsU0FBVzs7OztnQkFDcEMsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWdCLGVBQWUsYUFBYTtNQUFROzs7O2NBQ2xFO1FBSEs7Ozs7WUFHTCxDQUNMO0lBQ0M7Ozs7WUFDRzs7Ozs7O0dBRVQsd0JBQUMsV0FBRDtJQUFTLFdBQVU7Y0FBbkIsQ0FDRSx3QkFBQyxNQUFELFlBQUksc0JBQXVCOzs7O2NBQzNCLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQ1gsT0FBTyxRQUFRLGNBQWMsQ0FBQyxDQUM1QixNQUFNLEdBQUcsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FDM0IsS0FBSyxDQUFDLFVBQVUsV0FDZix3QkFBQyxNQUFEO01BQW1CLFdBQVU7Z0JBQTdCLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWdCO01BQWU7Ozs7Z0JBQy9DLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFnQjtNQUFZOzs7O2NBQzFDO1FBSEs7Ozs7WUFHTCxDQUNMO0lBQ0Q7Ozs7WUFDRzs7Ozs7O0VBQ1A7Ozs7O0NBRUY7Ozs7O0FBRU4iLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUmVwb3J0c1BhZ2UuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgU3RhdHVzQmFkZ2UgZnJvbSAnLi4vY29tcG9uZW50cy9TdGF0dXNCYWRnZS5qc3gnO1xuaW1wb3J0IFByaW9yaXR5QmFkZ2UgZnJvbSAnLi4vY29tcG9uZW50cy9Qcmlvcml0eUJhZGdlLmpzeCc7XG5pbXBvcnQgeyB1c2VUaWNrZXREYXRhIH0gZnJvbSAnLi4vY29udGV4dC9UaWNrZXREYXRhQ29udGV4dC5qc3gnO1xuXG5jb25zdCBTVEFUVVNfT1JERVIgPSBbJ09QRU4nLCAnSU5fUFJPR1JFU1MnLCAnUkVTT0xWRUQnLCAnQ0xPU0VEJ107XG5jb25zdCBQUklPUklUWV9PUkRFUiA9IFsnSElHSCcsICdNRURJVU0nLCAnTE9XJ107XG5cbmZ1bmN0aW9uIGNvdW50QnkoaXRlbXMsIGtleSkge1xuICByZXR1cm4gaXRlbXMucmVkdWNlKChhY2MsIGl0ZW0pID0+IHtcbiAgICBhY2NbaXRlbVtrZXldXSA9IChhY2NbaXRlbVtrZXldXSB8fCAwKSArIDE7XG4gICAgcmV0dXJuIGFjYztcbiAgfSwge30pO1xufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBSZXBvcnRzUGFnZSgpIHtcbiAgY29uc3QgeyB0aWNrZXRzLCBsb2FkaW5nLCBlcnJvciB9ID0gdXNlVGlja2V0RGF0YSgpO1xuXG4gIGNvbnN0IHN0YXR1c0NvdW50cyA9IHVzZU1lbW8oKCkgPT4gY291bnRCeSh0aWNrZXRzLCAnc3RhdHVzJyksIFt0aWNrZXRzXSk7XG4gIGNvbnN0IHByaW9yaXR5Q291bnRzID0gdXNlTWVtbygoKSA9PiBjb3VudEJ5KHRpY2tldHMsICdwcmlvcml0eScpLCBbdGlja2V0c10pO1xuICBjb25zdCBjYXRlZ29yeUNvdW50cyA9IHVzZU1lbW8oKCkgPT4gY291bnRCeSh0aWNrZXRzLCAnY2F0ZWdvcnknKSwgW3RpY2tldHNdKTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8aDIgY2xhc3NOYW1lPVwicGFnZS10aXRsZVwiPlJlcG9ydHM8L2gyPlxuXG4gICAgICB7bG9hZGluZyAmJiA8cD5Mb2FkaW5nIHJlcG9ydHMuLi48L3A+fVxuICAgICAge2Vycm9yICYmIDxwIHN0eWxlPXt7IGNvbG9yOiAncmVkJyB9fT57ZXJyb3J9PC9wPn1cbiAgICAgIHshbG9hZGluZyAmJiAhZXJyb3IgJiYgKDw+XG5cbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImNhcmQgcmVwb3J0LWNhcmRcIj5cbiAgICAgICAgPGgzPlRpY2tldHMgYnkgU3RhdHVzPC9oMz5cbiAgICAgICAgPHVsIGNsYXNzTmFtZT1cInJlcG9ydC1saXN0XCI+XG4gICAgICAgICAge1NUQVRVU19PUkRFUi5tYXAoKHN0YXR1cykgPT4gKFxuICAgICAgICAgICAgPGxpIGtleT17c3RhdHVzfSBjbGFzc05hbWU9XCJyZXBvcnQtcm93XCI+XG4gICAgICAgICAgICAgIDxTdGF0dXNCYWRnZSBzdGF0dXM9e3N0YXR1c30gLz5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmVwb3J0LWNvdW50XCI+e3N0YXR1c0NvdW50c1tzdGF0dXNdIHx8IDB9PC9zcGFuPlxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC91bD5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiY2FyZCByZXBvcnQtY2FyZFwiPlxuICAgICAgICA8aDM+VGlja2V0cyBieSBQcmlvcml0eTwvaDM+XG4gICAgICAgIDx1bCBjbGFzc05hbWU9XCJyZXBvcnQtbGlzdFwiPlxuICAgICAgICAgIHtQUklPUklUWV9PUkRFUi5tYXAoKHByaW9yaXR5KSA9PiAoXG4gICAgICAgICAgICA8bGkga2V5PXtwcmlvcml0eX0gY2xhc3NOYW1lPVwicmVwb3J0LXJvd1wiPlxuICAgICAgICAgICAgICA8UHJpb3JpdHlCYWRnZSBwcmlvcml0eT17cHJpb3JpdHl9IC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJlcG9ydC1jb3VudFwiPntwcmlvcml0eUNvdW50c1twcmlvcml0eV0gfHwgMH08L3NwYW4+XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L3VsPlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJjYXJkIHJlcG9ydC1jYXJkXCI+XG4gICAgICAgIDxoMz5UaWNrZXRzIGJ5IENhdGVnb3J5PC9oMz5cbiAgICAgICAgPHVsIGNsYXNzTmFtZT1cInJlcG9ydC1saXN0XCI+XG4gICAgICAgICAge09iamVjdC5lbnRyaWVzKGNhdGVnb3J5Q291bnRzKVxuICAgICAgICAgICAgLnNvcnQoKGEsIGIpID0+IGJbMV0gLSBhWzFdKVxuICAgICAgICAgICAgLm1hcCgoW2NhdGVnb3J5LCBjb3VudF0pID0+IChcbiAgICAgICAgICAgICAgPGxpIGtleT17Y2F0ZWdvcnl9IGNsYXNzTmFtZT1cInJlcG9ydC1yb3dcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyZXBvcnQtbGFiZWxcIj57Y2F0ZWdvcnl9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJlcG9ydC1jb3VudFwiPntjb3VudH08L3NwYW4+XG4gICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgPC91bD5cbiAgICAgIDwvc2VjdGlvbj5cbiAgICAgIDwvPlxuICAgICAgKX1cbiAgICA8Lz5cbiAgKTtcbn1cbiJdfQ==