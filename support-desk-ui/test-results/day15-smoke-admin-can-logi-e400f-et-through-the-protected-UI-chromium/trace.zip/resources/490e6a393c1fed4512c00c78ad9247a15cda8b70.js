import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TicketFormWizard.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=3927c5ff";
import InlineFieldError from "/src/components/InlineFieldError.jsx";
var _jsxFileName = "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/TicketFormWizard.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3927c5ff";
var _s = $RefreshSig$();
const CATEGORY_OPTIONS = [
	"Email",
	"Hardware",
	"Software",
	"Network",
	"Account"
];
const PRIORITY_OPTIONS = [
	"HIGH",
	"MEDIUM",
	"LOW"
];
// Must match the statuses accepted by the backend TicketService
const STATUS_OPTIONS = [
	"OPEN",
	"IN_PROGRESS",
	"CLOSED"
];
export const emptyTicketForm = {
	title: "",
	description: "",
	category: "",
	priority: "",
	status: ""
};
export default function TicketFormWizard({ initialValues = emptyTicketForm, onSubmit, saving = false, submitLabel = "Create Ticket" }) {
	_s();
	const [formValues, setFormValues] = useState({
		...emptyTicketForm,
		...initialValues
	});
	const [fieldErrors, setFieldErrors] = useState({});
	function updateField(fieldName, value) {
		setFormValues((current) => ({
			...current,
			[fieldName]: value
		}));
		// Clear the error for a field as soon as the user edits it
		setFieldErrors((current) => ({
			...current,
			[fieldName]: ""
		}));
	}
	function validateForm() {
		const errors = {};
		if (!formValues.title.trim()) {
			errors.title = "Title is required.";
		}
		if (!formValues.description.trim()) {
			errors.description = "Description is required.";
		}
		if (!formValues.category) {
			errors.category = "Category is required.";
		}
		if (!formValues.priority) {
			errors.priority = "Priority is required.";
		}
		if (!formValues.status) {
			errors.status = "Status is required.";
		}
		setFieldErrors(errors);
		return Object.keys(errors).length === 0;
	}
	function handleSubmit(event) {
		event.preventDefault();
		// Block submission when any required field is empty
		if (!validateForm()) {
			return;
		}
		const payload = {
			title: formValues.title.trim(),
			description: formValues.description.trim(),
			category: formValues.category,
			priority: formValues.priority,
			status: formValues.status
		};
		if (onSubmit) {
			onSubmit(payload);
		}
	}
	return /* @__PURE__ */ _jsxDEV("form", {
		className: "card ticket-form",
		onSubmit: handleSubmit,
		noValidate: true,
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "section-heading",
				children: [
					/* @__PURE__ */ _jsxDEV("p", {
						className: "eyebrow",
						children: "Day 13 form"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", { children: "Ticket Details" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 91,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: "Controlled inputs backed by React state, with client-side validation and inline errors." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 92,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "title",
				children: [
					"Title",
					/* @__PURE__ */ _jsxDEV("input", {
						id: "title",
						type: "text",
						value: formValues.title,
						onChange: (event) => updateField("title", event.target.value),
						placeholder: "Short summary of the issue",
						"aria-invalid": Boolean(fieldErrors.title)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(InlineFieldError, { message: fieldErrors.title }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 105,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 95,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "description",
				children: [
					"Description",
					/* @__PURE__ */ _jsxDEV("textarea", {
						id: "description",
						rows: 4,
						value: formValues.description,
						onChange: (event) => updateField("description", event.target.value),
						placeholder: "Describe the problem in more detail",
						"aria-invalid": Boolean(fieldErrors.description)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(InlineFieldError, { message: fieldErrors.description }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 108,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "category",
				children: [
					"Category",
					/* @__PURE__ */ _jsxDEV("select", {
						id: "category",
						value: formValues.category,
						onChange: (event) => updateField("category", event.target.value),
						"aria-invalid": Boolean(fieldErrors.category),
						children: [/* @__PURE__ */ _jsxDEV("option", {
							value: "",
							children: "Select a category..."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 129,
							columnNumber: 11
						}, this), CATEGORY_OPTIONS.map((category) => /* @__PURE__ */ _jsxDEV("option", {
							value: category,
							children: category
						}, category, false, {
							fileName: _jsxFileName,
							lineNumber: 131,
							columnNumber: 13
						}, this))]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(InlineFieldError, { message: fieldErrors.category }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 134,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 121,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "priority",
				children: [
					"Priority",
					/* @__PURE__ */ _jsxDEV("select", {
						id: "priority",
						value: formValues.priority,
						onChange: (event) => updateField("priority", event.target.value),
						"aria-invalid": Boolean(fieldErrors.priority),
						children: [/* @__PURE__ */ _jsxDEV("option", {
							value: "",
							children: "Select a priority..."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 11
						}, this), PRIORITY_OPTIONS.map((priority) => /* @__PURE__ */ _jsxDEV("option", {
							value: priority,
							children: priority
						}, priority, false, {
							fileName: _jsxFileName,
							lineNumber: 147,
							columnNumber: 13
						}, this))]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 139,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(InlineFieldError, { message: fieldErrors.priority }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 137,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "status",
				children: [
					"Status",
					/* @__PURE__ */ _jsxDEV("select", {
						id: "status",
						value: formValues.status,
						onChange: (event) => updateField("status", event.target.value),
						"aria-invalid": Boolean(fieldErrors.status),
						children: [/* @__PURE__ */ _jsxDEV("option", {
							value: "",
							children: "Select a status..."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 161,
							columnNumber: 11
						}, this), STATUS_OPTIONS.map((status) => /* @__PURE__ */ _jsxDEV("option", {
							value: status,
							children: status
						}, status, false, {
							fileName: _jsxFileName,
							lineNumber: 163,
							columnNumber: 13
						}, this))]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 155,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(InlineFieldError, { message: fieldErrors.status }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 166,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 153,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "form-actions",
				children: /* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					className: "button-link",
					disabled: saving,
					children: saving ? "Saving..." : submitLabel
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 170,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 169,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 88,
		columnNumber: 5
	}, this);
}
_s(TicketFormWizard, "oC9DpM8+/t8gJZab1vI149D0VF0=");
_c = TicketFormWizard;
var _c;
$RefreshReg$(_c, "TicketFormWizard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/TicketFormWizard.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/TicketFormWizard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/TicketFormWizard.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/TicketFormWizard.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsT0FBTyxzQkFBc0I7Ozs7QUFFN0IsTUFBTSxtQkFBbUI7Q0FBQztDQUFTO0NBQVk7Q0FBWTtDQUFXO0FBQVM7QUFDL0UsTUFBTSxtQkFBbUI7Q0FBQztDQUFRO0NBQVU7QUFBSzs7QUFFakQsTUFBTSxpQkFBaUI7Q0FBQztDQUFRO0NBQWU7QUFBUTtBQUV2RCxPQUFPLE1BQU0sa0JBQWtCO0NBQzdCLE9BQU87Q0FDUCxhQUFhO0NBQ2IsVUFBVTtDQUNWLFVBQVU7Q0FDVixRQUFRO0FBQ1Y7QUFFQSxlQUFlLFNBQVMsaUJBQWlCLEVBQ3ZDLGdCQUFnQixpQkFDaEIsVUFDQSxTQUFTLE9BQ1QsY0FBYyxtQkFDYjs7Q0FDRCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUztFQUFFLEdBQUc7RUFBaUIsR0FBRztDQUFjLENBQUM7Q0FDckYsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsQ0FBQyxDQUFDO0NBRWpELFNBQVMsWUFBWSxXQUFXLE9BQU87RUFDckMsZUFBZSxhQUFhO0dBQzFCLEdBQUc7SUFDRixZQUFZO0VBQ2YsRUFBRTs7RUFHRixnQkFBZ0IsYUFBYTtHQUMzQixHQUFHO0lBQ0YsWUFBWTtFQUNmLEVBQUU7Q0FDSjtDQUVBLFNBQVMsZUFBZTtFQUN0QixNQUFNLFNBQVMsQ0FBQztFQUVoQixJQUFJLENBQUMsV0FBVyxNQUFNLEtBQUssR0FBRztHQUM1QixPQUFPLFFBQVE7RUFDakI7RUFFQSxJQUFJLENBQUMsV0FBVyxZQUFZLEtBQUssR0FBRztHQUNsQyxPQUFPLGNBQWM7RUFDdkI7RUFFQSxJQUFJLENBQUMsV0FBVyxVQUFVO0dBQ3hCLE9BQU8sV0FBVztFQUNwQjtFQUVBLElBQUksQ0FBQyxXQUFXLFVBQVU7R0FDeEIsT0FBTyxXQUFXO0VBQ3BCO0VBRUEsSUFBSSxDQUFDLFdBQVcsUUFBUTtHQUN0QixPQUFPLFNBQVM7RUFDbEI7RUFFQSxlQUFlLE1BQU07RUFDckIsT0FBTyxPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsV0FBVztDQUN4QztDQUVBLFNBQVMsYUFBYSxPQUFPO0VBQzNCLE1BQU0sZUFBZTs7RUFHckIsSUFBSSxDQUFDLGFBQWEsR0FBRztHQUNuQjtFQUNGO0VBRUEsTUFBTSxVQUFVO0dBQ2QsT0FBTyxXQUFXLE1BQU0sS0FBSztHQUM3QixhQUFhLFdBQVcsWUFBWSxLQUFLO0dBQ3pDLFVBQVUsV0FBVztHQUNyQixVQUFVLFdBQVc7R0FDckIsUUFBUSxXQUFXO0VBQ3JCO0VBRUEsSUFBSSxVQUFVO0dBQ1osU0FBUyxPQUFPO0VBQ2xCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLFFBQUQ7RUFBTSxXQUFVO0VBQW1CLFVBQVU7RUFBYztZQUEzRDtHQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBVTtLQUFjOzs7OztLQUNyQyx3QkFBQyxNQUFELFlBQUksaUJBQWtCOzs7OztLQUN0Qix3QkFBQyxLQUFELFlBQUcsMEZBQTBGOzs7OztJQUMxRjs7Ozs7O0dBRUwsd0JBQUMsU0FBRDtJQUFPLFNBQVE7Y0FBZjtLQUF1QjtLQUVyQix3QkFBQyxTQUFEO01BQ0UsSUFBRztNQUNILE1BQUs7TUFDTCxPQUFPLFdBQVc7TUFDbEIsV0FBVyxVQUFVLFlBQVksU0FBUyxNQUFNLE9BQU8sS0FBSztNQUM1RCxhQUFZO01BQ1osZ0JBQWMsUUFBUSxZQUFZLEtBQUs7S0FDeEM7Ozs7O0tBQ0Qsd0JBQUMsa0JBQUQsRUFBa0IsU0FBUyxZQUFZLE1BQVE7Ozs7O0lBQzFDOzs7Ozs7R0FFUCx3QkFBQyxTQUFEO0lBQU8sU0FBUTtjQUFmO0tBQTZCO0tBRTNCLHdCQUFDLFlBQUQ7TUFDRSxJQUFHO01BQ0gsTUFBTTtNQUNOLE9BQU8sV0FBVztNQUNsQixXQUFXLFVBQVUsWUFBWSxlQUFlLE1BQU0sT0FBTyxLQUFLO01BQ2xFLGFBQVk7TUFDWixnQkFBYyxRQUFRLFlBQVksV0FBVztLQUM5Qzs7Ozs7S0FDRCx3QkFBQyxrQkFBRCxFQUFrQixTQUFTLFlBQVksWUFBYzs7Ozs7SUFDaEQ7Ozs7OztHQUVQLHdCQUFDLFNBQUQ7SUFBTyxTQUFRO2NBQWY7S0FBMEI7S0FFeEIsd0JBQUMsVUFBRDtNQUNFLElBQUc7TUFDSCxPQUFPLFdBQVc7TUFDbEIsV0FBVyxVQUFVLFlBQVksWUFBWSxNQUFNLE9BQU8sS0FBSztNQUMvRCxnQkFBYyxRQUFRLFlBQVksUUFBUTtnQkFKNUMsQ0FNRSx3QkFBQyxVQUFEO09BQVEsT0FBTTtpQkFBRztNQUE0Qjs7OztnQkFDNUMsaUJBQWlCLEtBQUssYUFDckIsd0JBQUMsVUFBRDtPQUF1QixPQUFPO2lCQUFXO01BQWlCLEdBQTdDOzs7O2FBQTZDLENBQzNELENBQ0s7Ozs7OztLQUNSLHdCQUFDLGtCQUFELEVBQWtCLFNBQVMsWUFBWSxTQUFXOzs7OztJQUM3Qzs7Ozs7O0dBRVAsd0JBQUMsU0FBRDtJQUFPLFNBQVE7Y0FBZjtLQUEwQjtLQUV4Qix3QkFBQyxVQUFEO01BQ0UsSUFBRztNQUNILE9BQU8sV0FBVztNQUNsQixXQUFXLFVBQVUsWUFBWSxZQUFZLE1BQU0sT0FBTyxLQUFLO01BQy9ELGdCQUFjLFFBQVEsWUFBWSxRQUFRO2dCQUo1QyxDQU1FLHdCQUFDLFVBQUQ7T0FBUSxPQUFNO2lCQUFHO01BQTRCOzs7O2dCQUM1QyxpQkFBaUIsS0FBSyxhQUNyQix3QkFBQyxVQUFEO09BQXVCLE9BQU87aUJBQVc7TUFBaUIsR0FBN0M7Ozs7YUFBNkMsQ0FDM0QsQ0FDSzs7Ozs7O0tBQ1Isd0JBQUMsa0JBQUQsRUFBa0IsU0FBUyxZQUFZLFNBQVc7Ozs7O0lBQzdDOzs7Ozs7R0FFUCx3QkFBQyxTQUFEO0lBQU8sU0FBUTtjQUFmO0tBQXdCO0tBRXRCLHdCQUFDLFVBQUQ7TUFDRSxJQUFHO01BQ0gsT0FBTyxXQUFXO01BQ2xCLFdBQVcsVUFBVSxZQUFZLFVBQVUsTUFBTSxPQUFPLEtBQUs7TUFDN0QsZ0JBQWMsUUFBUSxZQUFZLE1BQU07Z0JBSjFDLENBTUUsd0JBQUMsVUFBRDtPQUFRLE9BQU07aUJBQUc7TUFBMEI7Ozs7Z0JBQzFDLGVBQWUsS0FBSyxXQUNuQix3QkFBQyxVQUFEO09BQXFCLE9BQU87aUJBQVM7TUFBZSxHQUF2Qzs7OzthQUF1QyxDQUNyRCxDQUNLOzs7Ozs7S0FDUix3QkFBQyxrQkFBRCxFQUFrQixTQUFTLFlBQVksT0FBUzs7Ozs7SUFDM0M7Ozs7OztHQUVQLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsVUFBRDtLQUFRLE1BQUs7S0FBUyxXQUFVO0tBQWMsVUFBVTtlQUNyRCxTQUFTLGNBQWM7SUFDbEI7Ozs7O0dBQ0w7Ozs7O0VBQ0Q7Ozs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlRpY2tldEZvcm1XaXphcmQuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IElubGluZUZpZWxkRXJyb3IgZnJvbSAnLi9JbmxpbmVGaWVsZEVycm9yLmpzeCc7XG5cbmNvbnN0IENBVEVHT1JZX09QVElPTlMgPSBbJ0VtYWlsJywgJ0hhcmR3YXJlJywgJ1NvZnR3YXJlJywgJ05ldHdvcmsnLCAnQWNjb3VudCddO1xuY29uc3QgUFJJT1JJVFlfT1BUSU9OUyA9IFsnSElHSCcsICdNRURJVU0nLCAnTE9XJ107XG4vLyBNdXN0IG1hdGNoIHRoZSBzdGF0dXNlcyBhY2NlcHRlZCBieSB0aGUgYmFja2VuZCBUaWNrZXRTZXJ2aWNlXG5jb25zdCBTVEFUVVNfT1BUSU9OUyA9IFsnT1BFTicsICdJTl9QUk9HUkVTUycsICdDTE9TRUQnXTtcblxuZXhwb3J0IGNvbnN0IGVtcHR5VGlja2V0Rm9ybSA9IHtcbiAgdGl0bGU6ICcnLFxuICBkZXNjcmlwdGlvbjogJycsXG4gIGNhdGVnb3J5OiAnJyxcbiAgcHJpb3JpdHk6ICcnLFxuICBzdGF0dXM6ICcnXG59O1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBUaWNrZXRGb3JtV2l6YXJkKHtcbiAgaW5pdGlhbFZhbHVlcyA9IGVtcHR5VGlja2V0Rm9ybSxcbiAgb25TdWJtaXQsXG4gIHNhdmluZyA9IGZhbHNlLFxuICBzdWJtaXRMYWJlbCA9ICdDcmVhdGUgVGlja2V0J1xufSkge1xuICBjb25zdCBbZm9ybVZhbHVlcywgc2V0Rm9ybVZhbHVlc10gPSB1c2VTdGF0ZSh7IC4uLmVtcHR5VGlja2V0Rm9ybSwgLi4uaW5pdGlhbFZhbHVlcyB9KTtcbiAgY29uc3QgW2ZpZWxkRXJyb3JzLCBzZXRGaWVsZEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XG5cbiAgZnVuY3Rpb24gdXBkYXRlRmllbGQoZmllbGROYW1lLCB2YWx1ZSkge1xuICAgIHNldEZvcm1WYWx1ZXMoKGN1cnJlbnQpID0+ICh7XG4gICAgICAuLi5jdXJyZW50LFxuICAgICAgW2ZpZWxkTmFtZV06IHZhbHVlXG4gICAgfSkpO1xuXG4gICAgLy8gQ2xlYXIgdGhlIGVycm9yIGZvciBhIGZpZWxkIGFzIHNvb24gYXMgdGhlIHVzZXIgZWRpdHMgaXRcbiAgICBzZXRGaWVsZEVycm9ycygoY3VycmVudCkgPT4gKHtcbiAgICAgIC4uLmN1cnJlbnQsXG4gICAgICBbZmllbGROYW1lXTogJydcbiAgICB9KSk7XG4gIH1cblxuICBmdW5jdGlvbiB2YWxpZGF0ZUZvcm0oKSB7XG4gICAgY29uc3QgZXJyb3JzID0ge307XG5cbiAgICBpZiAoIWZvcm1WYWx1ZXMudGl0bGUudHJpbSgpKSB7XG4gICAgICBlcnJvcnMudGl0bGUgPSAnVGl0bGUgaXMgcmVxdWlyZWQuJztcbiAgICB9XG5cbiAgICBpZiAoIWZvcm1WYWx1ZXMuZGVzY3JpcHRpb24udHJpbSgpKSB7XG4gICAgICBlcnJvcnMuZGVzY3JpcHRpb24gPSAnRGVzY3JpcHRpb24gaXMgcmVxdWlyZWQuJztcbiAgICB9XG5cbiAgICBpZiAoIWZvcm1WYWx1ZXMuY2F0ZWdvcnkpIHtcbiAgICAgIGVycm9ycy5jYXRlZ29yeSA9ICdDYXRlZ29yeSBpcyByZXF1aXJlZC4nO1xuICAgIH1cblxuICAgIGlmICghZm9ybVZhbHVlcy5wcmlvcml0eSkge1xuICAgICAgZXJyb3JzLnByaW9yaXR5ID0gJ1ByaW9yaXR5IGlzIHJlcXVpcmVkLic7XG4gICAgfVxuXG4gICAgaWYgKCFmb3JtVmFsdWVzLnN0YXR1cykge1xuICAgICAgZXJyb3JzLnN0YXR1cyA9ICdTdGF0dXMgaXMgcmVxdWlyZWQuJztcbiAgICB9XG5cbiAgICBzZXRGaWVsZEVycm9ycyhlcnJvcnMpO1xuICAgIHJldHVybiBPYmplY3Qua2V5cyhlcnJvcnMpLmxlbmd0aCA9PT0gMDtcbiAgfVxuXG4gIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChldmVudCkge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG5cbiAgICAvLyBCbG9jayBzdWJtaXNzaW9uIHdoZW4gYW55IHJlcXVpcmVkIGZpZWxkIGlzIGVtcHR5XG4gICAgaWYgKCF2YWxpZGF0ZUZvcm0oKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IHBheWxvYWQgPSB7XG4gICAgICB0aXRsZTogZm9ybVZhbHVlcy50aXRsZS50cmltKCksXG4gICAgICBkZXNjcmlwdGlvbjogZm9ybVZhbHVlcy5kZXNjcmlwdGlvbi50cmltKCksXG4gICAgICBjYXRlZ29yeTogZm9ybVZhbHVlcy5jYXRlZ29yeSxcbiAgICAgIHByaW9yaXR5OiBmb3JtVmFsdWVzLnByaW9yaXR5LFxuICAgICAgc3RhdHVzOiBmb3JtVmFsdWVzLnN0YXR1c1xuICAgIH07XG5cbiAgICBpZiAob25TdWJtaXQpIHtcbiAgICAgIG9uU3VibWl0KHBheWxvYWQpO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGZvcm0gY2xhc3NOYW1lPVwiY2FyZCB0aWNrZXQtZm9ybVwiIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IG5vVmFsaWRhdGU+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24taGVhZGluZ1wiPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJleWVicm93XCI+RGF5IDEzIGZvcm08L3A+XG4gICAgICAgIDxoMj5UaWNrZXQgRGV0YWlsczwvaDI+XG4gICAgICAgIDxwPkNvbnRyb2xsZWQgaW5wdXRzIGJhY2tlZCBieSBSZWFjdCBzdGF0ZSwgd2l0aCBjbGllbnQtc2lkZSB2YWxpZGF0aW9uIGFuZCBpbmxpbmUgZXJyb3JzLjwvcD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8bGFiZWwgaHRtbEZvcj1cInRpdGxlXCI+XG4gICAgICAgIFRpdGxlXG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIGlkPVwidGl0bGVcIlxuICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICB2YWx1ZT17Zm9ybVZhbHVlcy50aXRsZX1cbiAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiB1cGRhdGVGaWVsZCgndGl0bGUnLCBldmVudC50YXJnZXQudmFsdWUpfVxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2hvcnQgc3VtbWFyeSBvZiB0aGUgaXNzdWVcIlxuICAgICAgICAgIGFyaWEtaW52YWxpZD17Qm9vbGVhbihmaWVsZEVycm9ycy50aXRsZSl9XG4gICAgICAgIC8+XG4gICAgICAgIDxJbmxpbmVGaWVsZEVycm9yIG1lc3NhZ2U9e2ZpZWxkRXJyb3JzLnRpdGxlfSAvPlxuICAgICAgPC9sYWJlbD5cblxuICAgICAgPGxhYmVsIGh0bWxGb3I9XCJkZXNjcmlwdGlvblwiPlxuICAgICAgICBEZXNjcmlwdGlvblxuICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICBpZD1cImRlc2NyaXB0aW9uXCJcbiAgICAgICAgICByb3dzPXs0fVxuICAgICAgICAgIHZhbHVlPXtmb3JtVmFsdWVzLmRlc2NyaXB0aW9ufVxuICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHVwZGF0ZUZpZWxkKCdkZXNjcmlwdGlvbicsIGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJEZXNjcmliZSB0aGUgcHJvYmxlbSBpbiBtb3JlIGRldGFpbFwiXG4gICAgICAgICAgYXJpYS1pbnZhbGlkPXtCb29sZWFuKGZpZWxkRXJyb3JzLmRlc2NyaXB0aW9uKX1cbiAgICAgICAgLz5cbiAgICAgICAgPElubGluZUZpZWxkRXJyb3IgbWVzc2FnZT17ZmllbGRFcnJvcnMuZGVzY3JpcHRpb259IC8+XG4gICAgICA8L2xhYmVsPlxuXG4gICAgICA8bGFiZWwgaHRtbEZvcj1cImNhdGVnb3J5XCI+XG4gICAgICAgIENhdGVnb3J5XG4gICAgICAgIDxzZWxlY3RcbiAgICAgICAgICBpZD1cImNhdGVnb3J5XCJcbiAgICAgICAgICB2YWx1ZT17Zm9ybVZhbHVlcy5jYXRlZ29yeX1cbiAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiB1cGRhdGVGaWVsZCgnY2F0ZWdvcnknLCBldmVudC50YXJnZXQudmFsdWUpfVxuICAgICAgICAgIGFyaWEtaW52YWxpZD17Qm9vbGVhbihmaWVsZEVycm9ycy5jYXRlZ29yeSl9XG4gICAgICAgID5cbiAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IGEgY2F0ZWdvcnkuLi48L29wdGlvbj5cbiAgICAgICAgICB7Q0FURUdPUllfT1BUSU9OUy5tYXAoKGNhdGVnb3J5KSA9PiAoXG4gICAgICAgICAgICA8b3B0aW9uIGtleT17Y2F0ZWdvcnl9IHZhbHVlPXtjYXRlZ29yeX0+e2NhdGVnb3J5fTwvb3B0aW9uPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgPElubGluZUZpZWxkRXJyb3IgbWVzc2FnZT17ZmllbGRFcnJvcnMuY2F0ZWdvcnl9IC8+XG4gICAgICA8L2xhYmVsPlxuXG4gICAgICA8bGFiZWwgaHRtbEZvcj1cInByaW9yaXR5XCI+XG4gICAgICAgIFByaW9yaXR5XG4gICAgICAgIDxzZWxlY3RcbiAgICAgICAgICBpZD1cInByaW9yaXR5XCJcbiAgICAgICAgICB2YWx1ZT17Zm9ybVZhbHVlcy5wcmlvcml0eX1cbiAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiB1cGRhdGVGaWVsZCgncHJpb3JpdHknLCBldmVudC50YXJnZXQudmFsdWUpfVxuICAgICAgICAgIGFyaWEtaW52YWxpZD17Qm9vbGVhbihmaWVsZEVycm9ycy5wcmlvcml0eSl9XG4gICAgICAgID5cbiAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IGEgcHJpb3JpdHkuLi48L29wdGlvbj5cbiAgICAgICAgICB7UFJJT1JJVFlfT1BUSU9OUy5tYXAoKHByaW9yaXR5KSA9PiAoXG4gICAgICAgICAgICA8b3B0aW9uIGtleT17cHJpb3JpdHl9IHZhbHVlPXtwcmlvcml0eX0+e3ByaW9yaXR5fTwvb3B0aW9uPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgPElubGluZUZpZWxkRXJyb3IgbWVzc2FnZT17ZmllbGRFcnJvcnMucHJpb3JpdHl9IC8+XG4gICAgICA8L2xhYmVsPlxuXG4gICAgICA8bGFiZWwgaHRtbEZvcj1cInN0YXR1c1wiPlxuICAgICAgICBTdGF0dXNcbiAgICAgICAgPHNlbGVjdFxuICAgICAgICAgIGlkPVwic3RhdHVzXCJcbiAgICAgICAgICB2YWx1ZT17Zm9ybVZhbHVlcy5zdGF0dXN9XG4gICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gdXBkYXRlRmllbGQoJ3N0YXR1cycsIGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgYXJpYS1pbnZhbGlkPXtCb29sZWFuKGZpZWxkRXJyb3JzLnN0YXR1cyl9XG4gICAgICAgID5cbiAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IGEgc3RhdHVzLi4uPC9vcHRpb24+XG4gICAgICAgICAge1NUQVRVU19PUFRJT05TLm1hcCgoc3RhdHVzKSA9PiAoXG4gICAgICAgICAgICA8b3B0aW9uIGtleT17c3RhdHVzfSB2YWx1ZT17c3RhdHVzfT57c3RhdHVzfTwvb3B0aW9uPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgPElubGluZUZpZWxkRXJyb3IgbWVzc2FnZT17ZmllbGRFcnJvcnMuc3RhdHVzfSAvPlxuICAgICAgPC9sYWJlbD5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWFjdGlvbnNcIj5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwiYnV0dG9uLWxpbmtcIiBkaXNhYmxlZD17c2F2aW5nfT5cbiAgICAgICAgICB7c2F2aW5nID8gJ1NhdmluZy4uLicgOiBzdWJtaXRMYWJlbH1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Zvcm0+XG4gICk7XG59XG4iXX0=