import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AppShell.jsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { NavLink, Outlet, useNavigate } from "/node_modules/.vite/deps/react-router.js?v=3927c5ff";
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/AppShell.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3927c5ff";
var _s = $RefreshSig$();
export default function AppShell() {
	_s();
	const { user, logout } = useAuth();
	const navigate = useNavigate();
	function handleLogout() {
		logout();
		navigate("/login", { replace: true });
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "app-shell",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "app-header",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("p", {
						className: "eyebrow",
						children: "Day 12 Routing & Protected Views"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 17,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 18,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", { children: "Support Desk UI" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 19,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 20,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "header-subtitle",
						children: "Nested routes, guarded pages, login redirect flow and protected backend data."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 21,
						columnNumber: 11
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 16,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "user-panel",
					children: [
						/* @__PURE__ */ _jsxDEV("span", { children: user?.name }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 26,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("strong", { children: user?.role }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 27,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handleLogout,
							children: "Logout"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 28,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("nav", {
				className: "app-nav",
				"aria-label": "Main navigation",
				children: [
					/* @__PURE__ */ _jsxDEV(NavLink, {
						to: "/app/dashboard",
						children: "Dashboard"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 33,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(NavLink, {
						to: "/app/tickets",
						children: "Tickets"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(NavLink, {
						to: "/app/tickets/new",
						children: "New Ticket"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(NavLink, {
						to: "/app/reports",
						children: "Reports"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 36,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", { children: /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 9
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 5
	}, this);
}
_s(AppShell, "gdMNr7PmFUHK6Y0R8aLYpBa+3SU=", false, function() {
	return [useAuth, useNavigate];
});
_c = AppShell;
var _c;
$RefreshReg$(_c, "AppShell");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/AppShell.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/AppShell.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/AppShell.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/AppShell.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxTQUFTLFFBQVEsbUJBQW1CO0FBQzdDLFNBQVMsZUFBZTs7OztBQUV4QixlQUFlLFNBQVMsV0FBVzs7Q0FDakMsTUFBTSxFQUFFLE1BQU0sV0FBVyxRQUFRO0NBQ2pDLE1BQU0sV0FBVyxZQUFZO0NBRTdCLFNBQVMsZUFBZTtFQUN0QixPQUFPO0VBQ1AsU0FBUyxVQUFVLEVBQUUsU0FBUyxLQUFLLENBQUM7Q0FDdEM7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxVQUFEO0lBQVEsV0FBVTtjQUFsQixDQUNFLHdCQUFDLE9BQUQ7S0FDRSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBVTtLQUFtQzs7Ozs7S0FDMUQsd0JBQUMsTUFBRCxDQUFJOzs7OztLQUNKLHdCQUFDLE1BQUQsWUFBSSxrQkFBbUI7Ozs7O0tBQ3ZCLHdCQUFDLE1BQUQsQ0FBSTs7Ozs7S0FDSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBa0I7S0FFNUI7Ozs7O0lBQ0E7Ozs7Y0FDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsUUFBRCxZQUFPLE1BQU0sS0FBVzs7Ozs7TUFDeEIsd0JBQUMsVUFBRCxZQUFTLE1BQU0sS0FBYTs7Ozs7TUFDNUIsd0JBQUMsVUFBRDtPQUFRLE1BQUs7T0FBUyxTQUFTO2lCQUFjO01BQWM7Ozs7O0tBQ3hEOzs7OztZQUNDOzs7Ozs7R0FFUix3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFVLGNBQVc7Y0FBcEM7S0FDRSx3QkFBQyxTQUFEO01BQVMsSUFBRztnQkFBaUI7S0FBa0I7Ozs7O0tBQy9DLHdCQUFDLFNBQUQ7TUFBUyxJQUFHO2dCQUFlO0tBQWdCOzs7OztLQUMzQyx3QkFBQyxTQUFEO01BQVMsSUFBRztnQkFBbUI7S0FBbUI7Ozs7O0tBQ2xELHdCQUFDLFNBQUQ7TUFBUyxJQUFHO2dCQUFlO0tBQWdCOzs7OztJQUN4Qzs7Ozs7O0dBRUwsd0JBQUMsUUFBRCxZQUNFLHdCQUFDLFFBQUQsQ0FBUzs7OztZQUNMOzs7OztFQUNIOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHBTaGVsbC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmF2TGluaywgT3V0bGV0LCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlcic7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vY29udGV4dC9BdXRoQ29udGV4dC5qc3gnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHBTaGVsbCgpIHtcbiAgY29uc3QgeyB1c2VyLCBsb2dvdXQgfSA9IHVzZUF1dGgoKTtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuXG4gIGZ1bmN0aW9uIGhhbmRsZUxvZ291dCgpIHtcbiAgICBsb2dvdXQoKTtcbiAgICBuYXZpZ2F0ZSgnL2xvZ2luJywgeyByZXBsYWNlOiB0cnVlIH0pO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImFwcC1zaGVsbFwiPlxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJhcHAtaGVhZGVyXCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZXllYnJvd1wiPkRheSAxMiBSb3V0aW5nICYgUHJvdGVjdGVkIFZpZXdzPC9wPlxuICAgICAgICAgIDxici8+XG4gICAgICAgICAgPGgxPlN1cHBvcnQgRGVzayBVSTwvaDE+XG4gICAgICAgICAgPGJyLz5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJoZWFkZXItc3VidGl0bGVcIj5cbiAgICAgICAgICAgIE5lc3RlZCByb3V0ZXMsIGd1YXJkZWQgcGFnZXMsIGxvZ2luIHJlZGlyZWN0IGZsb3cgYW5kIHByb3RlY3RlZCBiYWNrZW5kIGRhdGEuXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1c2VyLXBhbmVsXCI+XG4gICAgICAgICAgPHNwYW4+e3VzZXI/Lm5hbWV9PC9zcGFuPlxuICAgICAgICAgIDxzdHJvbmc+e3VzZXI/LnJvbGV9PC9zdHJvbmc+XG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17aGFuZGxlTG9nb3V0fT5Mb2dvdXQ8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2hlYWRlcj5cblxuICAgICAgPG5hdiBjbGFzc05hbWU9XCJhcHAtbmF2XCIgYXJpYS1sYWJlbD1cIk1haW4gbmF2aWdhdGlvblwiPlxuICAgICAgICA8TmF2TGluayB0bz1cIi9hcHAvZGFzaGJvYXJkXCI+RGFzaGJvYXJkPC9OYXZMaW5rPlxuICAgICAgICA8TmF2TGluayB0bz1cIi9hcHAvdGlja2V0c1wiPlRpY2tldHM8L05hdkxpbms+XG4gICAgICAgIDxOYXZMaW5rIHRvPVwiL2FwcC90aWNrZXRzL25ld1wiPk5ldyBUaWNrZXQ8L05hdkxpbms+XG4gICAgICAgIDxOYXZMaW5rIHRvPVwiL2FwcC9yZXBvcnRzXCI+UmVwb3J0czwvTmF2TGluaz5cbiAgICAgIDwvbmF2PlxuXG4gICAgICA8bWFpbj5cbiAgICAgICAgPE91dGxldCAvPlxuICAgICAgPC9tYWluPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl19