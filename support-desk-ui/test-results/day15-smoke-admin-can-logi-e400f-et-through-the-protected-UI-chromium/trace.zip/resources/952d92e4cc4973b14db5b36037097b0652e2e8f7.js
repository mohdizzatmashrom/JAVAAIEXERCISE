import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/AuthContext.jsx");const createContext = __vite__cjsImport0_react["createContext"]; const useContext = __vite__cjsImport0_react["useContext"]; const useMemo = __vite__cjsImport0_react["useMemo"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=3927c5ff";
import { loginRequest } from "/src/services/api.js";
var _jsxFileName = "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/context/AuthContext.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3927c5ff";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const STORAGE_KEY = "supportDeskAuth";
const AuthContext = createContext(null);
_c = AuthContext;
function readStoredAuth() {
	try {
		const stored = localStorage.getItem(STORAGE_KEY);
		return stored ? JSON.parse(stored) : null;
	} catch {
		return null;
	}
}
export function AuthProvider({ children }) {
	_s();
	const [auth, setAuth] = useState(readStoredAuth);
	async function login(email, password) {
		const response = await loginRequest(email, password);
		const nextAuth = {
			token: response.token,
			tokenType: response.tokenType,
			expiresInMinutes: response.expiresInMinutes,
			user: {
				id: response.userId,
				name: response.name,
				email: response.email,
				role: response.role
			}
		};
		localStorage.setItem(STORAGE_KEY, JSON.stringify(nextAuth));
		setAuth(nextAuth);
		return nextAuth;
	}
	function logout() {
		localStorage.removeItem(STORAGE_KEY);
		setAuth(null);
	}
	const value = useMemo(() => ({
		auth,
		token: auth?.token ?? "",
		user: auth?.user ?? null,
		isAuthenticated: Boolean(auth?.token),
		login,
		logout
	}), [auth]);
	return /* @__PURE__ */ _jsxDEV(AuthContext.Provider, {
		value,
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 56,
		columnNumber: 10
	}, this);
}
_s(AuthProvider, "vZKS7i7XlQ8m6R95c8DjJ4+Nx4Y=");
_c2 = AuthProvider;
export function useAuth() {
	_s2();
	const value = useContext(AuthContext);
	if (!value) {
		throw new Error("useAuth must be used inside AuthProvider");
	}
	return value;
}
_s2(useAuth, "ksutO2/Ix3UeCrGnhyM+QEP505Y=");
var _c, _c2;
$RefreshReg$(_c, "AuthContext");
$RefreshReg$(_c2, "AuthProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/context/AuthContext.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/context/AuthContext.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/context/AuthContext.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/context/AuthContext.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlLFlBQVksU0FBUyxnQkFBZ0I7QUFDN0QsU0FBUyxvQkFBb0I7Ozs7QUFFN0IsTUFBTSxjQUFjO0FBQ3BCLE1BQU0sY0FBYyxjQUFjLElBQUk7O0FBRXRDLFNBQVMsaUJBQWlCO0NBQ3hCLElBQUk7RUFDRixNQUFNLFNBQVMsYUFBYSxRQUFRLFdBQVc7RUFDL0MsT0FBTyxTQUFTLEtBQUssTUFBTSxNQUFNLElBQUk7Q0FDdkMsUUFBUTtFQUNOLE9BQU87Q0FDVDtBQUNGO0FBRUEsT0FBTyxTQUFTLGFBQWEsRUFBRSxZQUFZOztDQUN6QyxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsY0FBYztDQUUvQyxlQUFlLE1BQU0sT0FBTyxVQUFVO0VBQ3BDLE1BQU0sV0FBVyxNQUFNLGFBQWEsT0FBTyxRQUFRO0VBRW5ELE1BQU0sV0FBVztHQUNmLE9BQU8sU0FBUztHQUNoQixXQUFXLFNBQVM7R0FDcEIsa0JBQWtCLFNBQVM7R0FDM0IsTUFBTTtJQUNKLElBQUksU0FBUztJQUNiLE1BQU0sU0FBUztJQUNmLE9BQU8sU0FBUztJQUNoQixNQUFNLFNBQVM7R0FDakI7RUFDRjtFQUVBLGFBQWEsUUFBUSxhQUFhLEtBQUssVUFBVSxRQUFRLENBQUM7RUFDMUQsUUFBUSxRQUFRO0VBQ2hCLE9BQU87Q0FDVDtDQUVBLFNBQVMsU0FBUztFQUNoQixhQUFhLFdBQVcsV0FBVztFQUNuQyxRQUFRLElBQUk7Q0FDZDtDQUVBLE1BQU0sUUFBUSxlQUNMO0VBQ0w7RUFDQSxPQUFPLE1BQU0sU0FBUztFQUN0QixNQUFNLE1BQU0sUUFBUTtFQUNwQixpQkFBaUIsUUFBUSxNQUFNLEtBQUs7RUFDcEM7RUFDQTtDQUNGLElBQ0EsQ0FBQyxJQUFJLENBQ1A7Q0FFQSxPQUFPLHdCQUFDLFlBQVksVUFBYjtFQUE2QjtFQUFRO0NBQStCOzs7OztBQUM3RTs7O0FBRUEsT0FBTyxTQUFTLFVBQVU7O0NBQ3hCLE1BQU0sUUFBUSxXQUFXLFdBQVc7Q0FFcEMsSUFBSSxDQUFDLE9BQU87RUFDVixNQUFNLElBQUksTUFBTSwwQ0FBMEM7Q0FDNUQ7Q0FFQSxPQUFPO0FBQ1QiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXV0aENvbnRleHQuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUNvbnRleHQsIHVzZUNvbnRleHQsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgbG9naW5SZXF1ZXN0IH0gZnJvbSAnLi4vc2VydmljZXMvYXBpLmpzJztcblxuY29uc3QgU1RPUkFHRV9LRVkgPSAnc3VwcG9ydERlc2tBdXRoJztcbmNvbnN0IEF1dGhDb250ZXh0ID0gY3JlYXRlQ29udGV4dChudWxsKTtcblxuZnVuY3Rpb24gcmVhZFN0b3JlZEF1dGgoKSB7XG4gIHRyeSB7XG4gICAgY29uc3Qgc3RvcmVkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oU1RPUkFHRV9LRVkpO1xuICAgIHJldHVybiBzdG9yZWQgPyBKU09OLnBhcnNlKHN0b3JlZCkgOiBudWxsO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gQXV0aFByb3ZpZGVyKHsgY2hpbGRyZW4gfSkge1xuICBjb25zdCBbYXV0aCwgc2V0QXV0aF0gPSB1c2VTdGF0ZShyZWFkU3RvcmVkQXV0aCk7XG5cbiAgYXN5bmMgZnVuY3Rpb24gbG9naW4oZW1haWwsIHBhc3N3b3JkKSB7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBsb2dpblJlcXVlc3QoZW1haWwsIHBhc3N3b3JkKTtcblxuICAgIGNvbnN0IG5leHRBdXRoID0ge1xuICAgICAgdG9rZW46IHJlc3BvbnNlLnRva2VuLFxuICAgICAgdG9rZW5UeXBlOiByZXNwb25zZS50b2tlblR5cGUsXG4gICAgICBleHBpcmVzSW5NaW51dGVzOiByZXNwb25zZS5leHBpcmVzSW5NaW51dGVzLFxuICAgICAgdXNlcjoge1xuICAgICAgICBpZDogcmVzcG9uc2UudXNlcklkLFxuICAgICAgICBuYW1lOiByZXNwb25zZS5uYW1lLFxuICAgICAgICBlbWFpbDogcmVzcG9uc2UuZW1haWwsXG4gICAgICAgIHJvbGU6IHJlc3BvbnNlLnJvbGVcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oU1RPUkFHRV9LRVksIEpTT04uc3RyaW5naWZ5KG5leHRBdXRoKSk7XG4gICAgc2V0QXV0aChuZXh0QXV0aCk7XG4gICAgcmV0dXJuIG5leHRBdXRoO1xuICB9XG5cbiAgZnVuY3Rpb24gbG9nb3V0KCkge1xuICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKFNUT1JBR0VfS0VZKTtcbiAgICBzZXRBdXRoKG51bGwpO1xuICB9XG5cbiAgY29uc3QgdmFsdWUgPSB1c2VNZW1vKFxuICAgICgpID0+ICh7XG4gICAgICBhdXRoLFxuICAgICAgdG9rZW46IGF1dGg/LnRva2VuID8/ICcnLFxuICAgICAgdXNlcjogYXV0aD8udXNlciA/PyBudWxsLFxuICAgICAgaXNBdXRoZW50aWNhdGVkOiBCb29sZWFuKGF1dGg/LnRva2VuKSxcbiAgICAgIGxvZ2luLFxuICAgICAgbG9nb3V0XG4gICAgfSksXG4gICAgW2F1dGhdXG4gICk7XG5cbiAgcmV0dXJuIDxBdXRoQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17dmFsdWV9PntjaGlsZHJlbn08L0F1dGhDb250ZXh0LlByb3ZpZGVyPjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUF1dGgoKSB7XG4gIGNvbnN0IHZhbHVlID0gdXNlQ29udGV4dChBdXRoQ29udGV4dCk7XG5cbiAgaWYgKCF2YWx1ZSkge1xuICAgIHRocm93IG5ldyBFcnJvcigndXNlQXV0aCBtdXN0IGJlIHVzZWQgaW5zaWRlIEF1dGhQcm92aWRlcicpO1xuICB9XG5cbiAgcmV0dXJuIHZhbHVlO1xufVxuIl19