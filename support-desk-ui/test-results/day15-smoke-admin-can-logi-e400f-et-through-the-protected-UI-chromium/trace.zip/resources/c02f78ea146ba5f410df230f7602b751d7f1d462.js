import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TicketFilterPanel.jsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/TicketFilterPanel.jsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3927c5ff";
export default function TicketFilterPanel({ searchText, onSearchChange, statusFilter, onStatusChange, sortBy, onSortByChange, direction, onDirectionChange, pageSize, onPageSizeChange }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "filter-panel",
		children: [
			/* @__PURE__ */ _jsxDEV("input", {
				type: "text",
				className: "filter-input",
				placeholder: "Search by title or category...",
				value: searchText,
				onChange: (e) => onSearchChange(e.target.value)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("select", {
				className: "filter-select",
				value: statusFilter,
				onChange: (e) => onStatusChange(e.target.value),
				children: [
					/* @__PURE__ */ _jsxDEV("option", {
						value: "",
						children: "All Statuses"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 28,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("option", {
						value: "OPEN",
						children: "Open"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 29,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("option", {
						value: "IN_PROGRESS",
						children: "In Progress"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 30,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("option", {
						value: "CLOSED",
						children: "Closed"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 31,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("select", {
				className: "filter-select",
				value: sortBy,
				onChange: (e) => onSortByChange(e.target.value),
				children: [
					/* @__PURE__ */ _jsxDEV("option", {
						value: "createdAt",
						children: "Date Created"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 39,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("option", {
						value: "title",
						children: "Title"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("option", {
						value: "priority",
						children: "Priority"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("option", {
						value: "status",
						children: "Status"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 42,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("select", {
				className: "filter-select",
				value: direction,
				onChange: (e) => onDirectionChange(e.target.value),
				children: [/* @__PURE__ */ _jsxDEV("option", {
					value: "desc",
					children: "Newest First"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("option", {
					value: "asc",
					children: "Oldest First"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 51,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 45,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("select", {
				className: "filter-select",
				value: pageSize,
				onChange: (e) => onPageSizeChange(Number(e.target.value)),
				children: [
					/* @__PURE__ */ _jsxDEV("option", {
						value: 5,
						children: "5 per page"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("option", {
						value: 10,
						children: "10 per page"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("option", {
						value: 20,
						children: "20 per page"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 5
	}, this);
}
_c = TicketFilterPanel;
var _c;
$RefreshReg$(_c, "TicketFilterPanel");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/TicketFilterPanel.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/TicketFilterPanel.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/TicketFilterPanel.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/TicketFilterPanel.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFBQSxlQUFlLFNBQVMsa0JBQWtCLEVBQ3hDLFlBQ0EsZ0JBQ0EsY0FDQSxnQkFDQSxRQUNBLGdCQUNBLFdBQ0EsbUJBQ0EsVUFDQSxvQkFDQztDQUNELE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNFLHdCQUFDLFNBQUQ7SUFDRSxNQUFLO0lBQ0wsV0FBVTtJQUNWLGFBQVk7SUFDWixPQUFPO0lBQ1AsV0FBVyxNQUFNLGVBQWUsRUFBRSxPQUFPLEtBQUs7R0FDL0M7Ozs7O0dBRUQsd0JBQUMsVUFBRDtJQUNFLFdBQVU7SUFDVixPQUFPO0lBQ1AsV0FBVyxNQUFNLGVBQWUsRUFBRSxPQUFPLEtBQUs7Y0FIaEQ7S0FLRSx3QkFBQyxVQUFEO01BQVEsT0FBTTtnQkFBRztLQUFvQjs7Ozs7S0FDckMsd0JBQUMsVUFBRDtNQUFRLE9BQU07Z0JBQU87S0FBWTs7Ozs7S0FDakMsd0JBQUMsVUFBRDtNQUFRLE9BQU07Z0JBQWM7S0FBbUI7Ozs7O0tBQy9DLHdCQUFDLFVBQUQ7TUFBUSxPQUFNO2dCQUFTO0tBQWM7Ozs7O0lBQy9COzs7Ozs7R0FFUix3QkFBQyxVQUFEO0lBQ0UsV0FBVTtJQUNWLE9BQU87SUFDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztjQUhoRDtLQUtFLHdCQUFDLFVBQUQ7TUFBUSxPQUFNO2dCQUFZO0tBQW9COzs7OztLQUM5Qyx3QkFBQyxVQUFEO01BQVEsT0FBTTtnQkFBUTtLQUFhOzs7OztLQUNuQyx3QkFBQyxVQUFEO01BQVEsT0FBTTtnQkFBVztLQUFnQjs7Ozs7S0FDekMsd0JBQUMsVUFBRDtNQUFRLE9BQU07Z0JBQVM7S0FBYzs7Ozs7SUFDL0I7Ozs7OztHQUVSLHdCQUFDLFVBQUQ7SUFDRSxXQUFVO0lBQ1YsT0FBTztJQUNQLFdBQVcsTUFBTSxrQkFBa0IsRUFBRSxPQUFPLEtBQUs7Y0FIbkQsQ0FLRSx3QkFBQyxVQUFEO0tBQVEsT0FBTTtlQUFPO0lBQW9COzs7O2NBQ3pDLHdCQUFDLFVBQUQ7S0FBUSxPQUFNO2VBQU07SUFBb0I7Ozs7WUFDbEM7Ozs7OztHQUVSLHdCQUFDLFVBQUQ7SUFDRSxXQUFVO0lBQ1YsT0FBTztJQUNQLFdBQVcsTUFBTSxpQkFBaUIsT0FBTyxFQUFFLE9BQU8sS0FBSyxDQUFDO2NBSDFEO0tBS0Usd0JBQUMsVUFBRDtNQUFRLE9BQU87Z0JBQUc7S0FBa0I7Ozs7O0tBQ3BDLHdCQUFDLFVBQUQ7TUFBUSxPQUFPO2dCQUFJO0tBQW1COzs7OztLQUN0Qyx3QkFBQyxVQUFEO01BQVEsT0FBTztnQkFBSTtLQUFtQjs7Ozs7SUFDaEM7Ozs7OztFQUNMOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJUaWNrZXRGaWx0ZXJQYW5lbC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gVGlja2V0RmlsdGVyUGFuZWwoe1xuICBzZWFyY2hUZXh0LFxuICBvblNlYXJjaENoYW5nZSxcbiAgc3RhdHVzRmlsdGVyLFxuICBvblN0YXR1c0NoYW5nZSxcbiAgc29ydEJ5LFxuICBvblNvcnRCeUNoYW5nZSxcbiAgZGlyZWN0aW9uLFxuICBvbkRpcmVjdGlvbkNoYW5nZSxcbiAgcGFnZVNpemUsXG4gIG9uUGFnZVNpemVDaGFuZ2Vcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpbHRlci1wYW5lbFwiPlxuICAgICAgPGlucHV0XG4gICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgY2xhc3NOYW1lPVwiZmlsdGVyLWlucHV0XCJcbiAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggYnkgdGl0bGUgb3IgY2F0ZWdvcnkuLi5cIlxuICAgICAgICB2YWx1ZT17c2VhcmNoVGV4dH1cbiAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvblNlYXJjaENoYW5nZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAvPlxuXG4gICAgICA8c2VsZWN0XG4gICAgICAgIGNsYXNzTmFtZT1cImZpbHRlci1zZWxlY3RcIlxuICAgICAgICB2YWx1ZT17c3RhdHVzRmlsdGVyfVxuICAgICAgICBvbkNoYW5nZT17KGUpID0+IG9uU3RhdHVzQ2hhbmdlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgID5cbiAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPkFsbCBTdGF0dXNlczwvb3B0aW9uPlxuICAgICAgICA8b3B0aW9uIHZhbHVlPVwiT1BFTlwiPk9wZW48L29wdGlvbj5cbiAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIklOX1BST0dSRVNTXCI+SW4gUHJvZ3Jlc3M8L29wdGlvbj5cbiAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNMT1NFRFwiPkNsb3NlZDwvb3B0aW9uPlxuICAgICAgPC9zZWxlY3Q+XG5cbiAgICAgIDxzZWxlY3RcbiAgICAgICAgY2xhc3NOYW1lPVwiZmlsdGVyLXNlbGVjdFwiXG4gICAgICAgIHZhbHVlPXtzb3J0Qnl9XG4gICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gb25Tb3J0QnlDaGFuZ2UoZS50YXJnZXQudmFsdWUpfVxuICAgICAgPlxuICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY3JlYXRlZEF0XCI+RGF0ZSBDcmVhdGVkPC9vcHRpb24+XG4gICAgICAgIDxvcHRpb24gdmFsdWU9XCJ0aXRsZVwiPlRpdGxlPC9vcHRpb24+XG4gICAgICAgIDxvcHRpb24gdmFsdWU9XCJwcmlvcml0eVwiPlByaW9yaXR5PC9vcHRpb24+XG4gICAgICAgIDxvcHRpb24gdmFsdWU9XCJzdGF0dXNcIj5TdGF0dXM8L29wdGlvbj5cbiAgICAgIDwvc2VsZWN0PlxuXG4gICAgICA8c2VsZWN0XG4gICAgICAgIGNsYXNzTmFtZT1cImZpbHRlci1zZWxlY3RcIlxuICAgICAgICB2YWx1ZT17ZGlyZWN0aW9ufVxuICAgICAgICBvbkNoYW5nZT17KGUpID0+IG9uRGlyZWN0aW9uQ2hhbmdlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgID5cbiAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImRlc2NcIj5OZXdlc3QgRmlyc3Q8L29wdGlvbj5cbiAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImFzY1wiPk9sZGVzdCBGaXJzdDwvb3B0aW9uPlxuICAgICAgPC9zZWxlY3Q+XG5cbiAgICAgIDxzZWxlY3RcbiAgICAgICAgY2xhc3NOYW1lPVwiZmlsdGVyLXNlbGVjdFwiXG4gICAgICAgIHZhbHVlPXtwYWdlU2l6ZX1cbiAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvblBhZ2VTaXplQ2hhbmdlKE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgPlxuICAgICAgICA8b3B0aW9uIHZhbHVlPXs1fT41IHBlciBwYWdlPC9vcHRpb24+XG4gICAgICAgIDxvcHRpb24gdmFsdWU9ezEwfT4xMCBwZXIgcGFnZTwvb3B0aW9uPlxuICAgICAgICA8b3B0aW9uIHZhbHVlPXsyMH0+MjAgcGVyIHBhZ2U8L29wdGlvbj5cbiAgICAgIDwvc2VsZWN0PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl19