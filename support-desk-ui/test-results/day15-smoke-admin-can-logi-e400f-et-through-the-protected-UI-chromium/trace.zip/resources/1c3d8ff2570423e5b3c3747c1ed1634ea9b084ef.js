import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import { Navigate, Route, Routes } from "/node_modules/.vite/deps/react-router.js?v=3927c5ff";
import ProtectedRoute from "/src/components/ProtectedRoute.jsx";
import AppShell from "/src/components/AppShell.jsx";
import DashboardPage from "/src/pages/DashboardPage.jsx";
import TicketsPage from "/src/pages/TicketsPage.jsx";
import TicketFormPage from "/src/pages/TicketFormPage.jsx";
import ReportsPage from "/src/pages/ReportsPage.jsx";
import LoginPage from "/src/pages/LoginPage.jsx";
import "/src/App.css";
var _jsxFileName = "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/App.jsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3927c5ff";
export default function App() {
	return /* @__PURE__ */ _jsxDEV(Routes, { children: [
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/",
			element: /* @__PURE__ */ _jsxDEV(Navigate, {
				to: "/app/dashboard",
				replace: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 32
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/login",
			element: /* @__PURE__ */ _jsxDEV(LoginPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 37
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/app",
			element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(AppShell, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 13
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 11
			}, this),
			children: [
				/* @__PURE__ */ _jsxDEV(Route, {
					index: true,
					element: /* @__PURE__ */ _jsxDEV(Navigate, {
						to: "dashboard",
						replace: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 31
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "dashboard",
					element: /* @__PURE__ */ _jsxDEV(DashboardPage, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 42
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "tickets",
					element: /* @__PURE__ */ _jsxDEV(TicketsPage, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 40
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "tickets/new",
					element: /* @__PURE__ */ _jsxDEV(TicketFormPage, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 28,
						columnNumber: 44
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "tickets/:ticketId/edit",
					element: /* @__PURE__ */ _jsxDEV(TicketFormPage, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 29,
						columnNumber: 55
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "reports",
					element: /* @__PURE__ */ _jsxDEV(ReportsPage, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 30,
						columnNumber: 40
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "*",
			element: /* @__PURE__ */ _jsxDEV(Navigate, {
				to: "/app/dashboard",
				replace: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 32
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 5
	}, this);
}
_c = App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/App.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLE9BQU8sY0FBYztBQUN4QyxPQUFPLG9CQUFvQjtBQUMzQixPQUFPLGNBQWM7QUFDckIsT0FBTyxtQkFBbUI7QUFDMUIsT0FBTyxpQkFBaUI7QUFDeEIsT0FBTyxvQkFBb0I7QUFDM0IsT0FBTyxpQkFBaUI7QUFDeEIsT0FBTyxlQUFlO0FBQ3RCLE9BQU87OztBQUVQLGVBQWUsU0FBUyxNQUFNO0NBQzVCLE9BQ0Usd0JBQUMsUUFBRDtFQUNFLHdCQUFDLE9BQUQ7R0FBTyxNQUFLO0dBQUksU0FBUyx3QkFBQyxVQUFEO0lBQVUsSUFBRztJQUFpQjtHQUFTOzs7OztFQUFJOzs7OztFQUNwRSx3QkFBQyxPQUFEO0dBQU8sTUFBSztHQUFTLFNBQVMsd0JBQUMsV0FBRCxDQUFZOzs7OztFQUFJOzs7OztFQUU5Qyx3QkFBQyxPQUFEO0dBQ0UsTUFBSztHQUNMLFNBQ0Usd0JBQUMsZ0JBQUQsWUFDRSx3QkFBQyxVQUFELENBQVc7Ozs7WUFDRzs7Ozs7YUFMcEI7SUFRRSx3QkFBQyxPQUFEO0tBQU87S0FBTSxTQUFTLHdCQUFDLFVBQUQ7TUFBVSxJQUFHO01BQVk7S0FBUzs7Ozs7SUFBSTs7Ozs7SUFDNUQsd0JBQUMsT0FBRDtLQUFPLE1BQUs7S0FBWSxTQUFTLHdCQUFDLGVBQUQsQ0FBZ0I7Ozs7O0lBQUk7Ozs7O0lBQ3JELHdCQUFDLE9BQUQ7S0FBTyxNQUFLO0tBQVUsU0FBUyx3QkFBQyxhQUFELENBQWM7Ozs7O0lBQUk7Ozs7O0lBQ2pELHdCQUFDLE9BQUQ7S0FBTyxNQUFLO0tBQWMsU0FBUyx3QkFBQyxnQkFBRCxDQUFpQjs7Ozs7SUFBSTs7Ozs7SUFDeEQsd0JBQUMsT0FBRDtLQUFPLE1BQUs7S0FBeUIsU0FBUyx3QkFBQyxnQkFBRCxDQUFpQjs7Ozs7SUFBSTs7Ozs7SUFDbkUsd0JBQUMsT0FBRDtLQUFPLE1BQUs7S0FBVSxTQUFTLHdCQUFDLGFBQUQsQ0FBYzs7Ozs7SUFBSTs7Ozs7R0FDNUM7Ozs7OztFQUVQLHdCQUFDLE9BQUQ7R0FBTyxNQUFLO0dBQUksU0FBUyx3QkFBQyxVQUFEO0lBQVUsSUFBRztJQUFpQjtHQUFTOzs7OztFQUFJOzs7OztDQUM5RDs7Ozs7QUFFWiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHAuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5hdmlnYXRlLCBSb3V0ZSwgUm91dGVzIH0gZnJvbSAncmVhY3Qtcm91dGVyJztcbmltcG9ydCBQcm90ZWN0ZWRSb3V0ZSBmcm9tICcuL2NvbXBvbmVudHMvUHJvdGVjdGVkUm91dGUuanN4JztcbmltcG9ydCBBcHBTaGVsbCBmcm9tICcuL2NvbXBvbmVudHMvQXBwU2hlbGwuanN4JztcbmltcG9ydCBEYXNoYm9hcmRQYWdlIGZyb20gJy4vcGFnZXMvRGFzaGJvYXJkUGFnZS5qc3gnO1xuaW1wb3J0IFRpY2tldHNQYWdlIGZyb20gJy4vcGFnZXMvVGlja2V0c1BhZ2UuanN4JztcbmltcG9ydCBUaWNrZXRGb3JtUGFnZSBmcm9tICcuL3BhZ2VzL1RpY2tldEZvcm1QYWdlLmpzeCc7XG5pbXBvcnQgUmVwb3J0c1BhZ2UgZnJvbSAnLi9wYWdlcy9SZXBvcnRzUGFnZS5qc3gnO1xuaW1wb3J0IExvZ2luUGFnZSBmcm9tICcuL3BhZ2VzL0xvZ2luUGFnZS5qc3gnO1xuaW1wb3J0ICcuL0FwcC5jc3MnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoKSB7XG4gIHJldHVybiAoXG4gICAgPFJvdXRlcz5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiL1wiIGVsZW1lbnQ9ezxOYXZpZ2F0ZSB0bz1cIi9hcHAvZGFzaGJvYXJkXCIgcmVwbGFjZSAvPn0gLz5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiL2xvZ2luXCIgZWxlbWVudD17PExvZ2luUGFnZSAvPn0gLz5cblxuICAgICAgPFJvdXRlXG4gICAgICAgIHBhdGg9XCIvYXBwXCJcbiAgICAgICAgZWxlbWVudD17XG4gICAgICAgICAgPFByb3RlY3RlZFJvdXRlPlxuICAgICAgICAgICAgPEFwcFNoZWxsIC8+XG4gICAgICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cbiAgICAgICAgfVxuICAgICAgPlxuICAgICAgICA8Um91dGUgaW5kZXggZWxlbWVudD17PE5hdmlnYXRlIHRvPVwiZGFzaGJvYXJkXCIgcmVwbGFjZSAvPn0gLz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCJkYXNoYm9hcmRcIiBlbGVtZW50PXs8RGFzaGJvYXJkUGFnZSAvPn0gLz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCJ0aWNrZXRzXCIgZWxlbWVudD17PFRpY2tldHNQYWdlIC8+fSAvPlxuICAgICAgICA8Um91dGUgcGF0aD1cInRpY2tldHMvbmV3XCIgZWxlbWVudD17PFRpY2tldEZvcm1QYWdlIC8+fSAvPlxuICAgICAgICA8Um91dGUgcGF0aD1cInRpY2tldHMvOnRpY2tldElkL2VkaXRcIiBlbGVtZW50PXs8VGlja2V0Rm9ybVBhZ2UgLz59IC8+XG4gICAgICAgIDxSb3V0ZSBwYXRoPVwicmVwb3J0c1wiIGVsZW1lbnQ9ezxSZXBvcnRzUGFnZSAvPn0gLz5cbiAgICAgIDwvUm91dGU+XG5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiKlwiIGVsZW1lbnQ9ezxOYXZpZ2F0ZSB0bz1cIi9hcHAvZGFzaGJvYXJkXCIgcmVwbGFjZSAvPn0gLz5cbiAgICA8L1JvdXRlcz5cbiAgKTtcbn1cbiJdfQ==