import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PriorityBadge.jsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/PriorityBadge.jsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3927c5ff";
const priorityStyles = {
	HIGH: {
		background: "#fee2e2",
		color: "#dc2626",
		border: "1px solid #fca5a5"
	},
	MEDIUM: {
		background: "#fef3c7",
		color: "#d97706",
		border: "1px solid #fcd34d"
	},
	LOW: {
		background: "#dcfce7",
		color: "#16a34a",
		border: "1px solid #86efac"
	}
};
export default function PriorityBadge({ priority }) {
	const style = priorityStyles[priority] || priorityStyles.LOW;
	return /* @__PURE__ */ _jsxDEV("span", {
		className: "badge",
		style,
		children: priority
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 5
	}, this);
}
_c = PriorityBadge;
var _c;
$RefreshReg$(_c, "PriorityBadge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/PriorityBadge.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/PriorityBadge.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/PriorityBadge.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/PriorityBadge.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFBQSxNQUFNLGlCQUFpQjtDQUNyQixNQUFNO0VBQUUsWUFBWTtFQUFXLE9BQU87RUFBVyxRQUFRO0NBQW9CO0NBQzdFLFFBQVE7RUFBRSxZQUFZO0VBQVcsT0FBTztFQUFXLFFBQVE7Q0FBb0I7Q0FDL0UsS0FBSztFQUFFLFlBQVk7RUFBVyxPQUFPO0VBQVcsUUFBUTtDQUFvQjtBQUM5RTtBQUVBLGVBQWUsU0FBUyxjQUFjLEVBQUUsWUFBWTtDQUNsRCxNQUFNLFFBQVEsZUFBZSxhQUFhLGVBQWU7Q0FFekQsT0FDRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtFQUFlO1lBQzVCO0NBQ0c7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHJpb3JpdHlCYWRnZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiY29uc3QgcHJpb3JpdHlTdHlsZXMgPSB7XG4gIEhJR0g6IHsgYmFja2dyb3VuZDogJyNmZWUyZTInLCBjb2xvcjogJyNkYzI2MjYnLCBib3JkZXI6ICcxcHggc29saWQgI2ZjYTVhNScgfSxcbiAgTUVESVVNOiB7IGJhY2tncm91bmQ6ICcjZmVmM2M3JywgY29sb3I6ICcjZDk3NzA2JywgYm9yZGVyOiAnMXB4IHNvbGlkICNmY2QzNGQnIH0sXG4gIExPVzogeyBiYWNrZ3JvdW5kOiAnI2RjZmNlNycsIGNvbG9yOiAnIzE2YTM0YScsIGJvcmRlcjogJzFweCBzb2xpZCAjODZlZmFjJyB9XG59O1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQcmlvcml0eUJhZGdlKHsgcHJpb3JpdHkgfSkge1xuICBjb25zdCBzdHlsZSA9IHByaW9yaXR5U3R5bGVzW3ByaW9yaXR5XSB8fCBwcmlvcml0eVN0eWxlcy5MT1c7XG5cbiAgcmV0dXJuIChcbiAgICA8c3BhbiBjbGFzc05hbWU9XCJiYWRnZVwiIHN0eWxlPXtzdHlsZX0+XG4gICAgICB7cHJpb3JpdHl9XG4gICAgPC9zcGFuPlxuICApO1xufVxuIl19