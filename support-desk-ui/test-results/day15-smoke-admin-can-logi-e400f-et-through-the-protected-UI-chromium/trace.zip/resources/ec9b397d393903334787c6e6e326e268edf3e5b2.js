import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ApiInfoCard.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=3927c5ff";
import { fetchApiInfo } from "/src/services/api.js";
var _jsxFileName = "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/ApiInfoCard.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3927c5ff";
var _s = $RefreshSig$();
export default function ApiInfoCard() {
	_s();
	const [info, setInfo] = useState(null);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);
	useEffect(() => {
		let cancelled = false;
		async function load() {
			try {
				setLoading(true);
				setError(null);
				const data = await fetchApiInfo();
				if (!cancelled) {
					setInfo(data);
				}
			} catch (err) {
				if (!cancelled) {
					setError(err.message);
				}
			} finally {
				if (!cancelled) {
					setLoading(false);
				}
			}
		}
		load();
		return () => {
			cancelled = true;
		};
	}, []);
	if (loading) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "api-info-card",
			children: /* @__PURE__ */ _jsxDEV("p", {
				className: "api-info-loading",
				children: "Loading API info..."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 7
		}, this);
	}
	if (error) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "api-info-card api-info-error",
			children: [/* @__PURE__ */ _jsxDEV("p", {
				className: "api-info-error-text",
				children: ["Could not connect to backend: ", error]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "api-info-error-hint",
				children: "Make sure the Spring Boot backend is running on port 8080."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 50,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 48,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "api-info-card api-info-success",
		children: [/* @__PURE__ */ _jsxDEV("h3", {
			className: "api-info-title",
			children: "Backend API Info"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 57,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("dl", {
			className: "api-info-fields",
			children: Object.entries(info).map(([key, value]) => /* @__PURE__ */ _jsxDEV("div", {
				className: "api-info-row",
				children: [/* @__PURE__ */ _jsxDEV("dt", { children: key }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("dd", { children: String(value) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 13
				}, this)]
			}, key, true, {
				fileName: _jsxFileName,
				lineNumber: 60,
				columnNumber: 11
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 58,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 56,
		columnNumber: 5
	}, this);
}
_s(ApiInfoCard, "UlOJcwUt4Z0rLXiRIzEUl/J+0Mg=");
_c = ApiInfoCard;
var _c;
$RefreshReg$(_c, "ApiInfoCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ApiInfoCard.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/ApiInfoCard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/ApiInfoCard.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/ApiInfoCard.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGlCQUFpQjtBQUNwQyxTQUFTLG9CQUFvQjs7OztBQUU3QixlQUFlLFNBQVMsY0FBYzs7Q0FDcEMsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLElBQUk7Q0FDckMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7Q0FDM0MsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLElBQUk7Q0FFdkMsZ0JBQWdCO0VBQ2QsSUFBSSxZQUFZO0VBRWhCLGVBQWUsT0FBTztHQUNwQixJQUFJO0lBQ0YsV0FBVyxJQUFJO0lBQ2YsU0FBUyxJQUFJO0lBQ2IsTUFBTSxPQUFPLE1BQU0sYUFBYTtJQUNoQyxJQUFJLENBQUMsV0FBVztLQUNkLFFBQVEsSUFBSTtJQUNkO0dBQ0YsU0FBUyxLQUFLO0lBQ1osSUFBSSxDQUFDLFdBQVc7S0FDZCxTQUFTLElBQUksT0FBTztJQUN0QjtHQUNGLFVBQVU7SUFDUixJQUFJLENBQUMsV0FBVztLQUNkLFdBQVcsS0FBSztJQUNsQjtHQUNGO0VBQ0Y7RUFFQSxLQUFLO0VBRUwsYUFBYTtHQUNYLFlBQVk7RUFDZDtDQUNGLEdBQUcsQ0FBQyxDQUFDO0NBRUwsSUFBSSxTQUFTO0VBQ1gsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNiLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQW1CO0dBQXNCOzs7OztFQUNuRDs7Ozs7Q0FFVDtDQUVBLElBQUksT0FBTztFQUNULE9BQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQWIsQ0FBbUMsa0NBQStCLEtBQVM7Ozs7O2FBQzNFLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQXNCO0dBQTZEOzs7O1dBQzdGOzs7Ozs7Q0FFVDtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLE1BQUQ7R0FBSSxXQUFVO2FBQWlCO0VBQW9COzs7O1lBQ25ELHdCQUFDLE1BQUQ7R0FBSSxXQUFVO2FBQ1gsT0FBTyxRQUFRLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLFdBQy9CLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFELFlBQUssSUFBUTs7OztjQUNiLHdCQUFDLE1BQUQsWUFBSyxPQUFPLEtBQUssRUFBTTs7OztZQUNwQjtNQUg4Qjs7OztVQUc5QixDQUNOO0VBQ0M7Ozs7VUFDRDs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBpSW5mb0NhcmQuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBmZXRjaEFwaUluZm8gfSBmcm9tICcuLi9zZXJ2aWNlcy9hcGkuanMnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcGlJbmZvQ2FyZCgpIHtcbiAgY29uc3QgW2luZm8sIHNldEluZm9dID0gdXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbGV0IGNhbmNlbGxlZCA9IGZhbHNlO1xuXG4gICAgYXN5bmMgZnVuY3Rpb24gbG9hZCgpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgIHNldEVycm9yKG51bGwpO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgZmV0Y2hBcGlJbmZvKCk7XG4gICAgICAgIGlmICghY2FuY2VsbGVkKSB7XG4gICAgICAgICAgc2V0SW5mbyhkYXRhKTtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGlmICghY2FuY2VsbGVkKSB7XG4gICAgICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UpO1xuICAgICAgICB9XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBpZiAoIWNhbmNlbGxlZCkge1xuICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgbG9hZCgpO1xuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGNhbmNlbGxlZCA9IHRydWU7XG4gICAgfTtcbiAgfSwgW10pO1xuXG4gIGlmIChsb2FkaW5nKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXBpLWluZm8tY2FyZFwiPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJhcGktaW5mby1sb2FkaW5nXCI+TG9hZGluZyBBUEkgaW5mby4uLjwvcD5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICBpZiAoZXJyb3IpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhcGktaW5mby1jYXJkIGFwaS1pbmZvLWVycm9yXCI+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImFwaS1pbmZvLWVycm9yLXRleHRcIj5Db3VsZCBub3QgY29ubmVjdCB0byBiYWNrZW5kOiB7ZXJyb3J9PC9wPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJhcGktaW5mby1lcnJvci1oaW50XCI+TWFrZSBzdXJlIHRoZSBTcHJpbmcgQm9vdCBiYWNrZW5kIGlzIHJ1bm5pbmcgb24gcG9ydCA4MDgwLjwvcD5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYXBpLWluZm8tY2FyZCBhcGktaW5mby1zdWNjZXNzXCI+XG4gICAgICA8aDMgY2xhc3NOYW1lPVwiYXBpLWluZm8tdGl0bGVcIj5CYWNrZW5kIEFQSSBJbmZvPC9oMz5cbiAgICAgIDxkbCBjbGFzc05hbWU9XCJhcGktaW5mby1maWVsZHNcIj5cbiAgICAgICAge09iamVjdC5lbnRyaWVzKGluZm8pLm1hcCgoW2tleSwgdmFsdWVdKSA9PiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhcGktaW5mby1yb3dcIiBrZXk9e2tleX0+XG4gICAgICAgICAgICA8ZHQ+e2tleX08L2R0PlxuICAgICAgICAgICAgPGRkPntTdHJpbmcodmFsdWUpfTwvZGQ+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICkpfVxuICAgICAgPC9kbD5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdfQ==