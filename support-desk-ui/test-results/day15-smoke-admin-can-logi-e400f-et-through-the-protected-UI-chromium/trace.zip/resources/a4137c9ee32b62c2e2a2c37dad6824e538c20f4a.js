import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/TicketFormPage.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=3927c5ff";
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router.js?v=3927c5ff";
import TicketFormWizard from "/src/components/TicketFormWizard.jsx";
import { useAuth } from "/src/context/AuthContext.jsx";
import { createTicket, fetchTicketById, updateTicket } from "/src/services/api.js";
var _jsxFileName = "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/pages/TicketFormPage.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3927c5ff";
var _s = $RefreshSig$();
export default function TicketFormPage() {
	_s();
	const navigate = useNavigate();
	const { ticketId } = useParams();
	const { token, user } = useAuth();
	const isEditMode = Boolean(ticketId);
	const [initialValues, setInitialValues] = useState(null);
	const [loading, setLoading] = useState(isEditMode);
	const [saving, setSaving] = useState(false);
	const [savedTicket, setSavedTicket] = useState(null);
	const [error, setError] = useState("");
	// In edit mode, load the existing ticket so the form starts pre-filled
	useEffect(() => {
		if (!isEditMode) {
			setInitialValues(null);
			setLoading(false);
			setSavedTicket(null);
			setError("");
			return;
		}
		let ignore = false;
		setLoading(true);
		setSavedTicket(null);
		setError("");
		fetchTicketById(ticketId, token).then((ticket) => {
			if (!ignore) {
				setInitialValues({
					title: ticket.title ?? "",
					description: ticket.description ?? "",
					category: ticket.category ?? "",
					priority: ticket.priority ?? "",
					status: ticket.status ?? ""
				});
			}
		}).catch((loadError) => {
			if (!ignore) {
				setError(loadError.message);
			}
		}).finally(() => {
			if (!ignore) {
				setLoading(false);
			}
		});
		return () => {
			ignore = true;
		};
	}, [
		ticketId,
		isEditMode,
		token
	]);
	async function handleSubmit(payload) {
		setSaving(true);
		setSavedTicket(null);
		setError("");
		try {
			const ticket = isEditMode ? await updateTicket(ticketId, token, payload) : await createTicket(token, {
				...payload,
				// Backend requires createdBy on create; use the logged-in user
				createdBy: user?.email ?? "unknown@example.com"
			});
			setSavedTicket(ticket);
		} catch (saveError) {
			setError(saveError.message);
		} finally {
			setSaving(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("h2", {
			className: "page-title",
			children: isEditMode ? "Edit Ticket" : "New Ticket"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 86,
			columnNumber: 7
		}, this),
		error && /* @__PURE__ */ _jsxDEV("div", {
			className: "ticket-form-error",
			role: "alert",
			children: /* @__PURE__ */ _jsxDEV("p", { children: error }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 90,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 89,
			columnNumber: 9
		}, this),
		savedTicket && /* @__PURE__ */ _jsxDEV("div", {
			className: "card ticket-form-success",
			role: "status",
			children: [
				/* @__PURE__ */ _jsxDEV("p", { children: [
					"Ticket ",
					isEditMode ? "updated" : "created",
					" successfully:"
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("dl", {
					className: "detail-fields",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "detail-row",
							children: [/* @__PURE__ */ _jsxDEV("dt", { children: "ID" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 99,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("dd", { children: savedTicket.id }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 100,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 98,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "detail-row",
							children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Title" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 103,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("dd", { children: savedTicket.title }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 104,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "detail-row",
							children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Description" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 107,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("dd", { children: savedTicket.description }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 108,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 106,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "detail-row",
							children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Category" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 111,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("dd", { children: savedTicket.category }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 112,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 110,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "detail-row",
							children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Priority" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 115,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("dd", { children: savedTicket.priority }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 116,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "detail-row",
							children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Status" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 119,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("dd", { children: savedTicket.status }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 118,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 97,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "form-actions",
					children: /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "button-link secondary",
						onClick: () => navigate("/app/tickets"),
						children: "Back to Tickets"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 123,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 95,
			columnNumber: 9
		}, this),
		loading ? /* @__PURE__ */ _jsxDEV("p", {
			className: "ticket-form-loading",
			children: "Loading ticket..."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 136,
			columnNumber: 9
		}, this) : (!isEditMode || initialValues) && /* @__PURE__ */ _jsxDEV(TicketFormWizard, {
			initialValues: initialValues ?? undefined,
			onSubmit: handleSubmit,
			saving,
			submitLabel: isEditMode ? "Save Changes" : "Create Ticket"
		}, ticketId ?? "new", false, {
			fileName: _jsxFileName,
			lineNumber: 139,
			columnNumber: 11
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 85,
		columnNumber: 5
	}, this);
}
_s(TicketFormPage, "qaWmFy1OjdsgQ1F0ehJiXV2zDNk=", false, function() {
	return [
		useNavigate,
		useParams,
		useAuth
	];
});
_c = TicketFormPage;
var _c;
$RefreshReg$(_c, "TicketFormPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/TicketFormPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/pages/TicketFormPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/pages/TicketFormPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/pages/TicketFormPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLGFBQWEsaUJBQWlCO0FBQ3ZDLE9BQU8sc0JBQXNCO0FBQzdCLFNBQVMsZUFBZTtBQUN4QixTQUFTLGNBQWMsaUJBQWlCLG9CQUFvQjs7OztBQUU1RCxlQUFlLFNBQVMsaUJBQWlCOztDQUN2QyxNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLEVBQUUsYUFBYSxVQUFVO0NBQy9CLE1BQU0sRUFBRSxPQUFPLFNBQVMsUUFBUTtDQUNoQyxNQUFNLGFBQWEsUUFBUSxRQUFRO0NBRW5DLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLElBQUk7Q0FDdkQsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLFVBQVU7Q0FDakQsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLEtBQUs7Q0FDMUMsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsSUFBSTtDQUNuRCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTs7Q0FHckMsZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDLFlBQVk7R0FDZixpQkFBaUIsSUFBSTtHQUNyQixXQUFXLEtBQUs7R0FDaEIsZUFBZSxJQUFJO0dBQ25CLFNBQVMsRUFBRTtHQUNYO0VBQ0Y7RUFFQSxJQUFJLFNBQVM7RUFDYixXQUFXLElBQUk7RUFDZixlQUFlLElBQUk7RUFDbkIsU0FBUyxFQUFFO0VBRVgsZ0JBQWdCLFVBQVUsS0FBSyxDQUFDLENBQzdCLE1BQU0sV0FBVztHQUNoQixJQUFJLENBQUMsUUFBUTtJQUNYLGlCQUFpQjtLQUNmLE9BQU8sT0FBTyxTQUFTO0tBQ3ZCLGFBQWEsT0FBTyxlQUFlO0tBQ25DLFVBQVUsT0FBTyxZQUFZO0tBQzdCLFVBQVUsT0FBTyxZQUFZO0tBQzdCLFFBQVEsT0FBTyxVQUFVO0lBQzNCLENBQUM7R0FDSDtFQUNGLENBQUMsQ0FBQyxDQUNELE9BQU8sY0FBYztHQUNwQixJQUFJLENBQUMsUUFBUTtJQUNYLFNBQVMsVUFBVSxPQUFPO0dBQzVCO0VBQ0YsQ0FBQyxDQUFDLENBQ0QsY0FBYztHQUNiLElBQUksQ0FBQyxRQUFRO0lBQ1gsV0FBVyxLQUFLO0dBQ2xCO0VBQ0YsQ0FBQztFQUVILGFBQWE7R0FDWCxTQUFTO0VBQ1g7Q0FDRixHQUFHO0VBQUM7RUFBVTtFQUFZO0NBQUssQ0FBQztDQUVoQyxlQUFlLGFBQWEsU0FBUztFQUNuQyxVQUFVLElBQUk7RUFDZCxlQUFlLElBQUk7RUFDbkIsU0FBUyxFQUFFO0VBRVgsSUFBSTtHQUNGLE1BQU0sU0FBUyxhQUNYLE1BQU0sYUFBYSxVQUFVLE9BQU8sT0FBTyxJQUMzQyxNQUFNLGFBQWEsT0FBTztJQUN4QixHQUFHOztJQUVILFdBQVcsTUFBTSxTQUFTO0dBQzVCLENBQUM7R0FFTCxlQUFlLE1BQU07RUFDdkIsU0FBUyxXQUFXO0dBQ2xCLFNBQVMsVUFBVSxPQUFPO0VBQzVCLFVBQVU7R0FDUixVQUFVLEtBQUs7RUFDakI7Q0FDRjtDQUVBLE9BQ0U7RUFDRSx3QkFBQyxNQUFEO0dBQUksV0FBVTthQUFjLGFBQWEsZ0JBQWdCO0VBQWlCOzs7OztFQUV6RSxTQUNDLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO0dBQW9CLE1BQUs7YUFDdEMsd0JBQUMsS0FBRCxZQUFJLE1BQVM7Ozs7O0VBQ1Y7Ozs7O0VBR04sZUFDQyx3QkFBQyxPQUFEO0dBQUssV0FBVTtHQUEyQixNQUFLO2FBQS9DO0lBQ0Usd0JBQUMsS0FBRDtLQUFHO0tBQVEsYUFBYSxZQUFZO0tBQVU7SUFBaUI7Ozs7O0lBQy9ELHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWQ7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQsWUFBSSxLQUFNOzs7O2lCQUNWLHdCQUFDLE1BQUQsWUFBSyxZQUFZLEdBQU87Ozs7ZUFDckI7Ozs7OztNQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRCxZQUFJLFFBQVM7Ozs7aUJBQ2Isd0JBQUMsTUFBRCxZQUFLLFlBQVksTUFBVTs7OztlQUN4Qjs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFELFlBQUksY0FBZTs7OztpQkFDbkIsd0JBQUMsTUFBRCxZQUFLLFlBQVksWUFBZ0I7Ozs7ZUFDOUI7Ozs7OztNQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRCxZQUFJLFdBQVk7Ozs7aUJBQ2hCLHdCQUFDLE1BQUQsWUFBSyxZQUFZLFNBQWE7Ozs7ZUFDM0I7Ozs7OztNQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRCxZQUFJLFdBQVk7Ozs7aUJBQ2hCLHdCQUFDLE1BQUQsWUFBSyxZQUFZLFNBQWE7Ozs7ZUFDM0I7Ozs7OztNQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRCxZQUFJLFNBQVU7Ozs7aUJBQ2Qsd0JBQUMsTUFBRCxZQUFLLFlBQVksT0FBVzs7OztlQUN6Qjs7Ozs7O0tBQ0g7Ozs7OztJQUNKLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxXQUFVO01BQ1YsZUFBZSxTQUFTLGNBQWM7Z0JBQ3ZDO0tBRU87Ozs7O0lBQ0w7Ozs7O0dBQ0Y7Ozs7OztFQUdOLFVBQ0Msd0JBQUMsS0FBRDtHQUFHLFdBQVU7YUFBc0I7RUFBb0I7Ozs7Y0FFdEQsQ0FBQyxjQUFjLGtCQUNkLHdCQUFDLGtCQUFEO0dBRUUsZUFBZSxpQkFBaUI7R0FDaEMsVUFBVTtHQUNGO0dBQ1IsYUFBYSxhQUFhLGlCQUFpQjtFQUM1QyxHQUxNLFlBQVk7Ozs7U0FLbEI7Q0FHTDs7Ozs7QUFFTiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJUaWNrZXRGb3JtUGFnZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU5hdmlnYXRlLCB1c2VQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXInO1xuaW1wb3J0IFRpY2tldEZvcm1XaXphcmQgZnJvbSAnLi4vY29tcG9uZW50cy9UaWNrZXRGb3JtV2l6YXJkLmpzeCc7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vY29udGV4dC9BdXRoQ29udGV4dC5qc3gnO1xuaW1wb3J0IHsgY3JlYXRlVGlja2V0LCBmZXRjaFRpY2tldEJ5SWQsIHVwZGF0ZVRpY2tldCB9IGZyb20gJy4uL3NlcnZpY2VzL2FwaS5qcyc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFRpY2tldEZvcm1QYWdlKCkge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IHsgdGlja2V0SWQgfSA9IHVzZVBhcmFtcygpO1xuICBjb25zdCB7IHRva2VuLCB1c2VyIH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IGlzRWRpdE1vZGUgPSBCb29sZWFuKHRpY2tldElkKTtcblxuICBjb25zdCBbaW5pdGlhbFZhbHVlcywgc2V0SW5pdGlhbFZhbHVlc10gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoaXNFZGl0TW9kZSk7XG4gIGNvbnN0IFtzYXZpbmcsIHNldFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtzYXZlZFRpY2tldCwgc2V0U2F2ZWRUaWNrZXRdID0gdXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpO1xuXG4gIC8vIEluIGVkaXQgbW9kZSwgbG9hZCB0aGUgZXhpc3RpbmcgdGlja2V0IHNvIHRoZSBmb3JtIHN0YXJ0cyBwcmUtZmlsbGVkXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFpc0VkaXRNb2RlKSB7XG4gICAgICBzZXRJbml0aWFsVmFsdWVzKG51bGwpO1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICBzZXRTYXZlZFRpY2tldChudWxsKTtcbiAgICAgIHNldEVycm9yKCcnKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBsZXQgaWdub3JlID0gZmFsc2U7XG4gICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICBzZXRTYXZlZFRpY2tldChudWxsKTtcbiAgICBzZXRFcnJvcignJyk7XG5cbiAgICBmZXRjaFRpY2tldEJ5SWQodGlja2V0SWQsIHRva2VuKVxuICAgICAgLnRoZW4oKHRpY2tldCkgPT4ge1xuICAgICAgICBpZiAoIWlnbm9yZSkge1xuICAgICAgICAgIHNldEluaXRpYWxWYWx1ZXMoe1xuICAgICAgICAgICAgdGl0bGU6IHRpY2tldC50aXRsZSA/PyAnJyxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiB0aWNrZXQuZGVzY3JpcHRpb24gPz8gJycsXG4gICAgICAgICAgICBjYXRlZ29yeTogdGlja2V0LmNhdGVnb3J5ID8/ICcnLFxuICAgICAgICAgICAgcHJpb3JpdHk6IHRpY2tldC5wcmlvcml0eSA/PyAnJyxcbiAgICAgICAgICAgIHN0YXR1czogdGlja2V0LnN0YXR1cyA/PyAnJ1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9KVxuICAgICAgLmNhdGNoKChsb2FkRXJyb3IpID0+IHtcbiAgICAgICAgaWYgKCFpZ25vcmUpIHtcbiAgICAgICAgICBzZXRFcnJvcihsb2FkRXJyb3IubWVzc2FnZSk7XG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgICAuZmluYWxseSgoKSA9PiB7XG4gICAgICAgIGlmICghaWdub3JlKSB7XG4gICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGlnbm9yZSA9IHRydWU7XG4gICAgfTtcbiAgfSwgW3RpY2tldElkLCBpc0VkaXRNb2RlLCB0b2tlbl0pO1xuXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChwYXlsb2FkKSB7XG4gICAgc2V0U2F2aW5nKHRydWUpO1xuICAgIHNldFNhdmVkVGlja2V0KG51bGwpO1xuICAgIHNldEVycm9yKCcnKTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCB0aWNrZXQgPSBpc0VkaXRNb2RlXG4gICAgICAgID8gYXdhaXQgdXBkYXRlVGlja2V0KHRpY2tldElkLCB0b2tlbiwgcGF5bG9hZClcbiAgICAgICAgOiBhd2FpdCBjcmVhdGVUaWNrZXQodG9rZW4sIHtcbiAgICAgICAgICAgIC4uLnBheWxvYWQsXG4gICAgICAgICAgICAvLyBCYWNrZW5kIHJlcXVpcmVzIGNyZWF0ZWRCeSBvbiBjcmVhdGU7IHVzZSB0aGUgbG9nZ2VkLWluIHVzZXJcbiAgICAgICAgICAgIGNyZWF0ZWRCeTogdXNlcj8uZW1haWwgPz8gJ3Vua25vd25AZXhhbXBsZS5jb20nXG4gICAgICAgICAgfSk7XG5cbiAgICAgIHNldFNhdmVkVGlja2V0KHRpY2tldCk7XG4gICAgfSBjYXRjaCAoc2F2ZUVycm9yKSB7XG4gICAgICBzZXRFcnJvcihzYXZlRXJyb3IubWVzc2FnZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFNhdmluZyhmYWxzZSk7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGgyIGNsYXNzTmFtZT1cInBhZ2UtdGl0bGVcIj57aXNFZGl0TW9kZSA/ICdFZGl0IFRpY2tldCcgOiAnTmV3IFRpY2tldCd9PC9oMj5cblxuICAgICAge2Vycm9yICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtZm9ybS1lcnJvclwiIHJvbGU9XCJhbGVydFwiPlxuICAgICAgICAgIDxwPntlcnJvcn08L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAge3NhdmVkVGlja2V0ICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHRpY2tldC1mb3JtLXN1Y2Nlc3NcIiByb2xlPVwic3RhdHVzXCI+XG4gICAgICAgICAgPHA+VGlja2V0IHtpc0VkaXRNb2RlID8gJ3VwZGF0ZWQnIDogJ2NyZWF0ZWQnfSBzdWNjZXNzZnVsbHk6PC9wPlxuICAgICAgICAgIDxkbCBjbGFzc05hbWU9XCJkZXRhaWwtZmllbGRzXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRldGFpbC1yb3dcIj5cbiAgICAgICAgICAgICAgPGR0PklEPC9kdD5cbiAgICAgICAgICAgICAgPGRkPntzYXZlZFRpY2tldC5pZH08L2RkPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRldGFpbC1yb3dcIj5cbiAgICAgICAgICAgICAgPGR0PlRpdGxlPC9kdD5cbiAgICAgICAgICAgICAgPGRkPntzYXZlZFRpY2tldC50aXRsZX08L2RkPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRldGFpbC1yb3dcIj5cbiAgICAgICAgICAgICAgPGR0PkRlc2NyaXB0aW9uPC9kdD5cbiAgICAgICAgICAgICAgPGRkPntzYXZlZFRpY2tldC5kZXNjcmlwdGlvbn08L2RkPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRldGFpbC1yb3dcIj5cbiAgICAgICAgICAgICAgPGR0PkNhdGVnb3J5PC9kdD5cbiAgICAgICAgICAgICAgPGRkPntzYXZlZFRpY2tldC5jYXRlZ29yeX08L2RkPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRldGFpbC1yb3dcIj5cbiAgICAgICAgICAgICAgPGR0PlByaW9yaXR5PC9kdD5cbiAgICAgICAgICAgICAgPGRkPntzYXZlZFRpY2tldC5wcmlvcml0eX08L2RkPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRldGFpbC1yb3dcIj5cbiAgICAgICAgICAgICAgPGR0PlN0YXR1czwvZHQ+XG4gICAgICAgICAgICAgIDxkZD57c2F2ZWRUaWNrZXQuc3RhdHVzfTwvZGQ+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2RsPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1hY3Rpb25zXCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidXR0b24tbGluayBzZWNvbmRhcnlcIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgnL2FwcC90aWNrZXRzJyl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIEJhY2sgdG8gVGlja2V0c1xuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAge2xvYWRpbmcgPyAoXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRpY2tldC1mb3JtLWxvYWRpbmdcIj5Mb2FkaW5nIHRpY2tldC4uLjwvcD5cbiAgICAgICkgOiAoXG4gICAgICAgICghaXNFZGl0TW9kZSB8fCBpbml0aWFsVmFsdWVzKSAmJiAoXG4gICAgICAgICAgPFRpY2tldEZvcm1XaXphcmRcbiAgICAgICAgICAgIGtleT17dGlja2V0SWQgPz8gJ25ldyd9XG4gICAgICAgICAgICBpbml0aWFsVmFsdWVzPXtpbml0aWFsVmFsdWVzID8/IHVuZGVmaW5lZH1cbiAgICAgICAgICAgIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9XG4gICAgICAgICAgICBzYXZpbmc9e3NhdmluZ31cbiAgICAgICAgICAgIHN1Ym1pdExhYmVsPXtpc0VkaXRNb2RlID8gJ1NhdmUgQ2hhbmdlcycgOiAnQ3JlYXRlIFRpY2tldCd9XG4gICAgICAgICAgLz5cbiAgICAgICAgKVxuICAgICAgKX1cbiAgICA8Lz5cbiAgKTtcbn1cbiJdfQ==