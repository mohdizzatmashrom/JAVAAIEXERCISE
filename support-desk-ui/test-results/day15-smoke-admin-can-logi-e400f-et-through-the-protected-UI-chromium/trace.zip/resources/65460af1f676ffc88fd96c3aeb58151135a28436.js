import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/InlineFieldError.jsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/InlineFieldError.jsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3927c5ff";
export default function InlineFieldError({ message }) {
	if (!message) {
		return null;
	}
	return /* @__PURE__ */ _jsxDEV("span", {
		className: "field-error",
		role: "alert",
		children: message
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 6,
		columnNumber: 10
	}, this);
}
_c = InlineFieldError;
var _c;
$RefreshReg$(_c, "InlineFieldError");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/InlineFieldError.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/InlineFieldError.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/InlineFieldError.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/InlineFieldError.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFBQSxlQUFlLFNBQVMsaUJBQWlCLEVBQUUsV0FBVztDQUNwRCxJQUFJLENBQUMsU0FBUztFQUNaLE9BQU87Q0FDVDtDQUVBLE9BQU8sd0JBQUMsUUFBRDtFQUFNLFdBQVU7RUFBYyxNQUFLO1lBQVM7Q0FBYzs7Ozs7QUFDbkUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSW5saW5lRmllbGRFcnJvci5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSW5saW5lRmllbGRFcnJvcih7IG1lc3NhZ2UgfSkge1xuICBpZiAoIW1lc3NhZ2UpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJmaWVsZC1lcnJvclwiIHJvbGU9XCJhbGVydFwiPnttZXNzYWdlfTwvc3Bhbj47XG59XG4iXX0=