import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/TicketsPage.jsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];import { useTicketData } from "/src/context/TicketDataContext.jsx";
import TicketFilterPanel from "/src/components/TicketFilterPanel.jsx";
import TicketList from "/src/components/TicketList.jsx";
import TicketDetail from "/src/components/TicketDetail.jsx";
import PaginationControls from "/src/components/PaginationControls.jsx";
var _jsxFileName = "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/pages/TicketsPage.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3927c5ff";
var _s = $RefreshSig$();
export default function TicketsPage() {
	_s();
	const { loading, error, tickets, cacheMessage, pageInfo, sort, selectedId, selectedTicket, filters, setSearchText, setStatusFilter, setPage, setPageSize, setSortBy, setSortDirection, selectTicket, refreshTickets } = useTicketData();
	if (loading) {
		return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("h2", {
			className: "page-title",
			children: "Tickets"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 31,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("p", {
			className: "ticket-form-loading",
			children: "Loading tickets..."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 32,
			columnNumber: 9
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 30,
			columnNumber: 7
		}, this);
	}
	if (error) {
		return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("h2", {
			className: "page-title",
			children: "Tickets"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "ticket-form-error",
			role: "alert",
			children: /* @__PURE__ */ _jsxDEV("p", { children: error }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 42,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 41,
			columnNumber: 9
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
		className: "page-title-row",
		children: [/* @__PURE__ */ _jsxDEV("h2", {
			className: "page-title",
			children: "Tickets"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 51,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "page-title-actions",
			children: [cacheMessage && /* @__PURE__ */ _jsxDEV("span", {
				className: `cache-indicator ${cacheMessage === "Loaded from cache" ? "cache-hit" : "cache-miss"}`,
				children: cacheMessage
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				className: "refresh-btn",
				onClick: refreshTickets,
				title: "Force reload from backend",
				children: "Refresh"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 52,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 50,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV("div", {
		className: "ticket-dashboard",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "ticket-list-column",
			children: [
				/* @__PURE__ */ _jsxDEV(TicketFilterPanel, {
					searchText: filters.searchText,
					onSearchChange: setSearchText,
					statusFilter: filters.statusFilter,
					onStatusChange: setStatusFilter,
					sortBy: sort.sortBy,
					onSortByChange: setSortBy,
					direction: sort.direction,
					onDirectionChange: setSortDirection,
					pageSize: pageInfo.size,
					onPageSizeChange: setPageSize
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(TicketList, {
					tickets,
					selectedId,
					onSelect: selectTicket
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(PaginationControls, {
					page: pageInfo.page,
					totalPages: pageInfo.totalPages,
					totalElements: pageInfo.totalElements,
					onPrev: () => setPage(pageInfo.page - 1),
					onNext: () => setPage(pageInfo.page + 1)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 82,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 64,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV(TicketDetail, { ticket: selectedTicket }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 90,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 63,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 49,
		columnNumber: 5
	}, this);
}
_s(TicketsPage, "8ljqGmTWkOqaHcDz4TEIjm/HecA=", false, function() {
	return [useTicketData];
});
_c = TicketsPage;
var _c;
$RefreshReg$(_c, "TicketsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/TicketsPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/pages/TicketsPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/pages/TicketsPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/pages/TicketsPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxxQkFBcUI7QUFDOUIsT0FBTyx1QkFBdUI7QUFDOUIsT0FBTyxnQkFBZ0I7QUFDdkIsT0FBTyxrQkFBa0I7QUFDekIsT0FBTyx3QkFBd0I7Ozs7QUFFL0IsZUFBZSxTQUFTLGNBQWM7O0NBQ3BDLE1BQU0sRUFDSixTQUNBLE9BQ0EsU0FDQSxjQUNBLFVBQ0EsTUFDQSxZQUNBLGdCQUNBLFNBQ0EsZUFDQSxpQkFDQSxTQUNBLGFBQ0EsV0FDQSxrQkFDQSxjQUNBLG1CQUNFLGNBQWM7Q0FFbEIsSUFBSSxTQUFTO0VBQ1gsT0FDRSxnREFDRSx3QkFBQyxNQUFEO0dBQUksV0FBVTthQUFhO0VBQVc7Ozs7WUFDdEMsd0JBQUMsS0FBRDtHQUFHLFdBQVU7YUFBc0I7RUFBcUI7Ozs7VUFDeEQ7Ozs7O0NBRU47Q0FFQSxJQUFJLE9BQU87RUFDVCxPQUNFLGdEQUNFLHdCQUFDLE1BQUQ7R0FBSSxXQUFVO2FBQWE7RUFBVzs7OztZQUN0Qyx3QkFBQyxPQUFEO0dBQUssV0FBVTtHQUFvQixNQUFLO2FBQ3RDLHdCQUFDLEtBQUQsWUFBSSxNQUFTOzs7OztFQUNWOzs7O1VBQ0w7Ozs7O0NBRU47Q0FFQSxPQUNFLGdEQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDRSx3QkFBQyxNQUFEO0dBQUksV0FBVTthQUFhO0VBQVc7Ozs7WUFDdEMsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNHLGdCQUNDLHdCQUFDLFFBQUQ7SUFBTSxXQUFXLG1CQUFtQixpQkFBaUIsc0JBQXNCLGNBQWM7Y0FDdEY7R0FDRzs7OzthQUVSLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO0lBQWMsU0FBUztJQUFnQixPQUFNO2NBQTRCO0dBRW5GOzs7O1dBQ0w7Ozs7O1VBQ0Y7Ozs7O1dBQ0wsd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxtQkFBRDtLQUNFLFlBQVksUUFBUTtLQUNwQixnQkFBZ0I7S0FDaEIsY0FBYyxRQUFRO0tBQ3RCLGdCQUFnQjtLQUNoQixRQUFRLEtBQUs7S0FDYixnQkFBZ0I7S0FDaEIsV0FBVyxLQUFLO0tBQ2hCLG1CQUFtQjtLQUNuQixVQUFVLFNBQVM7S0FDbkIsa0JBQWtCO0lBQ25COzs7OztJQUNELHdCQUFDLFlBQUQ7S0FDVztLQUNHO0tBQ1osVUFBVTtJQUNYOzs7OztJQUNELHdCQUFDLG9CQUFEO0tBQ0UsTUFBTSxTQUFTO0tBQ2YsWUFBWSxTQUFTO0tBQ3JCLGVBQWUsU0FBUztLQUN4QixjQUFjLFFBQVEsU0FBUyxPQUFPLENBQUM7S0FDdkMsY0FBYyxRQUFRLFNBQVMsT0FBTyxDQUFDO0lBQ3hDOzs7OztHQUNFOzs7OztZQUNMLHdCQUFDLGNBQUQsRUFBYyxRQUFRLGVBQWlCOzs7O1VBQ3BDOzs7OztTQUNMOzs7OztBQUVOIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlRpY2tldHNQYWdlLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VUaWNrZXREYXRhIH0gZnJvbSAnLi4vY29udGV4dC9UaWNrZXREYXRhQ29udGV4dC5qc3gnO1xuaW1wb3J0IFRpY2tldEZpbHRlclBhbmVsIGZyb20gJy4uL2NvbXBvbmVudHMvVGlja2V0RmlsdGVyUGFuZWwuanN4JztcbmltcG9ydCBUaWNrZXRMaXN0IGZyb20gJy4uL2NvbXBvbmVudHMvVGlja2V0TGlzdC5qc3gnO1xuaW1wb3J0IFRpY2tldERldGFpbCBmcm9tICcuLi9jb21wb25lbnRzL1RpY2tldERldGFpbC5qc3gnO1xuaW1wb3J0IFBhZ2luYXRpb25Db250cm9scyBmcm9tICcuLi9jb21wb25lbnRzL1BhZ2luYXRpb25Db250cm9scy5qc3gnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBUaWNrZXRzUGFnZSgpIHtcbiAgY29uc3Qge1xuICAgIGxvYWRpbmcsXG4gICAgZXJyb3IsXG4gICAgdGlja2V0cyxcbiAgICBjYWNoZU1lc3NhZ2UsXG4gICAgcGFnZUluZm8sXG4gICAgc29ydCxcbiAgICBzZWxlY3RlZElkLFxuICAgIHNlbGVjdGVkVGlja2V0LFxuICAgIGZpbHRlcnMsXG4gICAgc2V0U2VhcmNoVGV4dCxcbiAgICBzZXRTdGF0dXNGaWx0ZXIsXG4gICAgc2V0UGFnZSxcbiAgICBzZXRQYWdlU2l6ZSxcbiAgICBzZXRTb3J0QnksXG4gICAgc2V0U29ydERpcmVjdGlvbixcbiAgICBzZWxlY3RUaWNrZXQsXG4gICAgcmVmcmVzaFRpY2tldHNcbiAgfSA9IHVzZVRpY2tldERhdGEoKTtcblxuICBpZiAobG9hZGluZykge1xuICAgIHJldHVybiAoXG4gICAgICA8PlxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwicGFnZS10aXRsZVwiPlRpY2tldHM8L2gyPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0aWNrZXQtZm9ybS1sb2FkaW5nXCI+TG9hZGluZyB0aWNrZXRzLi4uPC9wPlxuICAgICAgPC8+XG4gICAgKTtcbiAgfVxuXG4gIGlmIChlcnJvcikge1xuICAgIHJldHVybiAoXG4gICAgICA8PlxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwicGFnZS10aXRsZVwiPlRpY2tldHM8L2gyPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpY2tldC1mb3JtLWVycm9yXCIgcm9sZT1cImFsZXJ0XCI+XG4gICAgICAgICAgPHA+e2Vycm9yfTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8Lz5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYWdlLXRpdGxlLXJvd1wiPlxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwicGFnZS10aXRsZVwiPlRpY2tldHM8L2gyPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhZ2UtdGl0bGUtYWN0aW9uc1wiPlxuICAgICAgICAgIHtjYWNoZU1lc3NhZ2UgJiYgKFxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgY2FjaGUtaW5kaWNhdG9yICR7Y2FjaGVNZXNzYWdlID09PSAnTG9hZGVkIGZyb20gY2FjaGUnID8gJ2NhY2hlLWhpdCcgOiAnY2FjaGUtbWlzcyd9YH0+XG4gICAgICAgICAgICAgIHtjYWNoZU1lc3NhZ2V9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgKX1cbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInJlZnJlc2gtYnRuXCIgb25DbGljaz17cmVmcmVzaFRpY2tldHN9IHRpdGxlPVwiRm9yY2UgcmVsb2FkIGZyb20gYmFja2VuZFwiPlxuICAgICAgICAgICAgUmVmcmVzaFxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aWNrZXQtZGFzaGJvYXJkXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGlja2V0LWxpc3QtY29sdW1uXCI+XG4gICAgICAgICAgPFRpY2tldEZpbHRlclBhbmVsXG4gICAgICAgICAgICBzZWFyY2hUZXh0PXtmaWx0ZXJzLnNlYXJjaFRleHR9XG4gICAgICAgICAgICBvblNlYXJjaENoYW5nZT17c2V0U2VhcmNoVGV4dH1cbiAgICAgICAgICAgIHN0YXR1c0ZpbHRlcj17ZmlsdGVycy5zdGF0dXNGaWx0ZXJ9XG4gICAgICAgICAgICBvblN0YXR1c0NoYW5nZT17c2V0U3RhdHVzRmlsdGVyfVxuICAgICAgICAgICAgc29ydEJ5PXtzb3J0LnNvcnRCeX1cbiAgICAgICAgICAgIG9uU29ydEJ5Q2hhbmdlPXtzZXRTb3J0Qnl9XG4gICAgICAgICAgICBkaXJlY3Rpb249e3NvcnQuZGlyZWN0aW9ufVxuICAgICAgICAgICAgb25EaXJlY3Rpb25DaGFuZ2U9e3NldFNvcnREaXJlY3Rpb259XG4gICAgICAgICAgICBwYWdlU2l6ZT17cGFnZUluZm8uc2l6ZX1cbiAgICAgICAgICAgIG9uUGFnZVNpemVDaGFuZ2U9e3NldFBhZ2VTaXplfVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFRpY2tldExpc3RcbiAgICAgICAgICAgIHRpY2tldHM9e3RpY2tldHN9XG4gICAgICAgICAgICBzZWxlY3RlZElkPXtzZWxlY3RlZElkfVxuICAgICAgICAgICAgb25TZWxlY3Q9e3NlbGVjdFRpY2tldH1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxQYWdpbmF0aW9uQ29udHJvbHNcbiAgICAgICAgICAgIHBhZ2U9e3BhZ2VJbmZvLnBhZ2V9XG4gICAgICAgICAgICB0b3RhbFBhZ2VzPXtwYWdlSW5mby50b3RhbFBhZ2VzfVxuICAgICAgICAgICAgdG90YWxFbGVtZW50cz17cGFnZUluZm8udG90YWxFbGVtZW50c31cbiAgICAgICAgICAgIG9uUHJldj17KCkgPT4gc2V0UGFnZShwYWdlSW5mby5wYWdlIC0gMSl9XG4gICAgICAgICAgICBvbk5leHQ9eygpID0+IHNldFBhZ2UocGFnZUluZm8ucGFnZSArIDEpfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8VGlja2V0RGV0YWlsIHRpY2tldD17c2VsZWN0ZWRUaWNrZXR9IC8+XG4gICAgICA8L2Rpdj5cbiAgICA8Lz5cbiAgKTtcbn1cbiJdfQ==