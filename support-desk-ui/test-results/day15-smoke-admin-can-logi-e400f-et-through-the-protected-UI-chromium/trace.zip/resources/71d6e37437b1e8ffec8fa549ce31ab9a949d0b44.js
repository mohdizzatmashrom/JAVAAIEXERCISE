/**
* Reusable HTTP client for the Support Desk backend.
*
* Centralises JSON serialisation, the Authorization header, and
* error-message extraction so that individual API helpers stay
* focused on *what* they request rather than *how* the fetch is
* wired up.
*/
const BASE_URL = "/api";
/**
* Make an API request.
*
* @param {string}  path              - Path relative to BASE_URL (e.g. "/v1/tickets").
* @param {object}  [options]
* @param {string}  [options.method]  - HTTP method (default "GET").
* @param {string}  [options.token]   - JWT token; when provided an Authorization header is added.
* @param {object}  [options.body]    - Request payload – will be JSON-stringified automatically.
* @param {object}  [options.headers] - Extra headers merged on top of the defaults.
* @returns {Promise<any>} Parsed JSON response body (or null for non-JSON responses).
*
* @throws {Error} When the response is not ok.  The message is built from the
*                 backend's `message` field plus any field-level `errors`.
*/
export async function apiRequest(path, options = {}) {
	const { method = "GET", token, body, headers: extraHeaders = {} } = options;
	const headers = {
		"Content-Type": "application/json",
		...extraHeaders
	};
	if (token) {
		headers.Authorization = `Bearer ${token}`;
	}
	const config = {
		method,
		headers
	};
	if (body !== undefined) {
		config.body = JSON.stringify(body);
	}
	const response = await fetch(`${BASE_URL}${path}`, config);
	return parseJsonResponse(response);
}
/* ------------------------------------------------------------------ */
/*  Internal helpers                                                    */
/* ------------------------------------------------------------------ */
async function parseJsonResponse(response) {
	const contentType = response.headers.get("content-type") ?? "";
	const body = contentType.includes("application/json") ? await response.json() : null;
	if (!response.ok) {
		let message = body?.message || `Request failed with status ${response.status}`;
		const fieldDetails = (body?.errors ?? []).map((error) => `${error.field}: ${error.message}`).join("; ");
		if (fieldDetails) {
			message = `${message} (${fieldDetails})`;
		}
		throw new Error(message);
	}
	return body;
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFTQSxNQUFNLFdBQVc7Ozs7Ozs7Ozs7Ozs7OztBQWdCakIsT0FBTyxlQUFlLFdBQVcsTUFBTSxVQUFVLENBQUMsR0FBRztDQUNuRCxNQUFNLEVBQUUsU0FBUyxPQUFPLE9BQU8sTUFBTSxTQUFTLGVBQWUsQ0FBQyxNQUFNO0NBRXBFLE1BQU0sVUFBVTtFQUNkLGdCQUFnQjtFQUNoQixHQUFHO0NBQ0w7Q0FFQSxJQUFJLE9BQU87RUFDVCxRQUFRLGdCQUFnQixVQUFVO0NBQ3BDO0NBRUEsTUFBTSxTQUFTO0VBQUU7RUFBUTtDQUFRO0NBRWpDLElBQUksU0FBUyxXQUFXO0VBQ3RCLE9BQU8sT0FBTyxLQUFLLFVBQVUsSUFBSTtDQUNuQztDQUVBLE1BQU0sV0FBVyxNQUFNLE1BQU0sR0FBRyxXQUFXLFFBQVEsTUFBTTtDQUV6RCxPQUFPLGtCQUFrQixRQUFRO0FBQ25DOzs7O0FBTUEsZUFBZSxrQkFBa0IsVUFBVTtDQUN6QyxNQUFNLGNBQWMsU0FBUyxRQUFRLElBQUksY0FBYyxLQUFLO0NBQzVELE1BQU0sT0FBTyxZQUFZLFNBQVMsa0JBQWtCLElBQUksTUFBTSxTQUFTLEtBQUssSUFBSTtDQUVoRixJQUFJLENBQUMsU0FBUyxJQUFJO0VBQ2hCLElBQUksVUFBVSxNQUFNLFdBQVcsOEJBQThCLFNBQVM7RUFFdEUsTUFBTSxnQkFBZ0IsTUFBTSxVQUFVLENBQUMsRUFBQyxDQUNyQyxLQUFLLFVBQVUsR0FBRyxNQUFNLE1BQU0sSUFBSSxNQUFNLFNBQVMsQ0FBQyxDQUNsRCxLQUFLLElBQUk7RUFFWixJQUFJLGNBQWM7R0FDaEIsVUFBVSxHQUFHLFFBQVEsSUFBSSxhQUFhO0VBQ3hDO0VBRUEsTUFBTSxJQUFJLE1BQU0sT0FBTztDQUN6QjtDQUVBLE9BQU87QUFDVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJodHRwQ2xpZW50LmpzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBSZXVzYWJsZSBIVFRQIGNsaWVudCBmb3IgdGhlIFN1cHBvcnQgRGVzayBiYWNrZW5kLlxyXG4gKlxyXG4gKiBDZW50cmFsaXNlcyBKU09OIHNlcmlhbGlzYXRpb24sIHRoZSBBdXRob3JpemF0aW9uIGhlYWRlciwgYW5kXHJcbiAqIGVycm9yLW1lc3NhZ2UgZXh0cmFjdGlvbiBzbyB0aGF0IGluZGl2aWR1YWwgQVBJIGhlbHBlcnMgc3RheVxyXG4gKiBmb2N1c2VkIG9uICp3aGF0KiB0aGV5IHJlcXVlc3QgcmF0aGVyIHRoYW4gKmhvdyogdGhlIGZldGNoIGlzXHJcbiAqIHdpcmVkIHVwLlxyXG4gKi9cclxuXHJcbmNvbnN0IEJBU0VfVVJMID0gJy9hcGknO1xyXG5cclxuLyoqXHJcbiAqIE1ha2UgYW4gQVBJIHJlcXVlc3QuXHJcbiAqXHJcbiAqIEBwYXJhbSB7c3RyaW5nfSAgcGF0aCAgICAgICAgICAgICAgLSBQYXRoIHJlbGF0aXZlIHRvIEJBU0VfVVJMIChlLmcuIFwiL3YxL3RpY2tldHNcIikuXHJcbiAqIEBwYXJhbSB7b2JqZWN0fSAgW29wdGlvbnNdXHJcbiAqIEBwYXJhbSB7c3RyaW5nfSAgW29wdGlvbnMubWV0aG9kXSAgLSBIVFRQIG1ldGhvZCAoZGVmYXVsdCBcIkdFVFwiKS5cclxuICogQHBhcmFtIHtzdHJpbmd9ICBbb3B0aW9ucy50b2tlbl0gICAtIEpXVCB0b2tlbjsgd2hlbiBwcm92aWRlZCBhbiBBdXRob3JpemF0aW9uIGhlYWRlciBpcyBhZGRlZC5cclxuICogQHBhcmFtIHtvYmplY3R9ICBbb3B0aW9ucy5ib2R5XSAgICAtIFJlcXVlc3QgcGF5bG9hZCDigJMgd2lsbCBiZSBKU09OLXN0cmluZ2lmaWVkIGF1dG9tYXRpY2FsbHkuXHJcbiAqIEBwYXJhbSB7b2JqZWN0fSAgW29wdGlvbnMuaGVhZGVyc10gLSBFeHRyYSBoZWFkZXJzIG1lcmdlZCBvbiB0b3Agb2YgdGhlIGRlZmF1bHRzLlxyXG4gKiBAcmV0dXJucyB7UHJvbWlzZTxhbnk+fSBQYXJzZWQgSlNPTiByZXNwb25zZSBib2R5IChvciBudWxsIGZvciBub24tSlNPTiByZXNwb25zZXMpLlxyXG4gKlxyXG4gKiBAdGhyb3dzIHtFcnJvcn0gV2hlbiB0aGUgcmVzcG9uc2UgaXMgbm90IG9rLiAgVGhlIG1lc3NhZ2UgaXMgYnVpbHQgZnJvbSB0aGVcclxuICogICAgICAgICAgICAgICAgIGJhY2tlbmQncyBgbWVzc2FnZWAgZmllbGQgcGx1cyBhbnkgZmllbGQtbGV2ZWwgYGVycm9yc2AuXHJcbiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYXBpUmVxdWVzdChwYXRoLCBvcHRpb25zID0ge30pIHtcclxuICBjb25zdCB7IG1ldGhvZCA9ICdHRVQnLCB0b2tlbiwgYm9keSwgaGVhZGVyczogZXh0cmFIZWFkZXJzID0ge30gfSA9IG9wdGlvbnM7XHJcblxyXG4gIGNvbnN0IGhlYWRlcnMgPSB7XHJcbiAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgLi4uZXh0cmFIZWFkZXJzXHJcbiAgfTtcclxuXHJcbiAgaWYgKHRva2VuKSB7XHJcbiAgICBoZWFkZXJzLkF1dGhvcml6YXRpb24gPSBgQmVhcmVyICR7dG9rZW59YDtcclxuICB9XHJcblxyXG4gIGNvbnN0IGNvbmZpZyA9IHsgbWV0aG9kLCBoZWFkZXJzIH07XHJcblxyXG4gIGlmIChib2R5ICE9PSB1bmRlZmluZWQpIHtcclxuICAgIGNvbmZpZy5ib2R5ID0gSlNPTi5zdHJpbmdpZnkoYm9keSk7XHJcbiAgfVxyXG5cclxuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfSR7cGF0aH1gLCBjb25maWcpO1xyXG5cclxuICByZXR1cm4gcGFyc2VKc29uUmVzcG9uc2UocmVzcG9uc2UpO1xyXG59XHJcblxyXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cclxuLyogIEludGVybmFsIGhlbHBlcnMgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKi9cclxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXHJcblxyXG5hc3luYyBmdW5jdGlvbiBwYXJzZUpzb25SZXNwb25zZShyZXNwb25zZSkge1xyXG4gIGNvbnN0IGNvbnRlbnRUeXBlID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoJ2NvbnRlbnQtdHlwZScpID8/ICcnO1xyXG4gIGNvbnN0IGJvZHkgPSBjb250ZW50VHlwZS5pbmNsdWRlcygnYXBwbGljYXRpb24vanNvbicpID8gYXdhaXQgcmVzcG9uc2UuanNvbigpIDogbnVsbDtcclxuXHJcbiAgaWYgKCFyZXNwb25zZS5vaykge1xyXG4gICAgbGV0IG1lc3NhZ2UgPSBib2R5Py5tZXNzYWdlIHx8IGBSZXF1ZXN0IGZhaWxlZCB3aXRoIHN0YXR1cyAke3Jlc3BvbnNlLnN0YXR1c31gO1xyXG5cclxuICAgIGNvbnN0IGZpZWxkRGV0YWlscyA9IChib2R5Py5lcnJvcnMgPz8gW10pXHJcbiAgICAgIC5tYXAoKGVycm9yKSA9PiBgJHtlcnJvci5maWVsZH06ICR7ZXJyb3IubWVzc2FnZX1gKVxyXG4gICAgICAuam9pbignOyAnKTtcclxuXHJcbiAgICBpZiAoZmllbGREZXRhaWxzKSB7XHJcbiAgICAgIG1lc3NhZ2UgPSBgJHttZXNzYWdlfSAoJHtmaWVsZERldGFpbHN9KWA7XHJcbiAgICB9XHJcblxyXG4gICAgdGhyb3cgbmV3IEVycm9yKG1lc3NhZ2UpO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIGJvZHk7XHJcbn1cclxuIl19