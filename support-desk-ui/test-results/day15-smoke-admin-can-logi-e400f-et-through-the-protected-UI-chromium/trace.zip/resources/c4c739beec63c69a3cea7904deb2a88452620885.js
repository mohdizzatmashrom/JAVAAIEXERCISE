import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PaginationControls.jsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/PaginationControls.jsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3927c5ff";
export default function PaginationControls({ page, totalPages, totalElements, onPrev, onNext }) {
	const canGoPrev = page > 0;
	const canGoNext = page < totalPages - 1;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "pagination-controls",
		children: [
			/* @__PURE__ */ _jsxDEV("button", {
				className: "pagination-btn",
				disabled: !canGoPrev,
				onClick: onPrev,
				children: "← Previous"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 7,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("span", {
				className: "pagination-info",
				children: [
					"Page ",
					/* @__PURE__ */ _jsxDEV("strong", { children: page + 1 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 16,
						columnNumber: 14
					}, this),
					" of ",
					/* @__PURE__ */ _jsxDEV("strong", { children: totalPages || 1 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 16,
						columnNumber: 45
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "pagination-total",
						children: [
							" (",
							totalElements,
							" tickets)"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 17,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				className: "pagination-btn",
				disabled: !canGoNext,
				onClick: onNext,
				children: "Next →"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 6,
		columnNumber: 5
	}, this);
}
_c = PaginationControls;
var _c;
$RefreshReg$(_c, "PaginationControls");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/PaginationControls.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/PaginationControls.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/PaginationControls.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/izzat mashrom/Documents/JAVA FULLSTACK AI TRAINNING/Exercise/javaaiexercise/exercise/support-desk-ui/src/components/PaginationControls.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFBQSxlQUFlLFNBQVMsbUJBQW1CLEVBQUUsTUFBTSxZQUFZLGVBQWUsUUFBUSxVQUFVO0NBQzlGLE1BQU0sWUFBWSxPQUFPO0NBQ3pCLE1BQU0sWUFBWSxPQUFPLGFBQWE7Q0FFdEMsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsVUFBRDtJQUNFLFdBQVU7SUFDVixVQUFVLENBQUM7SUFDWCxTQUFTO2NBQ1Y7R0FFTzs7Ozs7R0FFUix3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFoQjtLQUFrQztLQUMzQix3QkFBQyxVQUFELFlBQVMsT0FBTyxFQUFVOzs7OztLQUFDO0tBQUksd0JBQUMsVUFBRCxZQUFTLGNBQWMsRUFBVTs7Ozs7S0FDckUsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCO09BQW1DO09BQUc7T0FBYztNQUFlOzs7Ozs7SUFDL0Q7Ozs7OztHQUVOLHdCQUFDLFVBQUQ7SUFDRSxXQUFVO0lBQ1YsVUFBVSxDQUFDO0lBQ1gsU0FBUztjQUNWO0dBRU87Ozs7O0VBQ0w7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlBhZ2luYXRpb25Db250cm9scy5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUGFnaW5hdGlvbkNvbnRyb2xzKHsgcGFnZSwgdG90YWxQYWdlcywgdG90YWxFbGVtZW50cywgb25QcmV2LCBvbk5leHQgfSkge1xyXG4gIGNvbnN0IGNhbkdvUHJldiA9IHBhZ2UgPiAwO1xyXG4gIGNvbnN0IGNhbkdvTmV4dCA9IHBhZ2UgPCB0b3RhbFBhZ2VzIC0gMTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwicGFnaW5hdGlvbi1jb250cm9sc1wiPlxyXG4gICAgICA8YnV0dG9uXHJcbiAgICAgICAgY2xhc3NOYW1lPVwicGFnaW5hdGlvbi1idG5cIlxyXG4gICAgICAgIGRpc2FibGVkPXshY2FuR29QcmV2fVxyXG4gICAgICAgIG9uQ2xpY2s9e29uUHJldn1cclxuICAgICAgPlxyXG4gICAgICAgICZsYXJyOyBQcmV2aW91c1xyXG4gICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInBhZ2luYXRpb24taW5mb1wiPlxyXG4gICAgICAgIFBhZ2UgPHN0cm9uZz57cGFnZSArIDF9PC9zdHJvbmc+IG9mIDxzdHJvbmc+e3RvdGFsUGFnZXMgfHwgMX08L3N0cm9uZz5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwYWdpbmF0aW9uLXRvdGFsXCI+ICh7dG90YWxFbGVtZW50c30gdGlja2V0cyk8L3NwYW4+XHJcbiAgICAgIDwvc3Bhbj5cclxuXHJcbiAgICAgIDxidXR0b25cclxuICAgICAgICBjbGFzc05hbWU9XCJwYWdpbmF0aW9uLWJ0blwiXHJcbiAgICAgICAgZGlzYWJsZWQ9eyFjYW5Hb05leHR9XHJcbiAgICAgICAgb25DbGljaz17b25OZXh0fVxyXG4gICAgICA+XHJcbiAgICAgICAgTmV4dCAmcmFycjtcclxuICAgICAgPC9idXR0b24+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdfQ==